"""
puppet_manager.py — Gestión y recuperación del agente Puppet para EduControl Agent.

Si el master rechaza el certificado del equipo (borrado o revocado en el servidor, CA
regenerada, clave que no coincide…) Puppet se queda aplicando para siempre el catálogo en
caché y el equipo deja de actualizarse. Esta rutina lo detecta, pide al servidor de
EduControl que borre el certificado en el master, borra el SSL local y vuelve a pedir
certificado lanzando puppet agent.

Funciona con Puppet 3-5 (sin `puppet ssl`, SSL en /var/lib/puppet/ssl) y con Puppet 6+.
"""

import asyncio
import logging
import os
import platform
import re
import socket
import ssl
import subprocess
import threading
import time
from typing import List, Optional

logger = logging.getLogger('EduControlAgent')

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# Errores de Puppet que indican que el master no acepta nuestro certificado (o nosotros el suyo).
# "certificate unknown" es lo que responde el master cuando ha borrado el certificado del equipo.
SSL_ERROR_PATTERNS = (
    'certificate verify failed',
    'certificate revoked',
    'certificate unknown',
    'certificate required',
    'unknown ca',
    'bad certificate',
    'does not match its private key',
)

SSL_DIR_CANDIDATES = ('/etc/puppetlabs/puppet/ssl', '/var/lib/puppet/ssl')
PUPPET_CONF_CANDIDATES = ('/etc/puppetlabs/puppet/puppet.conf', '/etc/puppet/puppet.conf')

# Segundos que se da al master para borrar el certificado antes de pedir uno nuevo
MASTER_CLEAN_WAIT = 5
# Tiempo máximo de `puppet agent -t` al recuperar: si el certificado no se firma
# automáticamente, puppet esperaría indefinidamente
PUPPET_RUN_TIMEOUT = 600
PUPPET_WAITFORCERT = 15


def _matches_ssl_error(text: str) -> bool:
    text = (text or '').lower()
    return any(pattern in text for pattern in SSL_ERROR_PATTERNS)


class PuppetManager:
    """Encapsula toda la lógica de detección/recuperación de Puppet."""

    puppet_port = 8140

    def __init__(self, config):
        """
        Args:
            config: instancia de AgentConfig con http_url, token, hostname,
                    agent_id, verify_ssl y puppet_check_enabled.
        """
        self.config = config
        self._lock = threading.Lock()

    # ── información de puppet ────────────────────────────────────────────────

    @staticmethod
    def _run(cmd: List[str], timeout: int = 15) -> subprocess.CompletedProcess:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)

    def _puppet_config(self, key: str) -> Optional[str]:
        try:
            res = self._run(['puppet', 'config', 'print', key])
            value = res.stdout.strip()
            return value if res.returncode == 0 and value else None
        except Exception:
            return None

    def _puppet_major_version(self) -> Optional[int]:
        try:
            res = self._run(['puppet', '--version'])
            match = re.match(r'(\d+)\.', res.stdout.strip())
            return int(match.group(1)) if match else None
        except Exception:
            return None

    def _puppet_server(self) -> str:
        return self._puppet_config('server') or 'puppetinstituto'

    def _ssl_dir(self) -> str:
        configured = self._puppet_config('ssldir')
        if configured:
            return configured
        for path in SSL_DIR_CANDIDATES:
            if os.path.isdir(path):
                return path
        return SSL_DIR_CANDIDATES[-1]

    def _ssl_files(self, certname: str):
        """Rutas (certificado, clave privada, CA) del equipo."""
        ssl_dir = self._ssl_dir()
        return (
            os.path.join(ssl_dir, 'certs', f'{certname}.pem'),
            os.path.join(ssl_dir, 'private_keys', f'{certname}.pem'),
            os.path.join(ssl_dir, 'certs', 'ca.pem'),
        )

    def _get_puppet_certname(self) -> str:
        """Intenta obtener el certname exacto de Puppet."""
        for conf in PUPPET_CONF_CANDIDATES:
            if not os.path.exists(conf):
                continue
            try:
                with open(conf, 'r') as f:
                    for line in f:
                        if line.strip().startswith('certname'):
                            parts = line.split('=', 1)
                            if len(parts) > 1 and parts[1].strip():
                                return parts[1].strip()
            except Exception as e:
                logger.debug(f"Error leyendo {conf}: {e}")

        certname = self._puppet_config('certname')
        if certname:
            return certname

        for ssl_dir in SSL_DIR_CANDIDATES:
            cert_dir = os.path.join(ssl_dir, 'certs')
            try:
                for name in os.listdir(cert_dir):
                    if name.endswith('.pem') and name != 'ca.pem':
                        return name[:-4]
            except OSError:
                pass

        fqdn = socket.getfqdn()
        if fqdn and fqdn != 'localhost':
            return fqdn
        return self.config.hostname

    # ── diagnóstico ──────────────────────────────────────────────────────────

    def _validate_rsa_keypair(self, certname: str) -> bool:
        """Verifica con OpenSSL que el certificado y la clave privada coinciden."""
        cert_file, key_file, _ca = self._ssl_files(certname)
        if not os.path.exists(cert_file) or not os.path.exists(key_file):
            return False
        try:
            res_cert = self._run(['openssl', 'x509', '-noout', '-modulus', '-in', cert_file], timeout=5)
            res_key = self._run(['openssl', 'rsa', '-noout', '-modulus', '-in', key_file], timeout=5)
            mod_cert = res_cert.stdout.strip()
            mod_key = res_key.stdout.strip()
            return res_cert.returncode == 0 and res_key.returncode == 0 and bool(mod_cert) and mod_cert == mod_key
        except Exception as e:
            logger.debug(f"Error verificando OpenSSL modulus: {e}")
            return False

    def _recent_puppet_ssl_error(self, major: Optional[int]) -> bool:
        """Indica si Puppet ha registrado errores de certificado recientemente."""
        if major and major >= 6:
            try:
                res = self._run(['puppet', 'ssl', 'verify'], timeout=30)
                if res.returncode != 0 and _matches_ssl_error(res.stdout + res.stderr):
                    logger.warning(f"⚠️ puppet ssl verify detectó error SSL: {res.stderr.strip()}")
                    return True
            except Exception as e:
                logger.debug(f"puppet ssl verify falló: {e}")

        # Solo el arranque actual: errores de hace semanas no deben disparar nada
        try:
            res = self._run(['journalctl', '-u', 'puppet', '-b', '-n', '200', '--no-pager'], timeout=15)
            if res.returncode == 0 and _matches_ssl_error(res.stdout):
                logger.warning("⚠️ Detectado error de certificado de Puppet en journalctl")
                return True
        except Exception as e:
            logger.debug(f"journalctl no disponible: {e}")

        for path in ('/var/log/puppetlabs/puppet/puppet.log', '/var/log/puppet/puppet.log'):
            if not os.path.exists(path):
                continue
            try:
                res = self._run(['tail', '-n', '200', path])
                if res.returncode == 0 and _matches_ssl_error(res.stdout):
                    logger.warning(f"⚠️ Detectado error de certificado en {path}")
                    return True
            except Exception:
                pass
        return False

    def _test_puppet_connection(self, certname: str) -> Optional[bool]:
        """Comprueba con una petición real si el master acepta nuestro certificado.

        No basta con el handshake: con TLS 1.3 el cliente lo da por terminado antes de
        que el servidor valide su certificado, y el rechazo ("certificate unknown") solo
        llega al leer la respuesta. Por eso se envía una petición y se lee.

        Returns:
            True  → el master responde con nuestro certificado
            False → error SSL (certificado rechazado o CA distinta)
            None  → no se pudo comprobar (red, servidor caído, faltan ficheros…)
        """
        cert_file, key_file, ca_file = self._ssl_files(certname)
        if not (os.path.exists(cert_file) and os.path.exists(key_file) and os.path.exists(ca_file)):
            return False

        server = self._puppet_server()
        try:
            context = ssl.create_default_context(cafile=ca_file)
            context.load_cert_chain(certfile=cert_file, keyfile=key_file)
            with socket.create_connection((server, self.puppet_port), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=server) as tls:
                    tls.sendall(
                        f"GET /puppet-ca/v1/certificate/ca HTTP/1.1\r\nHost: {server}\r\n"
                        "Accept: text/plain\r\nConnection: close\r\n\r\n".encode()
                    )
                    head = tls.recv(16)
            if head.startswith(b'HTTP/'):
                return True
            logger.debug(f"Respuesta inesperada del master puppet: {head!r}")
            return None
        except ssl.SSLError as e:
            logger.warning(f"El master puppet rechaza la conexión TLS: {e}")
            return False
        except Exception as e:
            logger.debug(f"No se pudo contactar con el master puppet ({server}): {e}")
            return None

    # ── recuperación ─────────────────────────────────────────────────────────

    def _request_master_certificate_revocation(self, certname: str) -> bool:
        """Pide al backend que ejecute `puppetserver ca clean --certname` en el master."""
        notify_url = f"{self.config.http_url}/api/hosts/agent/puppet-stuck/"
        headers = {'Content-Type': 'application/json'}
        if self.config.token:
            headers['Authorization'] = f'Token {self.config.token}'

        logger.info(f"📤 Pidiendo al servidor que borre el certificado '{certname}' en el master...")
        try:
            response = requests.post(
                notify_url,
                json={
                    'mac': self._get_mac_address() or '',
                    'hostname': self.config.hostname,
                    'certname': certname,
                    'agent_id': self.config.agent_id,
                    'ip_address': self._get_ip_address(),
                },
                headers=headers,
                timeout=10,
                verify=self.config.verify_ssl,
            )
            if response.status_code == 200:
                logger.info("✅ Petición de limpieza aceptada.")
                return True
            logger.error(f"❌ Error API limpieza (HTTP {response.status_code}): {response.text}")
        except Exception as e:
            logger.error(f"❌ Error conectando para limpieza: {e}")
        return False

    def _set_puppet_service(self, action: str):
        try:
            self._run(['systemctl', action, 'puppet'], timeout=60)
        except Exception as e:
            logger.warning(f"No se pudo hacer '{action}' del servicio puppet: {e}")

    def _purge_ssl(self):
        """Borrar el SSL local de puppet (certificado, clave, CA y CRL)."""
        paths = {self._ssl_dir(), *SSL_DIR_CANDIDATES}
        for path in paths:
            if os.path.isdir(path):
                subprocess.run(['rm', '-rf', path], check=False)
                logger.info(f"🗑️ Directorio {path} purgado.")

    def _run_puppet_agent(self) -> subprocess.CompletedProcess:
        """`puppet agent -t` pidiendo certificado; acotado en el tiempo por si no se firma."""
        try:
            return self._run(
                ['puppet', 'agent', '-t', '--waitforcert', str(PUPPET_WAITFORCERT)],
                timeout=PUPPET_RUN_TIMEOUT,
            )
        except subprocess.TimeoutExpired:
            logger.warning(
                f"⚠️ puppet agent no terminó en {PUPPET_RUN_TIMEOUT} s: "
                "probablemente el certificado está pendiente de firma en el master."
            )
            return subprocess.CompletedProcess([], 1, '', 'timeout')

    def _renew_certificate_modern(self, certname: str):
        """Puppet 6+: pedir y descargar el certificado con `puppet ssl`."""
        for intento in range(1, 4):
            logger.info(f"⏳ Solicitando firma del certificado nuevo (intento {intento}/3)")
            res = self._run(['puppet', 'ssl', 'submit_request'], timeout=120)
            out = (res.stdout + res.stderr).lower()
            if 'conflict on the server' in out or 'does not match its private key' in out:
                logger.warning("⚠️ El master aún tiene el certificado antiguo; se vuelve a pedir su borrado.")
                if not self._request_master_certificate_revocation(certname):
                    return
                self._purge_ssl()
                time.sleep(MASTER_CLEAN_WAIT * 2)
                continue
            break

        for intento in range(1, 4):
            time.sleep(3)
            self._run(['puppet', 'ssl', 'download_cert'], timeout=60)
            if self._validate_rsa_keypair(certname):
                logger.info(f"✅ Certificado descargado en el intento {intento}.")
                return
        logger.warning("⚠️ El certificado no se ha firmado todavía; puppet agent lo seguirá intentando.")

    def _repair(self, certname: str, major: Optional[int]) -> bool:
        logger.info("🛠️ Recuperando el certificado de Puppet...")
        if not self._request_master_certificate_revocation(certname):
            logger.error(
                "❌ El servidor de EduControl no pudo borrar el certificado en el master; "
                "no se toca el certificado local. Se reintentará en la próxima comprobación."
            )
            return False

        time.sleep(MASTER_CLEAN_WAIT)
        self._set_puppet_service('stop')
        try:
            self._purge_ssl()
            if major and major >= 6:
                self._renew_certificate_modern(certname)
            logger.info("🔄 Ejecutando puppet agent para obtener certificado y catálogo...")
            res = self._run_puppet_agent()
            # puppet agent -t: 0 sin cambios, 2 con cambios; 4/6 = fallos de recursos
            logger.info(f"puppet agent terminó con código {res.returncode}")
        finally:
            self._set_puppet_service('start')

        result = self._test_puppet_connection(certname)
        if result is True:
            logger.info("✅ Certificado de Puppet regenerado: el master lo acepta.")
            return True
        logger.warning("⚠️ Tras la recuperación el master todavía no acepta el certificado (¿pendiente de firma?).")
        return False

    # ── comprobación principal ────────────────────────────────────────────────

    def check_and_repair(self) -> Optional[bool]:
        """Comprobar el SSL de puppet y repararlo si el master lo rechaza.

        Returns:
            None si no aplica o no se pudo comprobar, True si está bien o se reparó,
            False si sigue roto.
        """
        if platform.system() != 'Linux' or not REQUESTS_AVAILABLE or not self.config.puppet_check_enabled:
            return None
        if not self._lock.acquire(blocking=False):
            logger.debug("Comprobación de Puppet ya en curso; se omite.")
            return None
        try:
            logger.info("🔍 Verificando estado del SSL del agente puppet...")
            major = self._puppet_major_version()
            if major is None:
                logger.info("ℹ️ Puppet no está instalado; nada que comprobar.")
                return None

            certname = self._get_puppet_certname()
            cert_file, _key, _ca = self._ssl_files(certname)

            if not os.path.exists(cert_file):
                # Sin certificado no hay nada que reparar (p. ej. primera petición pendiente de firma)
                logger.info(f"ℹ️ Puppet aún no tiene certificado para '{certname}'; lo pedirá puppet agent.")
                return None

            if not self._validate_rsa_keypair(certname):
                logger.warning("⚠️ El certificado de Puppet no coincide con su clave privada.")
                return self._repair(certname, major)

            # El handshake con petición real es la prueba que manda; los logs solo sirven de aviso
            connection = self._test_puppet_connection(certname)
            if connection is True:
                logger.info("✅ SSL de Puppet verificado y funcionando correctamente.")
                return True
            if connection is None:
                if self._recent_puppet_ssl_error(major):
                    logger.info("ℹ️ Hay errores de certificado en los logs, pero el master no responde ahora; se reintentará.")
                else:
                    logger.info("ℹ️ No se pudo contactar con el master puppet; se reintentará.")
                return None

            logger.warning(f"⚠️ El master puppet rechaza el certificado '{certname}'.")
            return self._repair(certname, major)
        except Exception as e:
            logger.error(f"❌ Error en rutina recuperadora de Puppet: {e}")
            return False
        finally:
            self._lock.release()

    async def check_puppet_stuck(self):
        """Versión asíncrona: la comprobación y la reparación (que puede tardar minutos)
        corren en un hilo para no bloquear el WebSocket del agente."""
        await asyncio.to_thread(self.check_and_repair)

    # ── utilidades ────────────────────────────────────────────────────────────

    def _get_ip_address(self) -> str:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect((self.config.host, 80))
                return s.getsockname()[0]
        except Exception:
            return "unknown"

    def _get_mac_address(self) -> Optional[str]:
        """MAC principal: la cableada si la hay; si no, la wifi."""
        try:
            import psutil as _psutil
            interfaces = _psutil.net_if_addrs()
            for patterns in (('eno', 'ens', 'enp', 'eth', 'enx'), ('wl',)):
                for iface, addrs in sorted(interfaces.items()):
                    if not iface.lower().startswith(patterns):
                        continue
                    for addr in addrs:
                        if addr.family == _psutil.AF_LINK:
                            mac = addr.address.upper()
                            if mac and mac != '00:00:00:00:00:00':
                                return mac
        except Exception:
            pass
        return None

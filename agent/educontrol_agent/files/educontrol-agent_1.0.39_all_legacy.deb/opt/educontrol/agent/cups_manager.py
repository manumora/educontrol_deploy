"""
cups_manager.py — Configuración automática de auditoría CUPS para EduControl Agent.

Asegura que el daemon CUPS registre cada trabajo impreso con el formato
requerido por el daemon de parsing interno (page_log).
"""

import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger('EduControlAgent')

CUPSD_CONF = '/etc/cups/cupsd.conf'

# Directivas requeridas y sus valores exactos.
REQUIRED_DIRECTIVES = [
    ('JobPrivateValues', 'none'),
    ('PageLog', '/var/log/cups/page_log'),
    ('PageLogFormat', '%p %u %j %T %P %C %{job-originating-host-name} %{job-name}'),
]


class CUPSManager:
    """Encapsula la lógica de detección y configuración de CUPS para auditoría."""

    def __init__(self, config):
        """
        Args:
            config: instancia de AgentConfig con cups_audit_enabled.
        """
        self.config = config

    # ── helpers privados ─────────────────────────────────────────────────────

    @staticmethod
    def _cups_installed() -> bool:
        """Verifica si CUPS está instalado (presencia de cupsd.conf)."""
        return os.path.isfile(CUPSD_CONF)

    @staticmethod
    def _is_active(line: str, directive: str, value: str) -> bool:
        """
        Comprueba si una línea activa (sin # al inicio) contiene la
        directiva con el valor esperado.

        Se considera activa si la línea, tras stripping, no empieza por '#'.
        """
        stripped = line.strip()
        if stripped.startswith('#'):
            return False
        # La directiva puede aparecer sola o con el valor pegado:
        #   JobPrivateValues none
        #   JobPrivateValues=none
        #   PageLog /var/log/cups/page_log
        return (
            stripped == f'{directive} {value}'
            or stripped == f'{directive}={value}'
        )

    def _configure(self) -> bool:
        """
        Lee /etc/cups/cupsd.conf y garantiza la presencia de las directivas
        requeridas.  Si una directiva ya está activa con el valor correcto
        no se modifica; si está activa con un valor incorrecto se comenta
        y se agrega la correcta; si no existe se agrega al final.

        Returns:
            True  → el archivo fue modificado
            False → no hubo cambios (ya estaba correctamente configurado)
        """
        if not self._cups_installed():
            return False

        try:
            with open(CUPSD_CONF, 'r') as f:
                lines = f.readlines()
        except OSError as e:
            logger.error(f"No se pudo leer {CUPSD_CONF}: {e}")
            return False

        modified = False
        new_lines = []
        # Rastrea qué directivas ya están activas con el valor correcto.
        satisfied = set()

        for line in lines:
            stripped = line.strip()

            # Verificar si esta línea es una directiva activa que necesitamos.
            matched = False
            for idx, (directive, value) in enumerate(REQUIRED_DIRECTIVES):
                if idx in satisfied:
                    continue  # ya la tenemos

                # Línea activa con el valor correcto → dejarla y marcarla.
                if self._is_active(line, directive, value):
                    satisfied.add(idx)
                    new_lines.append(line)
                    matched = True
                    break

                # Línea activa de la misma directiva pero con valor distinto
                # → comentar y planear agregar la correcta.
                if stripped and not stripped.startswith('#'):
                    parts = stripped.split()
                    key = parts[0].rstrip('=') if parts else ''
                    if key == directive:
                        logger.info(
                            f"CUPS: comentando línea existente "
                            f"'{stripped}' (valor incorrecto)"
                        )
                        new_lines.append(f"# {line.rstrip()}\n" if not line.startswith('#') else line)
                        matched = True
                        break

            if not matched:
                new_lines.append(line)

        # Agregar las directivas faltantes al final.
        for idx, (directive, value) in enumerate(REQUIRED_DIRECTIVES):
            if idx not in satisfied:
                logger.info(f"CUPS: añadiendo '{directive} {value}'")
                new_lines.append(f"\n{directive} {value}\n")
                modified = True

        if modified:
            try:
                with open(CUPSD_CONF, 'w') as f:
                    f.writelines(new_lines)
                logger.info(f"CUPS: {CUPSD_CONF} actualizado correctamente")
            except OSError as e:
                logger.error(f"No se pudo escribir {CUPSD_CONF}: {e}")
                return False

        return modified

    @staticmethod
    def _restart_cups() -> bool:
        """Reinicia el servicio CUPS para que los cambios surtan efecto."""
        try:
            result = subprocess.run(
                ['systemctl', 'restart', 'cups'],
                capture_output=True, text=True, timeout=15, check=False,
            )
            if result.returncode == 0:
                logger.info("✅ Servicio CUPS reiniciado correctamente")
                return True
            else:
                logger.warning(f"CUPS: fallo al reiniciar (rc={result.returncode}): {result.stderr.strip()}")
                return False
        except Exception as e:
            logger.warning(f"CUPS: error al reiniciar el servicio: {e}")
            return False

    # ── entrada principal ────────────────────────────────────────────────────

    def configure_audit(self) -> bool:
        """
        Configura CUPS para auditoría de impresiones.

        Retorna True si la auditoría está activa al final (ya lo estaba o fue
        configurada en esta llamada), False en caso contrario.
        """
        if not self._cups_installed():
            logger.warning("⚠️  CUPS no está instalado en este equipo; omitiendo configuración de auditoría")
            return False

        modified = self._configure()

        if modified:
            self._restart_cups()
            return True

        logger.info("✅ CUPS ya está configurado para auditoría de impresiones")
        return True

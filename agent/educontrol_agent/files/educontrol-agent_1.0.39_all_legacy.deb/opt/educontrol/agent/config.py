"""
config.py — Configuración del agente EduControl.
"""

import json
import logging
import re
import socket
import uuid
from typing import Optional

logger = logging.getLogger('EduControlAgent')

# Disponibilidad de psutil (se comprueba en tiempo de importación para ser coherente
# con el resto del paquete; se importa de forma lazy en _generate_agent_id).
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False


class AgentConfig:
    """Configuración del agente."""

    def __init__(self):
        self.host = "localhost"
        self.websocket_port = "8003"
        self.http_port = "8002"
        self.token: Optional[str] = None
        self.agent_id = self._generate_agent_id()
        self.hostname = socket.gethostname()
        self.heartbeat_interval = 30      # segundos
        self.reconnect_delay = 5          # segundos
        self.max_reconnect_attempts = None  # None = infinito
        self.auto_inventory = False
        self.auto_rename = False
        self.vnc_enabled = True
        self.puppet_check_enabled = True
        self.print_tracking = True
        self.vnc_port = 5950              # rango 5950+ para evitar conflictos
        self.ssl_enabled = False
        self.verify_ssl = False

    # ── propiedades ────────────────────────────────────────────────────────

    @property
    def server_url(self) -> str:
        protocol = "wss" if self.ssl_enabled else "ws"
        return f"{protocol}://{self.host}:{self.websocket_port}/ws/agent/"

    @property
    def http_url(self) -> str:
        protocol = "https" if self.ssl_enabled else "http"
        return f"{protocol}://{self.host}:{self.http_port}"

    # ── generación de ID ───────────────────────────────────────────────────

    @staticmethod
    def _generate_agent_id() -> str:
        """Generar ID único basado en MAC address (prioriza Ethernet sobre WiFi)."""
        try:
            if PSUTIL_AVAILABLE:
                ethernet_keywords = ['eth', 'enp', 'eno', 'ens', 'enx', 'enet']
                wifi_keywords = ['wlan', 'wifi', 'wlp', 'wlx', 'wifi0']

                ethernet_mac = None
                wifi_mac = None
                fallback_mac = None

                for iface, addrs in psutil.net_if_addrs().items():
                    if iface.lower() in ['lo', 'loopback'] or iface.lower().startswith(
                            ('veth', 'br-', 'docker', 'virbr')):
                        continue

                    is_ethernet = any(iface.lower().startswith(k) for k in ethernet_keywords)
                    is_wifi = any(iface.lower().startswith(k) for k in wifi_keywords)

                    for addr in addrs:
                        mac_family = None
                        if hasattr(psutil, 'AF_LINK'):
                            mac_family = psutil.AF_LINK
                        elif hasattr(socket, 'AF_LINK'):
                            mac_family = socket.AF_LINK
                        elif hasattr(socket, 'AF_PACKET'):
                            mac_family = socket.AF_PACKET

                        is_mac_family = (
                            (mac_family is not None and addr.family == mac_family)
                            or addr.family == 17   # Linux
                            or addr.family == -1   # Windows
                        )

                        if is_mac_family:
                            mac = addr.address.lower()
                            if mac and mac != '00:00:00:00:00:00' and len(mac) == 17:
                                if is_ethernet and not ethernet_mac:
                                    ethernet_mac = mac
                                elif is_wifi and not wifi_mac:
                                    wifi_mac = mac
                                elif not fallback_mac:
                                    fallback_mac = mac

                selected_mac = ethernet_mac or wifi_mac or fallback_mac
                if selected_mac:
                    return f"agent_{selected_mac.replace(':', '')}"

            # Fallback: uuid.getnode()
            mac = ':'.join(
                ['{:02x}'.format((uuid.getnode() >> ele) & 0xff) for ele in range(0, 8 * 6, 8)][::-1]
            )
            return f"agent_{mac.replace(':', '')}"

        except Exception:
            logger.warning("⚠️  No se pudo obtener MAC, usando ID aleatorio")
            return f"agent_{uuid.uuid4().hex[:12]}"

    # ── carga / guardado ───────────────────────────────────────────────────

    def load_from_file(self, config_file: str):
        """Cargar configuración desde archivo JSON."""
        try:
            with open(config_file, 'r') as f:
                data = json.load(f)

            if 'server_url' in data:
                # Formato antiguo
                url_match = re.match(r'ws://([^:]+):(\d+)/', data.get('server_url', ''))
                if url_match:
                    self.host = url_match.group(1)
                    self.websocket_port = url_match.group(2)
                logger.warning(
                    "Formato antiguo de configuración detectado (server_url). "
                    "Considera actualizar a host/websocket_port/http_port"
                )
            else:
                self.host = data.get('host', self.host)
                self.websocket_port = str(data.get('websocket_port', self.websocket_port))
                self.http_port = str(data.get('http_port', self.http_port))

            self.token = data.get('token', self.token)
            self.heartbeat_interval = data.get('heartbeat_interval', self.heartbeat_interval)
            self.reconnect_delay = data.get('reconnect_delay', self.reconnect_delay)
            self.auto_inventory = data.get('auto_inventory', self.auto_inventory)
            self.auto_rename = data.get('auto_rename', self.auto_rename)
            self.vnc_enabled = data.get('vnc_enabled', self.vnc_enabled)
            self.puppet_check_enabled = data.get('puppet_check_enabled', self.puppet_check_enabled)
            # print_tracking (unifica cups_audit_enabled + print_tracking_enabled)
            # compatibilidad con claves antiguas
            if 'print_tracking' in data:
                self.print_tracking = data['print_tracking']
            else:
                self.print_tracking = data.get(
                    'cups_audit_enabled',
                    data.get('print_tracking_enabled',
                             self.print_tracking))
            self.vnc_port = data.get('vnc_port', self.vnc_port)
            self.ssl_enabled = data.get('ssl_enabled', self.ssl_enabled)
            self.verify_ssl = data.get('verify_ssl', self.verify_ssl)

            logger.info(f"Configuración cargada desde {config_file}")
            logger.info(f"Servidor: {self.host}:{self.websocket_port} (WS), {self.host}:{self.http_port} (HTTP)")
            logger.info(f"Auto-inventario: {'activado' if self.auto_inventory else 'desactivado'}")
            logger.info(f"Auto-renombrado: {'activado' if self.auto_rename else 'desactivado'}")
            logger.info(f"VNC: {'activado' if self.vnc_enabled else 'desactivado'}")
            logger.info(f"Chequeo puppet: {'activado' if self.puppet_check_enabled else 'desactivado'}")

        except Exception as e:
            logger.error(f"Error cargando configuración: {e}")

    def save_to_file(self, config_file: str):
        """Guardar configuración a archivo JSON."""
        try:
            data = {
                'host': self.host,
                'websocket_port': self.websocket_port,
                'http_port': self.http_port,
                'token': self.token,
                'vnc_enabled': self.vnc_enabled,
                'vnc_port': self.vnc_port,
                'heartbeat_interval': self.heartbeat_interval,
                'reconnect_delay': self.reconnect_delay,
                'auto_inventory': self.auto_inventory,
                'auto_rename': self.auto_rename,
                'puppet_check_enabled': self.puppet_check_enabled,
                'print_tracking': self.print_tracking,
                'ssl_enabled': self.ssl_enabled,
                'verify_ssl': self.verify_ssl,
            }
            with open(config_file, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info(f"Configuración guardada en {config_file}")
        except Exception as e:
            logger.error(f"Error guardando configuración: {e}")

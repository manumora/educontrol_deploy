#!/usr/bin/env python3
"""Acciones locales del agente ejecutadas desde el backend.

Este modulo encapsula acciones de alto nivel para evitar enviar scripts
bash desde el frontend.
"""

from __future__ import annotations

import os
import pwd
import re
import shutil
import subprocess
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class ActionResult:
    success: bool
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0


@dataclass
class SessionContext:
    user: str
    uid: int
    display: str
    runtime_dir: str
    home: str
    xauthority: Optional[str]

    @property
    def env(self) -> Dict[str, str]:
        env = {
            "DISPLAY": self.display,
            "XDG_RUNTIME_DIR": self.runtime_dir,
            "DBUS_SESSION_BUS_ADDRESS": f"unix:path={self.runtime_dir}/bus",
            "PULSE_SERVER": f"unix:{self.runtime_dir}/pulse/native",
            "HOME": self.home,
            "USER": self.user,
            "LOGNAME": self.user,
        }
        if self.xauthority:
            env["XAUTHORITY"] = self.xauthority
        return env


# ── Certificate cache (module-level, shared across all AgentActions instances) ──

_PUPPET_SIGNED_DIR = Path("/opt/puppetlabs/puppet/ssl/ca/signed")

_SIG_ALG_NAMES: Dict[str, str] = {
    "1.2.840.113549.1.1.5":  "sha1WithRSAEncryption",
    "1.2.840.113549.1.1.11": "sha256WithRSAEncryption",
    "1.2.840.113549.1.1.12": "sha384WithRSAEncryption",
    "1.2.840.113549.1.1.13": "sha512WithRSAEncryption",
    "1.2.840.10045.4.3.2":   "ecdsa-with-SHA256",
    "1.2.840.10045.4.3.3":   "ecdsa-with-SHA384",
    "1.2.840.10045.4.3.4":   "ecdsa-with-SHA512",
}

_PUPPET_EXT_OID_PREFIX = "1.3.6.1.4.1.34380"

_cert_cache_lock = threading.Lock()
_cert_cache: Dict[str, object] = {
    "snapshot": None,   # frozenset of (stem, mtime_ns) — directory fingerprint
    "by_hostname": {},  # hostname -> full parsed cert dict
}


def _cert_dir_snapshot(signed_dir: Path) -> frozenset:
    """Return a frozenset fingerprint of every .pem file and its mtime_ns."""
    try:
        return frozenset(
            (p.stem, p.stat().st_mtime_ns)
            for p in signed_dir.glob("*.pem")
        )
    except OSError:
        return frozenset()


def _parse_puppet_cert(pem_file: Path) -> Dict[str, object]:
    """Parse a single PEM certificate using the cryptography library.

    Returns a dict with all fields needed by both the list and details
    endpoints so the result can be cached once and served for both.
    """
    import datetime as _dt
    from cryptography import x509 as _x509
    from cryptography.x509.oid import NameOID as _NameOID

    hostname = pem_file.stem
    cert = _x509.load_pem_x509_certificate(pem_file.read_bytes())

    # Timezone-aware dates — compatible with cryptography < 42 and >= 42
    try:
        not_valid_after = cert.not_valid_after_utc
        not_valid_before = cert.not_valid_before_utc
    except AttributeError:
        not_valid_after = cert.not_valid_after.replace(tzinfo=_dt.timezone.utc)
        not_valid_before = cert.not_valid_before.replace(tzinfo=_dt.timezone.utc)

    now = _dt.datetime.now(_dt.timezone.utc)
    status = "expired" if not_valid_after < now else "active"

    # Subject / issuer as RFC 4514 strings
    subject_str = cert.subject.rfc4514_string()
    issuer_str = cert.issuer.rfc4514_string()
    cn_attrs = cert.subject.get_attributes_for_oid(_NameOID.COMMON_NAME)
    common_name = cn_attrs[0].value if cn_attrs else hostname

    # Serial number as lowercase hex (matches openssl -serial output)
    serial_hex = format(cert.serial_number, "x")

    # Signature algorithm name from OID, with dotted-string fallback
    oid_str = cert.signature_algorithm_oid.dotted_string
    sig_alg = _SIG_ALG_NAMES.get(oid_str, oid_str)

    # Puppet-specific extensions (OID namespace 1.3.6.1.4.1.34380)
    puppet_extensions: List[str] = []
    for ext in cert.extensions:
        ext_oid = ext.oid.dotted_string
        if ext_oid.startswith(_PUPPET_EXT_OID_PREFIX):
            raw = getattr(ext.value, "value", b"")
            # DER-encoded UTF8String: first two bytes are tag (0x0C) + length
            try:
                val = raw[2:].decode("utf-8", errors="replace") if len(raw) > 2 else ""
            except Exception:
                val = ext_oid
            puppet_extensions.append(f"{ext_oid}: {val}")

    return {
        "hostname": hostname,
        "expiration": not_valid_after.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "status": status,
        # detail-only fields
        "common_name": common_name,
        "not_before": not_valid_before.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "not_after": not_valid_after.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "serial_number": serial_hex,
        "signature_algorithm": sig_alg,
        "issuer": issuer_str,
        "subject": subject_str,
        "puppet_extensions": puppet_extensions,
    }


def _load_certs_cached(signed_dir: Path) -> Dict[str, dict]:
    """Return {hostname: cert_data} from cache or freshly parsed from disk.

    The cache is invalidated automatically whenever the directory snapshot
    changes — i.e. on any add, remove, or in-place update of .pem files.
    Parsing happens outside the lock to avoid blocking concurrent callers.
    """
    current_snapshot = _cert_dir_snapshot(signed_dir)

    with _cert_cache_lock:
        if _cert_cache["snapshot"] == current_snapshot and _cert_cache["by_hostname"]:
            return _cert_cache["by_hostname"]  # type: ignore[return-value]

    # Parse outside the lock — potentially slow I/O should not block readers
    new_data: Dict[str, dict] = {}
    for pem_file in sorted(signed_dir.glob("*.pem")):
        try:
            new_data[pem_file.stem] = _parse_puppet_cert(pem_file)  # type: ignore[assignment]
        except Exception as exc:
            new_data[pem_file.stem] = {
                "hostname": pem_file.stem,
                "expiration": "",
                "status": "unknown",
                "error": str(exc),
            }

    # Re-snapshot after parsing so the stored key reflects what we actually read
    with _cert_cache_lock:
        _cert_cache["snapshot"] = _cert_dir_snapshot(signed_dir)
        _cert_cache["by_hostname"] = new_data

    return new_data


class AgentActions:
    """Implementa acciones predefinidas del agente."""

    LOCK_FILE = Path("/tmp/educontrol_input_lock_ids")
    PUPPET_BASE = Path("/etc/puppetlabs/code/environments/production")

    # ── path validation ───────────────────────────────────────────────────────

    def _puppet_resolve(self, rel_path: str) -> Path:
        """Resolve *rel_path* relative to PUPPET_BASE and validate no traversal."""
        base = self.PUPPET_BASE.resolve()
        # Strip leading slashes to treat it as relative
        rel_path = rel_path.lstrip("/")
        if rel_path:
            target = (base / rel_path).resolve()
        else:
            target = base
        if not str(target).startswith(str(base)):
            raise ValueError(f"Ruta fuera del directorio permitido: {rel_path!r}")
        return target

    # ── puppet actions ────────────────────────────────────────────────────────

    def _puppet_list_dir(self, rel_path: str) -> ActionResult:
        """Return a JSON tree of the puppet production directory."""
        import json as _json

        try:
            root = self._puppet_resolve(rel_path)
            if not root.exists():
                return ActionResult(False, stderr=f"Directorio no encontrado: {rel_path}", exit_code=1)

            def _walk(p: Path) -> dict:
                if p.is_file():
                    return {"name": p.name, "type": "file", "path": str(p.relative_to(self.PUPPET_BASE))}
                children = []
                try:
                    for child in sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
                        children.append(_walk(child))
                except PermissionError:
                    pass
                return {
                    "name": p.name,
                    "type": "directory",
                    "path": str(p.relative_to(self.PUPPET_BASE)),
                    "children": children,
                }

            if root == self.PUPPET_BASE:
                # Return list of top-level entries
                entries = []
                try:
                    for child in sorted(root.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
                        entries.append(_walk(child))
                except PermissionError as exc:
                    return ActionResult(False, stderr=str(exc), exit_code=1)
                return ActionResult(True, stdout=_json.dumps(entries), exit_code=0)
            else:
                return ActionResult(True, stdout=_json.dumps([_walk(root)]), exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_read_file(self, rel_path: str) -> ActionResult:
        """Return the raw text content of a puppet file."""
        try:
            target = self._puppet_resolve(rel_path)
            if not target.exists():
                return ActionResult(False, stderr=f"Archivo no encontrado: {rel_path}", exit_code=1)
            if not target.is_file():
                return ActionResult(False, stderr=f"La ruta no es un archivo: {rel_path}", exit_code=1)
            content = target.read_text(encoding="utf-8", errors="replace")
            return ActionResult(True, stdout=content, exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_save_file(self, rel_path: str, content: str) -> ActionResult:
        """Write *content* to a puppet file, creating parent directories as needed."""
        try:
            target = self._puppet_resolve(rel_path)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            return ActionResult(True, stdout=f"Archivo guardado: {rel_path}", exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_validate(self, rel_path: str) -> ActionResult:
        """Run syntax validation on a .pp or .yaml file."""
        try:
            target = self._puppet_resolve(rel_path)
            if not target.exists():
                return ActionResult(False, stderr=f"Archivo no encontrado: {rel_path}", exit_code=1)

            ext = target.suffix.lower()

            if ext == ".pp":
                # Buscar el binario de puppet en las rutas habituales
                import shutil as _shutil
                puppet_bin = (
                    _shutil.which("puppet")
                    or (_shutil.which("/opt/puppetlabs/bin/puppet") and "/opt/puppetlabs/bin/puppet")
                    or (Path("/opt/puppetlabs/bin/puppet").exists() and str(Path("/opt/puppetlabs/bin/puppet")))
                    or None
                )
                if not puppet_bin:
                    return ActionResult(
                        False,
                        stderr="No se encontró el ejecutable de Puppet. Asegúrate de que está instalado en /opt/puppetlabs/bin/puppet o en el PATH.",
                        exit_code=1,
                    )
                proc = subprocess.run(
                    [puppet_bin, "parser", "validate", str(target)],
                    capture_output=True, text=True, timeout=30, check=False,
                )
                combined = (proc.stdout or "").strip() + ("\n" + (proc.stderr or "").strip() if proc.stderr else "")
                if proc.returncode == 0 and not combined.strip():
                    combined = "Sintaxis válida"
                return ActionResult(
                    success=proc.returncode == 0,
                    stdout=combined.strip(),
                    stderr="",
                    exit_code=proc.returncode,
                )

            elif ext in (".yaml", ".yml"):
                ruby_script = f"require 'yaml'; YAML.load_file('{target}'); puts 'Sintaxis YAML válida'"
                proc = subprocess.run(
                    ["ruby", "-e", ruby_script],
                    capture_output=True, text=True, timeout=30, check=False,
                )
                combined = (proc.stdout or "").strip() + ("\n" + (proc.stderr or "").strip() if proc.stderr else "")
                return ActionResult(
                    success=proc.returncode == 0,
                    stdout=combined.strip(),
                    stderr="",
                    exit_code=proc.returncode,
                )

            else:
                return ActionResult(
                    False,
                    stderr=f"Tipo de archivo no soportado para validación: {ext}",
                    exit_code=1,
                )
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except subprocess.TimeoutExpired:
            return ActionResult(False, stderr="Timeout durante la validación", exit_code=1)
        except FileNotFoundError as exc:
            return ActionResult(False, stderr=f"Herramienta no encontrada: {exc}", exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_validate_all(self) -> ActionResult:
        """Run puppet parser validate on the entire production environment."""
        try:
            import shutil as _shutil
            puppet_bin = (
                _shutil.which("puppet")
                or (_shutil.which("/opt/puppetlabs/bin/puppet") and "/opt/puppetlabs/bin/puppet")
                or (Path("/opt/puppetlabs/bin/puppet").exists() and str(Path("/opt/puppetlabs/bin/puppet")))
                or None
            )
            if not puppet_bin:
                return ActionResult(
                    False,
                    stderr="No se encontró el ejecutable de Puppet. Asegúrate de que está instalado en /opt/puppetlabs/bin/puppet o en el PATH.",
                    exit_code=1,
                )
            proc = subprocess.run(
                [puppet_bin, "parser", "validate", str(self.PUPPET_BASE) + "/"],
                capture_output=True, text=True, timeout=60, check=False,
            )
            combined = (proc.stdout or "").strip() + ("\n" + (proc.stderr or "").strip() if proc.stderr else "")
            if proc.returncode == 0 and not combined.strip():
                combined = "Todos los manifests son válidos"
            return ActionResult(
                success=proc.returncode == 0,
                stdout=combined.strip(),
                stderr="",
                exit_code=proc.returncode,
            )
        except subprocess.TimeoutExpired:
            return ActionResult(False, stderr="Timeout durante la validación global", exit_code=1)
        except FileNotFoundError as exc:
            return ActionResult(False, stderr=f"Herramienta no encontrada: {exc}", exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_dependency_graph(self) -> ActionResult:
        """Parse manifests/site.pp recursively and return a dependency graph as JSON.

        Returns JSON: {nodes: [{id, label, path, group}], links: [{source, target, label}]}
        - group: 'site' | 'manifest' | 'modules' | 'modulesSec' | 'unknown'
        """
        import json as _json
        import re as _re

        base = self.PUPPET_BASE
        nodes: dict = {}   # id -> {id, label, path, group}
        links: list = []   # {source, target, label}
        visited: set = set()

        def _group_for_path(rel: str) -> str:
            if rel == "manifests/site.pp":
                return "site"
            if rel.startswith("manifests/"):
                return "manifest"
            if rel.startswith("modulesSec/"):
                return "modulesSec"
            if rel.startswith("modules/"):
                return "modules"
            return "unknown"

        def _node_id(rel: str) -> str:
            return rel.replace("/", "__").replace(".", "_")

        def _ensure_node(rel: str, label: str = "") -> str:
            nid = _node_id(rel)
            if nid not in nodes:
                nodes[nid] = {
                    "id": nid,
                    "label": label or rel.split("/")[-1],
                    "path": rel,
                    "group": _group_for_path(rel),
                }
            return nid

        def _module_path(module_name: str) -> str | None:
            """Resolve a Puppet class/module name to a relative path inside PUPPET_BASE."""
            # Strip leading ::
            name = module_name.lstrip(":")
            top = name.split("::")[0]
            for prefix in ("modules", "modulesSec"):
                candidate = base / prefix / top / "manifests" / "init.pp"
                if candidate.exists():
                    return str(candidate.relative_to(base))
            # Could be a manifest include like 'manifests/foo.pp'
            for prefix in ("modules", "modulesSec"):
                candidate = base / prefix / top / "manifests" / (name.replace("::", "/") + ".pp")
                if candidate.exists():
                    return str(candidate.relative_to(base))
            return None

        def _parse_file(rel_path: str, current_context: str = "") -> None:
            """Recursively parse a .pp file for include statements."""
            if rel_path in visited:
                return
            visited.add(rel_path)

            abs_path = base / rel_path
            if not abs_path.exists():
                return

            src_id = _ensure_node(rel_path)
            try:
                content = abs_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                return

            # Remove block comments (/* ... */)
            content_clean = _re.sub(r"/\*.*?\*/", "", content, flags=_re.DOTALL)

            # We walk line by line tracking 'case' context for labels
            context_stack: list[str] = [current_context] if current_context else [""]
            brace_depth = 0
            context_brace_depths: list[int] = []

            for line in content_clean.splitlines():
                # Strip inline comments
                stripped = _re.sub(r"#.*$", "", line).strip()

                # Detect case/if context openers to label outgoing edges
                case_match = _re.search(
                    r"(?:case\s+\$\w+\s*\{.*?'([\w.\-]+)'|'([\w.\-]+)'\s*:\s*\{)",
                    stripped,
                )
                if_match = _re.search(r"\$\w+\s*==\s*['\"]([\w.\-]+)['\"]", stripped)

                # Count braces to track context scope
                opens = stripped.count("{")
                closes = stripped.count("}")

                # Push context when a labeled block opens
                if opens > closes:
                    lbl = ""
                    if case_match:
                        lbl = case_match.group(1) or case_match.group(2) or ""
                    elif if_match:
                        lbl = if_match.group(1)
                    context_stack.append(lbl or context_stack[-1])
                    context_brace_depths.append(brace_depth)
                    brace_depth += opens - closes
                elif closes > opens:
                    brace_depth -= closes - opens
                    while context_brace_depths and brace_depth <= context_brace_depths[-1]:
                        context_brace_depths.pop()
                        context_stack.pop()

                # Find include/require/contain statements
                for kw in ("include", "require", "contain"):
                    for m in _re.finditer(
                        rf"\b{kw}\s+([:\w][\w:]*)", stripped
                    ):
                        module_name = m.group(1)
                        target_rel = _module_path(module_name)
                        if target_rel:
                            tgt_id = _ensure_node(target_rel, module_name.lstrip(":"))
                            edge_label = context_stack[-1] if context_stack else ""
                            links.append({"source": src_id, "target": tgt_id, "label": edge_label})
                            _parse_file(target_rel, "")

        try:
            entry = "manifests/site.pp"
            if not (base / entry).exists():
                return ActionResult(False, stderr="manifests/site.pp no encontrado", exit_code=1)
            _parse_file(entry)
            result = {"nodes": list(nodes.values()), "links": links}
            return ActionResult(True, stdout=_json.dumps(result), exit_code=0)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_create_dir(self, rel_path: str) -> ActionResult:
        """Create a directory inside the puppet production environment."""
        try:
            target = self._puppet_resolve(rel_path)
            target.mkdir(parents=True, exist_ok=True)
            return ActionResult(True, stdout=f"Directorio creado: {rel_path}", exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_delete(self, rel_path: str) -> ActionResult:
        """Delete a file or directory (recursive) inside the puppet environment."""
        import shutil as _shutil

        try:
            target = self._puppet_resolve(rel_path)
            if not target.exists():
                return ActionResult(False, stderr=f"Ruta no encontrada: {rel_path}", exit_code=1)
            if target == self.PUPPET_BASE:
                return ActionResult(False, stderr="No se puede eliminar el directorio raíz", exit_code=1)
            if target.is_dir():
                _shutil.rmtree(target)
            else:
                target.unlink()
            return ActionResult(True, stdout=f"Eliminado: {rel_path}", exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_rename(self, rel_path: str, new_rel_path: str) -> ActionResult:
        """Rename/move a file or directory inside the puppet environment."""
        try:
            src = self._puppet_resolve(rel_path)
            dst = self._puppet_resolve(new_rel_path)
            if not src.exists():
                return ActionResult(False, stderr=f"Origen no encontrado: {rel_path}", exit_code=1)
            if dst.exists():
                return ActionResult(False, stderr=f"El destino ya existe: {new_rel_path}", exit_code=1)
            dst.parent.mkdir(parents=True, exist_ok=True)
            src.rename(dst)
            return ActionResult(True, stdout=f"Renombrado: {rel_path} → {new_rel_path}", exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    # ── Puppet certificates ───────────────────────────────────────────────────

    def _puppet_list_certificates(self) -> ActionResult:
        """List all signed client certificates with expiration date and status.

        Returns JSON list of objects:
          {hostname, expiration, status: 'active'|'expired'}

        Parsed certificates are kept in a module-level in-memory cache and
        re-read from disk only when the contents of the signed/ directory change
        (i.e. files are added, removed, or their mtime changes).
        """
        import json as _json

        if not _PUPPET_SIGNED_DIR.exists():
            return ActionResult(False, stderr="Directorio de certificados no encontrado", exit_code=1)

        try:
            by_hostname = _load_certs_cached(_PUPPET_SIGNED_DIR)
            certs = [
                {
                    "hostname": d["hostname"],
                    "expiration": d["expiration"],
                    "status": d["status"],
                    **({
                        "error": d["error"]
                    } if "error" in d else {}),
                }
                for d in by_hostname.values()
            ]
            return ActionResult(True, stdout=_json.dumps(certs), exit_code=0)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_delete_certificate(self, hostname: str) -> ActionResult:
        """Delete a signed Puppet client certificate using puppetserver ca clean."""
        hostname = hostname.strip()
        if not hostname or "/" in hostname or "\\" in hostname or ".." in hostname:
            return ActionResult(False, stderr="Nombre de host inválido", exit_code=1)
        puppetserver_bin = "/opt/puppetlabs/bin/puppetserver"
        result = self._run([puppetserver_bin, "ca", "clean", "--certname", hostname])
        return result

    def _puppet_get_certificate_details(self, hostname: str) -> ActionResult:
        """Return detailed X.509 metadata for a signed client certificate.

        Reuses the shared certificate cache to avoid redundant disk reads when
        a listing has already been performed recently.
        """
        import json as _json

        hostname = hostname.strip()
        if not hostname or "/" in hostname or "\\" in hostname or ".." in hostname:
            return ActionResult(False, stderr="Nombre de host inválido", exit_code=1)

        cert_path = _PUPPET_SIGNED_DIR / f"{hostname}.pem"
        if not cert_path.exists():
            return ActionResult(False, stderr=f"Certificado no encontrado: {hostname}", exit_code=1)

        try:
            by_hostname = _load_certs_cached(_PUPPET_SIGNED_DIR)
            cached = by_hostname.get(hostname)
            if cached and "common_name" in cached:
                data = cached
            else:
                # Cache miss or error entry — parse the single file directly
                data = _parse_puppet_cert(cert_path)  # type: ignore[assignment]

            payload = {
                k: data[k]
                for k in (
                    "hostname", "common_name", "not_before", "not_after",
                    "serial_number", "signature_algorithm", "issuer",
                    "subject", "puppet_extensions",
                )
                if k in data
            }
            return ActionResult(True, stdout=_json.dumps(payload), exit_code=0)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    # ── Puppet reports ────────────────────────────────────────────────────────

    def _puppet_list_reports(self) -> ActionResult:
        """Return a shallow summary list (hostname, status, timestamp) for the latest
        Puppet report of each client node.

        Fast path — NO yaml.safe_load:
        * Latest file is found by OS mtime (no sorting of filenames).
        * status is extracted by scanning only the first 60 lines of the file.
        * timestamp comes from OS mtime to avoid any date-string parsing.
        """
        import json as _json
        import re as _re
        import datetime as _dt

        reports_base = Path("/opt/puppetlabs/server/data/puppetserver/reports")
        if not reports_base.exists():
            return ActionResult(False, stderr="Directorio de informes no encontrado", exit_code=1)

        _status_re = _re.compile(r"^status:\s*['\"]?(\w+)['\"]?", _re.MULTILINE)

        summaries = []
        try:
            for node_dir in sorted(reports_base.iterdir()):
                if not node_dir.is_dir():
                    continue
                hostname = node_dir.name

                # Pick newest .yaml by mtime — single os.scandir pass, no sorting
                latest: "Path | None" = None
                latest_mtime: float = -1.0
                for entry in node_dir.iterdir():
                    if entry.suffix == ".yaml":
                        mt = entry.stat().st_mtime
                        if mt > latest_mtime:
                            latest_mtime = mt
                            latest = entry
                if latest is None:
                    continue

                # Extract status from first 60 lines only (avoids loading megabytes)
                status_val = "unknown"
                try:
                    with latest.open("r", encoding="utf-8", errors="replace") as fh:
                        head = "".join(fh.readline() for _ in range(60))
                    m = _status_re.search(head)
                    if m:
                        status_val = m.group(1)
                except Exception:
                    pass

                # Timestamp from OS mtime
                ts = _dt.datetime.fromtimestamp(latest_mtime, tz=_dt.timezone.utc).strftime(
                    "%Y-%m-%dT%H:%M:%SZ"
                )

                summaries.append(
                    {
                        "hostname": hostname,
                        "status": status_val,
                        "timestamp": ts,
                        "report_file": latest.name,
                    }
                )
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

        return ActionResult(True, stdout=_json.dumps(summaries), exit_code=0)

    def _puppet_get_report_details(self, hostname: str, report_file: str) -> ActionResult:
        """Return the full parsed content of a specific Puppet report YAML file.
        Called lazily only when the user opens the detail dialog.
        """
        return self._puppet_get_report(hostname, report_file)

    def _puppet_get_report(self, hostname: str, report_file: str) -> ActionResult:
        """Return the full content of a specific Puppet report YAML file."""
        hostname = hostname.strip()
        report_file = report_file.strip()

        # Validate: no path traversal
        if not hostname or "/" in hostname or ".." in hostname:
            return ActionResult(False, stderr="Nombre de host inválido", exit_code=1)
        if not report_file.endswith(".yaml") or "/" in report_file or ".." in report_file:
            return ActionResult(False, stderr="Nombre de fichero de informe inválido", exit_code=1)

        import json as _json

        report_path = Path(f"/opt/puppetlabs/server/data/puppetserver/reports/{hostname}/{report_file}")
        if not report_path.exists():
            return ActionResult(False, stderr=f"Informe no encontrado: {report_file}", exit_code=1)

        try:
            import yaml as _yaml  # type: ignore[import]
        except ImportError:
            return ActionResult(False, stderr="PyYAML no disponible en el agente", exit_code=1)

        # Build a loader that silently handles Ruby-specific YAML tags
        # (e.g. !ruby/object:Puppet::Transaction::Report) by treating them
        # as plain mappings, sequences, or scalars.
        class _RubyLoader(_yaml.SafeLoader):
            pass

        def _ruby_object_constructor(loader: _yaml.SafeLoader, tag_suffix: str, node: _yaml.Node):
            if isinstance(node, _yaml.MappingNode):
                return loader.construct_mapping(node, deep=True)
            if isinstance(node, _yaml.SequenceNode):
                return loader.construct_sequence(node, deep=True)
            return loader.construct_scalar(node)  # type: ignore[arg-type]

        _RubyLoader.add_multi_constructor("", _ruby_object_constructor)

        try:
            with report_path.open("r", encoding="utf-8", errors="replace") as fh:
                data = _yaml.load(fh, Loader=_RubyLoader)  # noqa: S506 — custom safe loader

            # Flatten into a serialisable dict — replace non-serialisable objects with their str()
            def _safe(obj, depth=0):
                if depth > 8:
                    return str(obj)
                if isinstance(obj, dict):
                    return {str(k): _safe(v, depth + 1) for k, v in obj.items()}
                if isinstance(obj, (list, tuple)):
                    return [_safe(i, depth + 1) for i in obj]
                try:
                    _json.dumps(obj)
                    return obj
                except (TypeError, ValueError):
                    return str(obj)

            return ActionResult(True, stdout=_json.dumps(_safe(data)), exit_code=0)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_delete_report(self, hostname: str) -> ActionResult:
        """Delete the full report directory for a given report node."""
        import shutil as _shutil

        hostname = hostname.strip()
        if not hostname or "/" in hostname or "\\" in hostname or ".." in hostname:
            return ActionResult(False, stderr="Nombre de report inválido", exit_code=1)

        reports_base = Path("/opt/puppetlabs/server/data/puppetserver/reports")
        target = reports_base / hostname
        if not target.exists():
            return ActionResult(False, stderr=f"Carpeta de report no encontrada: {hostname}", exit_code=1)
        if not target.is_dir():
            return ActionResult(False, stderr=f"La ruta no es una carpeta: {hostname}", exit_code=1)

        try:
            _shutil.rmtree(target)
            return ActionResult(True, stdout=f"Carpeta de report eliminada: {hostname}", exit_code=0)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def execute(self, action: str, params: Optional[Dict] = None) -> ActionResult:
        params = params or {}

        try:
            if action == "mute":
                return self._set_mute(bool(params.get("mute", True)))
            if action == "input_lock":
                return self._set_input_lock(bool(params.get("lock", True)))
            if action == "launch_url":
                url = str(params.get("url", "")).strip()
                if not url:
                    return ActionResult(False, stderr="URL vacia", exit_code=1)
                return self._launch_url(url)
            # Puppet file manager actions
            if action == "puppet_list_dir":
                return self._puppet_list_dir(str(params.get("path", "")))
            if action == "puppet_read_file":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                return self._puppet_read_file(path)
            if action == "puppet_save_file":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                content = params.get("content", "")
                return self._puppet_save_file(path, str(content))
            if action == "puppet_validate":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                return self._puppet_validate(path)
            if action == "puppet_validate_all":
                return self._puppet_validate_all()
            if action == "puppet_dependency_graph":
                return self._puppet_dependency_graph()
            if action == "puppet_create_dir":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                return self._puppet_create_dir(path)
            if action == "puppet_delete":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                return self._puppet_delete(path)
            if action == "puppet_rename":
                path = str(params.get("path", "")).strip()
                new_path = str(params.get("new_path", "")).strip()
                if not path or not new_path:
                    return ActionResult(False, stderr="Parámetros 'path' y 'new_path' requeridos", exit_code=1)
                return self._puppet_rename(path, new_path)
            if action == "puppet_list_certificates":
                return self._puppet_list_certificates()
            if action == "puppet_delete_certificate":
                hostname = str(params.get("hostname", "")).strip()
                if not hostname:
                    return ActionResult(False, stderr="Parámetro 'hostname' requerido", exit_code=1)
                return self._puppet_delete_certificate(hostname)
            if action == "puppet_get_certificate_details":
                hostname = str(params.get("hostname", "")).strip()
                if not hostname:
                    return ActionResult(False, stderr="Parámetro 'hostname' requerido", exit_code=1)
                return self._puppet_get_certificate_details(hostname)
            if action == "puppet_list_reports":
                return self._puppet_list_reports()
            if action == "puppet_delete_report":
                hostname = str(params.get("hostname", "")).strip()
                if not hostname:
                    return ActionResult(False, stderr="Parámetro 'hostname' requerido", exit_code=1)
                return self._puppet_delete_report(hostname)
            if action in ("puppet_get_report", "puppet_get_report_details"):
                hostname = str(params.get("hostname", "")).strip()
                report_file = str(params.get("report_file", "")).strip()
                if not hostname or not report_file:
                    return ActionResult(False, stderr="Parámetros 'hostname' y 'report_file' requeridos", exit_code=1)
                return self._puppet_get_report(hostname, report_file)
            return ActionResult(False, stderr=f"Accion no soportada: {action}", exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _run(
        self,
        cmd: List[str],
        *,
        as_user: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
        background: bool = False,
    ) -> ActionResult:
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)

        def build_runuser_cmd() -> List[str]:
            env_parts = [f"{k}={v}" for k, v in (env or {}).items()]
            return ["runuser", "-u", as_user, "--", "env", *env_parts, *cmd]

        # Caso 1: Background con runuser (lanzar proceso como otro usuario en background)
        if background and as_user and os.geteuid() == 0 and shutil.which("runuser"):
            try:
                real_cmd = build_runuser_cmd()
                subprocess.Popen(
                    real_cmd,
                    env=merged_env,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
                return ActionResult(True, stdout="Proceso lanzado en background", exit_code=0)
            except OSError as exc:
                return ActionResult(False, stderr=str(exc), exit_code=1)

        # Caso 2: Background sin runuser (lanzar proceso simple en background)
        if background:
            try:
                subprocess.Popen(
                    cmd,
                    env=merged_env,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
                return ActionResult(True, stdout="Proceso lanzado", exit_code=0)
            except OSError as exc:
                return ActionResult(False, stderr=str(exc), exit_code=1)

        # Caso 3: Foreground con runuser
        if as_user and os.geteuid() == 0 and shutil.which("runuser"):
            real_cmd = build_runuser_cmd()
            proc = subprocess.run(real_cmd, env=merged_env, capture_output=True, text=True, check=False)
        else:
            # Caso 4: Foreground simple
            proc = subprocess.run(cmd, env=merged_env, capture_output=True, text=True, check=False)

        return ActionResult(
            success=proc.returncode == 0,
            stdout=(proc.stdout or "").strip(),
            stderr=(proc.stderr or "").strip(),
            exit_code=proc.returncode,
        )

    def _find_graphical_session(self) -> Optional[SessionContext]:
        if not shutil.which("loginctl"):
            return None

        list_proc = subprocess.run(
            ["loginctl", "list-sessions", "--no-legend"],
            capture_output=True,
            text=True,
            check=False,
        )
        if list_proc.returncode != 0:
            return None

        candidates: List[SessionContext] = []

        for line in list_proc.stdout.splitlines():
            parts = line.split()
            if not parts:
                continue
            sid = parts[0]

            def prop(session_id: str, name: str) -> str:
                p = subprocess.run(
                    ["loginctl", "show-session", session_id, "-p", name, "--value"],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                return (p.stdout or "").strip()

            user_id = prop(sid, "User")
            user_name = prop(sid, "Name")
            session_type = prop(sid, "Type")
            session_class = prop(sid, "Class")
            session_state = prop(sid, "State")
            session_remote = prop(sid, "Remote")
            display = prop(sid, "Display")
            tty = prop(sid, "TTY")

            if not user_id.isdigit() or int(user_id) < 1000:
                continue
            # Nunca usar sesiones greeter (gdm/sddm/lightdm), no son el usuario autenticado.
            if session_class != "user":
                continue
            if session_type not in {"x11", "wayland"}:
                continue
            if session_state not in {"active", "online"}:
                continue
            if session_remote == "yes":
                continue
            if user_name in {"gdm", "sddm", "lightdm"}:
                continue

            if not display:
                if tty in {"tty7", "tty1"}:
                    display = ":0"
                elif tty in {"tty8", "tty2"}:
                    display = ":1"
                else:
                    display = ":0"

            uid = int(user_id)
            runtime_dir = f"/run/user/{uid}"
            home = pwd.getpwnam(user_name).pw_dir

            xauth_candidates = [
                f"{runtime_dir}/gdm/Xauthority",
                f"{home}/.Xauthority",
            ]
            xauth = next((path for path in xauth_candidates if os.path.exists(path)), None)

            candidates.append(SessionContext(
                user=user_name,
                uid=uid,
                display=display,
                runtime_dir=runtime_dir,
                home=home,
                xauthority=xauth,
            ))

        if candidates:
            # Priorizamos la primera sesión de usuario válida que devuelve logind.
            return candidates[0]

        return None

    def _set_mute(self, mute: bool) -> ActionResult:
        mute_value = "1" if mute else "0"
        amixer_action = "mute" if mute else "unmute"

        applied = False
        messages: List[str] = []

        session = self._find_graphical_session()
        if session:
            for cmd in (
                ["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", mute_value],
                ["pactl", "set-sink-mute", "@DEFAULT_SINK@", mute_value],
                ["amixer", "-D", "pulse", "sset", "Master", amixer_action],
            ):
                if not shutil.which(cmd[0]):
                    continue
                res = self._run(cmd, as_user=session.user, env=session.env)
                if res.success:
                    applied = True
                    messages.append(f"Aplicado con {cmd[0]} en sesion de usuario")
                    break

        if not applied and shutil.which("amixer"):
            controls = ["Master", "PCM", "Speaker", "Headphone", "Front"]
            for ctl in controls:
                res = self._run(["amixer", "sset", ctl, amixer_action])
                if res.success:
                    applied = True
            for card in range(10):
                info = self._run(["amixer", "-c", str(card), "info"])
                if not info.success:
                    continue
                for ctl in controls:
                    res = self._run(["amixer", "-c", str(card), "sset", ctl, amixer_action])
                    if res.success:
                        applied = True
            if applied:
                messages.append("Aplicado via ALSA")

        if not applied:
            return ActionResult(False, stderr="No se pudo aplicar mute/unmute", exit_code=1)

        return ActionResult(True, stdout="; ".join(messages) or "Mute aplicado", exit_code=0)

    def _list_xinput_ids(self, session: SessionContext) -> List[str]:
        res = self._run(["xinput", "--list", "--short"], as_user=session.user, env=session.env)
        if not res.success:
            return []
        ids: List[str] = []
        for line in res.stdout.splitlines():
            low = line.lower()
            if "slave" not in low:
                continue
            if "pointer" not in low and "keyboard" not in low:
                continue
            if "xtest" in low or "virtual core" in low:
                continue
            match = re.search(r"\bid=(\d+)\b", line)
            if match:
                ids.append(match.group(1))
        return ids

    def _set_input_lock(self, lock: bool) -> ActionResult:
        if not shutil.which("xinput"):
            return ActionResult(False, stderr="xinput no disponible", exit_code=1)

        session = self._find_graphical_session()
        if not session:
            return ActionResult(False, stderr="No se detecto sesion grafica activa", exit_code=1)

        if lock:
            ids = self._list_xinput_ids(session)
            if not ids:
                return ActionResult(False, stderr="No se encontraron dispositivos para bloquear", exit_code=1)

            locked: List[str] = []
            for dev_id in ids:
                res = self._run(["xinput", "--disable", dev_id], as_user=session.user, env=session.env)
                if res.success:
                    locked.append(dev_id)

            if not locked:
                return ActionResult(False, stderr="No se pudo bloquear ningun dispositivo", exit_code=1)

            self.LOCK_FILE.write_text("\n".join(locked), encoding="utf-8")
            return ActionResult(True, stdout=f"Bloqueados {len(locked)} dispositivos", exit_code=0)

        if not self.LOCK_FILE.exists():
            return ActionResult(False, stderr="No hay bloqueo registrado", exit_code=1)

        ids = [line.strip() for line in self.LOCK_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]
        for dev_id in ids:
            self._run(["xinput", "--enable", dev_id], as_user=session.user, env=session.env)
        try:
            self.LOCK_FILE.unlink(missing_ok=True)
        except Exception:
            pass

        return ActionResult(True, stdout="Teclado y raton desbloqueados", exit_code=0)

    def _launch_url(self, url: str) -> ActionResult:
        session = self._find_graphical_session()
        if not session:
            return ActionResult(False, stderr="No se detecto sesion grafica activa", exit_code=1)

        browser = shutil.which("google-chrome") or shutil.which("chromium-browser") or shutil.which("chromium")
        if not browser:
            return ActionResult(False, stderr="No se encontro Chrome/Chromium instalado", exit_code=1)

        # Usar el entorno completo de sesión para DBus/Pulse/XDG además de DISPLAY.
        launch_env = dict(session.env)
        # Evitar enviar XAUTHORITY vacío explícito.
        if not session.xauthority:
            launch_env.pop("XAUTHORITY", None)

        attempts: List[List[str]] = [[browser, "--new-window", url], [browser, url]]
        if shutil.which("xdg-open"):
            attempts.append(["xdg-open", url])
        if shutil.which("gio"):
            attempts.append(["gio", "open", url])

        last_error = ""
        # Primer pase: entorno completo
        for cmd in attempts:
            res = self._run(cmd, as_user=session.user, env=launch_env, background=True)
            if res.success:
                return ActionResult(
                    True,
                    stdout=(
                        f"URL lanzada con {' '.join(cmd[:2])} "
                        f"(user={session.user}, display={session.display})"
                    ),
                    exit_code=0,
                )
            last_error = res.stderr or f"exit_code={res.exit_code}"

        # Segundo pase: sin XAUTHORITY explícito
        if "XAUTHORITY" in launch_env:
            launch_env.pop("XAUTHORITY", None)
            for cmd in attempts:
                res = self._run(cmd, as_user=session.user, env=launch_env, background=True)
                if res.success:
                    return ActionResult(
                        True,
                        stdout=(
                            f"URL lanzada sin XAUTHORITY con {' '.join(cmd[:2])} "
                            f"(user={session.user}, display={session.display})"
                        ),
                        exit_code=0,
                    )
                last_error = res.stderr or f"exit_code={res.exit_code}"

        return ActionResult(
            False,
            stderr=(
                "No se pudo abrir navegador "
                f"(user={session.user}, display={session.display}, browser={browser}): {last_error}"
            ),
            exit_code=1,
        )

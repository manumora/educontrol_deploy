"""
print_tracker.py — Monitor en tiempo real de impresiones CUPS para EduControl Agent.

Utiliza inotify para observar el directorio /var/log/cups/ y parsea el archivo
page_log para enviar cada trabajo de impresión al servidor EduControl.
"""

import logging
import os
import re
import threading
import time
from datetime import datetime
from typing import Optional

logger = logging.getLogger('EduControlAgent')

# ── dependencias opcionales ──────────────────────────────────────────────────

try:
    from inotify_simple import Watcher, flags
    INOTIFY_AVAILABLE = True
except ImportError:
    INOTIFY_AVAILABLE = False

try:
    import cups
    PYCUPS_AVAILABLE = True
except ImportError:
    PYCUPS_AVAILABLE = False

# ── constantes ───────────────────────────────────────────────────────────────

PAGE_LOG_DIR = '/var/log/cups/'
PAGE_LOG_FILE = os.path.join(PAGE_LOG_DIR, 'page_log')
MAX_PROCESSED_JOBS = 1000  # límite para evitar fugas de memoria

# Regex para la línea CUPS:
#   <Printer> <User> <Job_ID> [<Date>] total <Total_Sheets> <Host> <Document_Name>
LINE_RE = re.compile(
    r'^(\S+)\s+(\S+)\s+(\d+)\s+\[(.*?)\]\s+total\s+(\d+)\s+(\S+)\s+(.*)$'
)


class PrintTracker:
    """Monitoriza /var/log/cups/page_log y envía registros al backend."""

    def __init__(self, config):
        """
        Args:
            config: instancia de AgentConfig con http_url, token, agent_id,
                    verify_ssl, hostname y print_tracking.
        """
        self.config = config
        self._stop_event = threading.Event()
        self._processed_jobs: set = set()
        self._lock = threading.Lock()

    # ── helpers privados ─────────────────────────────────────────────────────

    def _get_copies(self, job_id: int) -> int:
        """
        Consulta el servidor CUPS local para obtener el número de copias
        del trabajo.

        Returns:
            Número de copias (1 como fallback si pycups falla).
        """
        if not PYCUPS_AVAILABLE:
            return 1

        try:
            conn = cups.Connection()
            job = conn.getJob(job_id)
            # cupsJobKeys puede variar; intentamos las claves más comunes.
            copies = 1
            for key in ('number-up', 'copies', 'number-of-copies'):
                if key in job:
                    try:
                        copies = int(job[key])
                        break
                    except (ValueError, TypeError):
                        pass
            return max(copies, 1)
        except Exception as e:
            logger.debug(f"PrintTracker: no se pudo consultar Job {job_id} en CUPS: {e}")
            return 1

    def _send_print_log(self, data: dict) -> bool:
        """
        Envía un registro de impresión al servidor EduControl vía HTTP POST.

        Returns:
            True si el servidor respondió con 2xx.
        """
        try:
            import requests as _requests

            url = f"{self.config.http_url}/api/print-logs/create/"
            headers = {'Content-Type': 'application/json'}
            if self.config.token:
                headers['Authorization'] = f'Token {self.config.token}'

            payload = {
                'agent_id': self.config.agent_id,
                'hostname': self.config.hostname,
                **data,
            }

            resp = _requests.post(
                url, json=payload, headers=headers,
                timeout=10, verify=self.config.verify_ssl,
            )
            if resp.status_code == 201:
                logger.info(f"PrintTracker: envío OK — {data.get('user')}/{data.get('document_name')} en {data.get('printer_name')}")
                return True
            else:
                logger.warning(
                    f"PrintTracker: fallo al enviar (HTTP {resp.status_code}): {resp.text[:200]}"
                )
                return False
        except ImportError:
            logger.warning("PrintTracker: requests no disponible, no se puede enviar registro")
            return False
        except Exception as e:
            logger.warning(f"PrintTracker: error al enviar registro: {e}")
            return False

    def _add_job(self, job_id: int):
        """Marca un job_id como procesado, descartando los más antiguos si el set crece."""
        with self._lock:
            if len(self._processed_jobs) >= MAX_PROCESSED_JOBS:
                # Eliminar la mitad más antigua para mantener el set acotado.
                to_remove = set(list(self._processed_jobs)[:MAX_PROCESSED_JOBS // 2])
                self._processed_jobs -= to_remove
            self._processed_jobs.add(job_id)

    def _is_processed(self, job_id: int) -> bool:
        """Comprueba si un job_id ya fue procesado."""
        with self._lock:
            return job_id in self._processed_jobs

    def _parse_and_send(self, filepath: str):
        """
        Lee las nuevas líneas del archivo, parsea y envía cada registro.
        """
        try:
            with open(filepath, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or 'total' not in line:
                        continue

                    m = LINE_RE.match(line)
                    if not m:
                        continue

                    printer_name = m.group(1)
                    user = m.group(2)
                    job_id = int(m.group(3))
                    date_str = m.group(4)
                    total_sheets = int(m.group(5))
                    host = m.group(6)
                    document_name = m.group(7).strip()

                    if self._is_processed(job_id):
                        continue

                    # Calcular páginas del documento
                    copies = self._get_copies(job_id)
                    document_pages = total_sheets // copies if copies > 0 else total_sheets

                    # Intentar parsear la fecha de CUPS; fallback a now()
                    timestamp = datetime.now().isoformat()
                    try:
                        dt = datetime.strptime(date_str, '%d/%b/%Y:%H:%M:%S %z')
                        timestamp = dt.isoformat()
                    except ValueError:
                        pass

                    self._send_print_log({
                        'user': user,
                        'printer_name': printer_name,
                        'document_name': document_name,
                        'copies': copies,
                        'document_pages': document_pages,
                        'total_sheets': total_sheets,
                        'timestamp': timestamp,
                    })

                    self._add_job(job_id)

        except OSError as e:
            logger.warning(f"PrintTracker: error leyendo {filepath}: {e}")

    def _watch(self):
        """
        Bucle principal del hilo: inicializa inotify y espera eventos en el
        directorio de logs.
        """
        if not os.path.isdir(PAGE_LOG_DIR):
            logger.warning(f"PrintTracker: directorio {PAGE_LOG_DIR} no existe; omitiendo")
            return

        # Si el archivo ya existe y tiene contenido, procesarlo antes de vigilar.
        if os.path.isfile(PAGE_LOG_FILE):
            logger.info("PrintTracker: procesando registros previos de page_log...")
            self._parse_and_send(PAGE_LOG_FILE)

        logger.info("PrintTracker: iniciando watcher en %s", PAGE_LOG_DIR)

        while not self._stop_event.is_set():
            try:
                watcher = Watcher()
                watcher.add_watch(PAGE_LOG_DIR, flags.MODIFY | flags.CREATE)

                while not self._stop_event.is_set():
                    events = watcher.event(timeout=1000)  # 1 s de timeout

                    for event in events:
                        # Ignorar eventos de directorio o de ignorar
                        if 'ISDIR' in event.mask_names or 'IGNORE' in event.mask_names:
                            continue

                        # Filtrar para el archivo page_log (event.name es el nombre del archivo)
                        if event.name and 'page_log' in event.name:
                            time.sleep(0.1)  # dejar que CUPS termine de escribir
                            if os.path.isfile(PAGE_LOG_FILE):
                                self._parse_and_send(PAGE_LOG_FILE)

            except Exception as e:
                logger.warning(f"PrintTracker: error en watcher: {e}")
                if self._stop_event.is_set():
                    break
                time.sleep(3)

    # ── control del hilo ────────────────────────────────────────────────────

    def start(self):
        """Inicia el hilo de monitoreo de impresiones."""
        if not INOTIFY_AVAILABLE:
            logger.warning("PrintTracker: inotify_simple no disponible; monitoreo desactivado")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._watch, daemon=True, name='PrintTracker')
        self._thread.start()
        logger.info("PrintTracker: hilo iniciado")

    def stop(self):
        """Detiene el hilo de monitoreo."""
        self._stop_event.set()
        if hasattr(self, '_thread') and self._thread.is_alive():
            self._thread.join(timeout=5)
        logger.info("PrintTracker: hilo detenido")

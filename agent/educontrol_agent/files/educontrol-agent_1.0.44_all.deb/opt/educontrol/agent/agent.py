#!/usr/bin/env python3
"""
EduControl Remote Agent
=======================

Agente remoto que se ejecuta en equipos de la red para recibir y ejecutar
comandos desde el servidor Django vía WebSocket.

Características:
- Conexión WebSocket persistente con reconexión automática
- Ejecución de comandos con salida en tiempo real línea por línea
- Identificación única por hostname y MAC address
- Logs detallados de todas las operaciones

Uso:
    python agent.py --server ws://localhost:8003 --token <token>
    python agent.py --config config.json
"""

import argparse
import asyncio
import json
import logging
import platform
import socket
import ssl
import subprocess
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

# Asegura imports locales (logging_setup, config, etc.) cuando systemd usa otro cwd.
AGENT_DIR = Path(__file__).resolve().parent
if str(AGENT_DIR) not in sys.path:
    sys.path.insert(0, str(AGENT_DIR))


try:
    import websockets
except ImportError:
    print("ERROR: websockets no está instalado. Ejecuta: pip install websockets")
    sys.exit(1)

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("⚠️  psutil no disponible. Funcionalidades de inventario limitadas.")

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    print("⚠️  requests no disponible. Inventario no se enviará al servidor.")

# Importar LoginMonitor desde módulo separado
try:
    from login_monitor import LoginMonitor
    LOGIN_MONITOR_AVAILABLE = True
except ImportError as e:
    LOGIN_MONITOR_AVAILABLE = False
    print(f"⚠️  LoginMonitor no disponible: {e}")

# ── módulos internos ──────────────────────────────────────────────────────────
from logging_setup import setup_logging
from config import AgentConfig
from vnc_manager import VNCManager
from command_executor import CommandExecutor
from terminal_handler import TerminalHandler
from inventory import collect_system_inventory
from battery import collect_battery_status
from puppet_manager import PuppetManager
from cups_manager import CUPSManager
from print_tracker import PrintTracker
from actions import AgentActions
from screenshot_streamer import ScreenshotStreamer
from password_prompt import PasswordChangePrompter

# Configurar logging (nivel por defecto INFO; main() lo ajusta si el usuario pide DEBUG)
logger = setup_logging()


# ═════════════════════════════════════════════════════════════════════════════
# RemoteAgent
# ═════════════════════════════════════════════════════════════════════════════

class RemoteAgent:
    """Agente remoto principal – orquesta todos los submódulos."""

    def __init__(self, config: AgentConfig):
        self.config = config
        self.websocket: Optional[websockets.WebSocketClientProtocol] = None
        self.executor: Optional[CommandExecutor] = None
        self.terminals: dict[str, TerminalHandler] = {}
        self.login_monitor = None
        self.vnc_manager: Optional[VNCManager] = None
        self.puppet_manager = PuppetManager(config)
        self.cups_manager = CUPSManager(config)
        self.print_tracker = PrintTracker(config)
        self.actions = AgentActions()
        self.screenshot_streamer = ScreenshotStreamer(actions=self.actions)
        self.password_prompter = PasswordChangePrompter(config, self.actions)
        self.running = False
        self.reconnect_attempts = 0
        self.last_battery_report = 0.0

    async def _execute_action(self, command_id: str, action: str, params: dict):
        """Ejecutar una accion predefinida del agente y reportar resultado."""
        start_time = time.time()
        result = await asyncio.to_thread(self.actions.execute, action, params)
        execution_time = round(time.time() - start_time, 2)

        if result.stdout:
            await self.send_json({
                'type': 'command_output',
                'command_id': command_id,
                'output': result.stdout,
                'stream': 'stdout',
            })

        if result.stderr:
            await self.send_json({
                'type': 'command_output',
                'command_id': command_id,
                'output': result.stderr,
                'stream': 'stderr',
            })

        await self.send_json({
            'type': 'command_complete',
            'command_id': command_id,
            'exit_code': result.exit_code,
            'execution_time': execution_time,
            'stdout': result.stdout,
            'stderr': result.stderr,
        })

    # ── información del sistema ───────────────────────────────────────────────

    def get_system_info(self) -> dict:
        return {
            'os': platform.system(),
            'os_version': platform.version(),
            'platform': platform.platform(),
            'python_version': platform.python_version(),
            'processor': platform.processor(),
            'hostname': self.config.hostname,
            'agent_id': self.config.agent_id,
        }

    def get_ip_address(self) -> str:
        try:
            port = int(self.config.websocket_port) if self.config.websocket_port.isdigit() else 8003
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect((self.config.host, port))
                return s.getsockname()[0]
        except Exception:
            return "unknown"

    def get_mac_address(self) -> Optional[str]:
        """Obtener MAC address principal del sistema."""
        try:
            if PSUTIL_AVAILABLE:
                network_interfaces = psutil.net_if_addrs()
                interfaces = sorted(network_interfaces.keys())
                wired_patterns = ['eno', 'ens', 'enp', 'eth', 'enx', 'ethernet']
                wifi_patterns = ['wlan', 'wifi', 'wl']

                def has_ip(iface_addrs):
                    for addr in iface_addrs:
                        if addr.family == socket.AF_INET and not addr.address.startswith('127.'):
                            return True
                    return False

                # 1. Wired con IP
                for pattern in wired_patterns:
                    for iface in interfaces:
                        if iface.lower().startswith(pattern):
                            addrs = network_interfaces[iface]
                            if has_ip(addrs):
                                for addr in addrs:
                                    if addr.family == psutil.AF_LINK:
                                        mac = addr.address.upper()
                                        if mac and mac != '00:00:00:00:00:00':
                                            return mac
                # 2. WiFi con IP
                for pattern in wifi_patterns:
                    for iface in interfaces:
                        if iface.lower().startswith(pattern):
                            addrs = network_interfaces[iface]
                            if has_ip(addrs):
                                for addr in addrs:
                                    if addr.family == psutil.AF_LINK:
                                        mac = addr.address.upper()
                                        if mac and mac != '00:00:00:00:00:00':
                                            return mac
                # 3. Cualquier Wired
                for pattern in wired_patterns:
                    for iface in interfaces:
                        if iface.lower().startswith(pattern):
                            for addr in network_interfaces[iface]:
                                if addr.family == psutil.AF_LINK:
                                    mac = addr.address.upper()
                                    if mac and mac != '00:00:00:00:00:00':
                                        return mac
                # 4. Cualquier MAC válida
                for iface, addrs in network_interfaces.items():
                    if iface.lower() in ['lo', 'loopback'] or iface.lower().startswith(
                            ('veth', 'br-', 'docker', 'virbr')):
                        continue
                    for addr in addrs:
                        if addr.family == psutil.AF_LINK:
                            mac = addr.address.upper()
                            if mac and mac != '00:00:00:00:00:00':
                                return mac

            mac = ':'.join(
                ['{:02x}'.format((uuid.getnode() >> ele) & 0xff) for ele in range(0, 8 * 6, 8)][::-1]
            )
            return mac.upper() if mac else None

        except Exception as e:
            logger.error(f"Error obteniendo MAC address: {e}")
            return None

    # ── renombrado de hostname ────────────────────────────────────────────────

    def rename_hostname(self, new_hostname: str) -> bool:
        """Renombrar el hostname del sistema (solo Linux)."""
        try:
            if platform.system() != 'Linux':
                logger.warning(f"Renombrado de hostname solo soportado en Linux")
                return False

            result = subprocess.run(
                ['hostnamectl', 'set-hostname', new_hostname],
                capture_output=True, text=True, check=False,
            )
            if result.returncode == 0:
                logger.info(f"✅ Hostname renombrado a: {new_hostname}")
                try:
                    with open('/etc/hostname', 'w') as f:
                        f.write(new_hostname + '\n')
                except Exception as e:
                    logger.warning(f"No se pudo actualizar /etc/hostname: {e}")
                return True
            else:
                logger.error(f"Error renombrando hostname: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"Error renombrando hostname: {e}")
            return False

    async def check_and_rename_hostname(self):
        """Verificar y aplicar renombrado del hostname al inicio del agente."""
        if not self.config.auto_rename:
            logger.debug("Auto-renombrado desactivado")
            return
        if platform.system() != 'Linux':
            logger.debug(f"Auto-renombrado solo disponible en Linux")
            return
        if not REQUESTS_AVAILABLE:
            logger.warning("⚠️  requests no disponible, no se puede verificar renombrado")
            return

        mac = self.get_mac_address()
        if not mac:
            logger.warning("⚠️  No se pudo obtener MAC address")
            return

        current_hostname = self.config.hostname
        headers = {'Content-Type': 'application/json'}
        if self.config.token:
            headers['Authorization'] = f'Token {self.config.token}'

        logger.info(f"🔍 Verificando autorenombrado: MAC={mac}, Hostname actual={current_hostname}")

        # Fase 1: LDAP
        ldap_registered = False
        try:
            check_url = f"{self.config.http_url}/api/hosts/agent/check-rename/"
            response = requests.post(
                check_url,
                json={'mac': mac, 'hostname': current_hostname},
                headers=headers, timeout=10, verify=self.config.verify_ssl,
            )
            if response.status_code == 200:
                data = response.json()
                ldap_registered = data.get('registered', False)
                if ldap_registered:
                    if data.get('should_rename'):
                        target_hostname = data.get('target_hostname')
                        logger.info(f"📝 [LDAP] Renombrando de '{current_hostname}' a '{target_hostname}'")
                        if self.rename_hostname(target_hostname):
                            self.config.hostname = target_hostname
                            try:
                                notify_url = f"{self.config.http_url}/api/hosts/agent/notify-rename/"
                                requests.post(
                                    notify_url,
                                    json={
                                        'agent_id': self.config.agent_id,
                                        'mac': mac,
                                        'old_hostname': current_hostname,
                                        'new_hostname': target_hostname,
                                        'ip_address': self.get_ip_address(),
                                    },
                                    headers=headers, timeout=10, verify=self.config.verify_ssl,
                                )
                            except Exception as e:
                                logger.warning(f"No se pudo notificar renombrado al servidor: {e}")
                    else:
                        logger.info(f"✅ [LDAP] Hostname '{current_hostname}' coincide. Sin cambios.")
                    return
                else:
                    logger.info(f"ℹ️  [LDAP] Equipo no encontrado en LDAP. Consultando inventario...")
        except Exception as e:
            logger.warning(f"⚠️  [LDAP] Error: {e}. Continuando con inventario...")

        # Fase 2: Inventario
        try:
            inventory_url = f"{self.config.http_url}/api/inventory/computers/by-agent/{self.config.agent_id}/"
            inv_response = requests.get(
                inventory_url, headers=headers, timeout=10, verify=self.config.verify_ssl,
            )
            if inv_response.status_code == 200:
                inv_data = inv_response.json()
                inventory_hostname = inv_data.get('hostname', '')
                if not inventory_hostname:
                    logger.info("ℹ️  [Inventario] Sin hostname en inventario. Sin cambios.")
                    return
                if inventory_hostname == current_hostname:
                    logger.info(f"✅ [Inventario] Hostname coincide. Sin cambios.")
                else:
                    logger.info(f"📝 [Inventario] Renombrando a '{inventory_hostname}'")
                    if self.rename_hostname(inventory_hostname):
                        self.config.hostname = inventory_hostname
            elif inv_response.status_code == 404:
                logger.info(f"ℹ️  [Inventario] Equipo no encontrado. Sin cambios.")
            else:
                logger.error(f"❌ [Inventario] Error HTTP {inv_response.status_code}")
        except Exception as e:
            logger.error(f"❌ [Inventario] Error: {e}")

    # ── websocket helpers ─────────────────────────────────────────────────────

    async def send_json(self, data: dict) -> bool:
        """Enviar JSON por WebSocket."""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps(data))
                return True
        except Exception as e:
            logger.error(f"Error enviando JSON: {e}")
        return False

    async def _send_login_notification(self, session_data: dict):
        """Notificación de login por WebSocket."""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'user_login',
                    'agent_id': self.config.agent_id,
                    'username': session_data['username'],
                    'terminal': session_data['terminal'],
                    'session_type': session_data['session_type'],
                    'host': session_data.get('host', 'local'),
                    'timestamp': datetime.now().isoformat(),
                }))
                logger.info(f"👤 Login detectado: {session_data['username']} en {session_data['terminal']}")
        except Exception as e:
            logger.error(f"Error enviando notificación de login: {e}")

    async def _send_logout_notification(self, session_data: dict):
        """Notificación de logout por WebSocket."""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'user_logout',
                    'agent_id': self.config.agent_id,
                    'username': session_data['username'],
                    'terminal': session_data['terminal'],
                    'session_type': session_data['session_type'],
                    'timestamp': datetime.now().isoformat(),
                }))
                logger.info(f"👤 Logout detectado: {session_data['username']} de {session_data['terminal']}")
        except Exception as e:
            logger.error(f"Error enviando notificación de logout: {e}")

    # ── monitorización local ──────────────────────────────────────────────────

    async def monitor_local_services(self):
        """Monitorear servicios locales y enviar heartbeat periódico al servidor."""
        while self.running and self.websocket:
            try:
                await asyncio.sleep(self.config.heartbeat_interval)
                if self.websocket and self.websocket.close_code is None:
                    await self.send_json({'type': 'heartbeat'})

                    if (time.time() - self.last_battery_report) >= self.config.battery_interval:
                        await self.send_battery_status()

                    if self.config.vnc_enabled and self.vnc_manager:
                        if not self.vnc_manager.is_running():
                            logger.warning("⚠️ Servicio VNC caído, reiniciando...")
                            if self.vnc_manager.start():
                                await self.send_json(self.vnc_manager.get_info())
                    elif not self.config.vnc_enabled and self.vnc_manager:
                        if self.vnc_manager.is_running():
                            logger.info("🛑 Servicio VNC desactivado por configuración, deteniendo...")
                            self.vnc_manager.stop()

            except Exception as e:
                logger.error(f"Error monitoreando servicios locales: {e}")
                break

    # ── información del agente ────────────────────────────────────────────────

    async def send_agent_info(self):
        """Enviar información del agente al servidor."""
        try:
            info = self.get_system_info()
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                info['ip_address'] = s.getsockname()[0]
                s.close()
            except Exception:
                info['ip_address'] = 'unknown'

            await self.websocket.send(json.dumps({'type': 'agent_info', **info}))
            logger.info(f"Información del agente enviada: {info['hostname']} ({info['ip_address']})")
        except Exception as e:
            logger.error(f"Error enviando información del agente: {e}")

    async def send_battery_status(self):
        """Enviar el estado actual de la batería al servidor vía WebSocket.

        Se envía también en equipos sin batería (is_laptop=False) para que el
        servidor pueda limpiar datos antiguos si el equipo deja de ser portátil.
        """
        try:
            battery = await asyncio.get_event_loop().run_in_executor(
                None, collect_battery_status
            )
            self.last_battery_report = time.time()

            if not await self.send_json({'type': 'battery_info', **battery}):
                return

            if battery.get('battery_present'):
                logger.info(
                    f"🔋 Batería: {battery.get('battery_percent')}% "
                    f"({battery.get('battery_status') or 'desconocido'}), "
                    f"salud: {battery.get('battery_health_status')}"
                )
        except Exception as e:
            logger.error(f"Error enviando estado de la batería: {e}")

    async def send_inventory_update(self):
        """Enviar actualización de inventario al servidor vía HTTP."""
        if not REQUESTS_AVAILABLE:
            logger.warning("⚠️  requests no disponible, no se puede enviar inventario")
            return
        try:
            logger.info("📦 Recopilando información del sistema para inventario...")
            inventory = collect_system_inventory()
            inventory['agent_id'] = self.config.agent_id
            inventory['hostname'] = self.config.hostname

            inventory_url = f"{self.config.http_url}/api/inventory/update/"
            headers = {'Content-Type': 'application/json'}
            if self.config.token:
                headers['Authorization'] = f'Token {self.config.token}'

            logger.info(f"📤 Enviando inventario a {inventory_url}...")
            response = requests.post(
                inventory_url, json=inventory, headers=headers,
                timeout=10, verify=self.config.verify_ssl,
            )
            if response.status_code == 200:
                result = response.json()
                if result.get('created'):
                    logger.info(f"✅ Equipo registrado en inventario: {inventory.get('hostname')}")
                else:
                    updated = result.get('updated_fields', [])
                    if updated:
                        logger.info(f"✅ Inventario actualizado. Campos: {', '.join(updated)}")
                    else:
                        logger.info("✅ Inventario verificado (sin cambios)")
            else:
                logger.error(f"❌ Error enviando inventario: HTTP {response.status_code}")
        except Exception as e:
            logger.error(f"❌ Error enviando inventario: {e}")

    # ── manejo de mensajes ────────────────────────────────────────────────────

    async def handle_message(self, message: str):
        """Manejar mensajes del servidor."""
        try:
            data = json.loads(message)
            msg_type = data.get('type')
            logger.debug(f"Mensaje recibido: {msg_type}")

            if msg_type == 'connected':
                logger.info(f"✅ Conectado al servidor: {data.get('message')}")
                await self.send_agent_info()
                await self.send_battery_status()

                if self.config.auto_rename:
                    logger.info("📝 Auto-renombrado activado, verificando...")
                    await self.check_and_rename_hostname()

                if self.config.auto_inventory:
                    logger.info("📦 Auto-inventario activado, enviando datos...")
                    await self.send_inventory_update()
                else:
                    logger.info("ℹ️  Auto-inventario desactivado")

                if self.config.vnc_enabled:
                    if not self.vnc_manager:
                        self.vnc_manager = VNCManager(self.config.token, self.config.vnc_port)
                    if self.vnc_manager.start():
                        vnc_info = self.vnc_manager.get_info()
                        await self.send_json(vnc_info)
                        logger.info(f"🖥️  Servicio VNC activo en {vnc_info['ip']}:{vnc_info['port']}")
                else:
                    logger.info("ℹ️ Servicio VNC desactivado por configuración")

                await self.puppet_manager.check_puppet_stuck()

                # Configurar auditoría CUPS e iniciar monitoreo de impresiones
                if self.config.print_tracking:
                    self.cups_manager.configure_audit()
                    self.print_tracker.start()

            elif msg_type == 'execute_command':
                command_id = data.get('command_id')
                command = data.get('command')
                args = data.get('args', [])
                shell = data.get('shell', True)
                timeout = data.get('timeout', 300)
                logger.info(f"📨 Comando recibido [{command_id}]: {command}")
                asyncio.create_task(self.executor.execute(command_id, command, args, shell, timeout))

            elif msg_type == 'execute_action':
                command_id = data.get('command_id')
                action = data.get('action')
                params = data.get('params', {})
                logger.info(f"⚙️ Accion recibida [{command_id}]: {action}")
                asyncio.create_task(self._execute_action(command_id, action, params))

            elif msg_type == 'cancel_command':
                command_id = data.get('command_id')
                logger.info(f"🛑 Cancelación recibida para comando [{command_id}]")
                asyncio.create_task(self.executor.cancel(command_id))

            elif msg_type == 'enable_streaming':
                for cid in data.get('command_ids', []):
                    self.executor.enable_streaming(cid)

            elif msg_type == 'disable_streaming':
                for cid in data.get('command_ids', []):
                    self.executor.disable_streaming(cid)

            elif msg_type == 'heartbeat_ack':
                logger.debug("Heartbeat ACK recibido")

            elif msg_type == 'ping':
                await self.websocket.send(json.dumps({
                    'type': 'pong',
                    'timestamp': data.get('timestamp'),
                }))

            elif msg_type == 'start_terminal':
                terminal_id = data.get('terminal_id')
                terminal_group = data.get('terminal_group')
                logger.info(f"🖥️  Iniciando terminal [{terminal_id}]")
                terminal = TerminalHandler(self.websocket, self.config.agent_id, terminal_id, terminal_group)
                self.terminals[terminal_id] = terminal
                asyncio.create_task(terminal.start())

            elif msg_type == 'terminal_input':
                terminal_id = data.get('terminal_id')
                input_data = data.get('data', '')
                if terminal_id in self.terminals:
                    await self.terminals[terminal_id].write_input(input_data)
                else:
                    logger.warning(f"Terminal {terminal_id} no encontrado")

            elif msg_type == 'terminal_resize':
                terminal_id = data.get('terminal_id')
                if terminal_id in self.terminals:
                    await self.terminals[terminal_id].resize(data.get('cols', 80), data.get('rows', 24))
                else:
                    logger.warning(f"Terminal {terminal_id} no encontrado para resize")

            elif msg_type == 'close_terminal':
                terminal_id = data.get('terminal_id')
                logger.info(f"🛑 Cerrando terminal [{terminal_id}]")
                if terminal_id in self.terminals:
                    await self.terminals[terminal_id].close()
                    del self.terminals[terminal_id]
                else:
                    logger.warning(f"Terminal {terminal_id} no encontrado para cerrar")

            elif msg_type == 'start_thumbnail_stream':
                interval = data.get('interval', 5)
                quality = data.get('quality', 40)
                width = data.get('width', 320)
                logger.info(
                    f"📸 Solicitud de inicio de thumbnail stream "
                    f"(intervalo={interval}s, quality={quality}, width={width})"
                )
                self.screenshot_streamer.start(
                    self.send_json,
                    interval=interval,
                    quality=quality,
                    width=width,
                )

            elif msg_type == 'stop_thumbnail_stream':
                logger.info("📸 Solicitud de parada de thumbnail stream")
                self.screenshot_streamer.stop()

            else:
                logger.warning(f"Tipo de mensaje desconocido: {msg_type}")

        except json.JSONDecodeError:
            logger.error(f"Error decodificando mensaje JSON: {message}")
        except Exception as e:
            logger.error(f"Error manejando mensaje: {e}")

    # ── conexión / ciclo principal ────────────────────────────────────────────

    async def connect(self) -> bool:
        """Conectar al servidor WebSocket."""
        url = f"{self.config.server_url}?agent_id={self.config.agent_id}&hostname={self.config.hostname}"
        logger.info(f"🔌 Conectando a {url}...")

        try:
            extra_headers = {}
            if self.config.token:
                extra_headers['Authorization'] = f'Token {self.config.token}'

            ssl_context = None
            if self.config.ssl_enabled:
                ssl_context = ssl.create_default_context()
                if not self.config.verify_ssl:
                    ssl_context.check_hostname = False
                    ssl_context.verify_mode = ssl.CERT_NONE

            self.websocket = await websockets.connect(
                url,
                ping_interval=20,
                ping_timeout=10,
                extra_headers=extra_headers,
                ssl=ssl_context,
            )
            self.executor = CommandExecutor(self.websocket, self.config.agent_id)
            self.reconnect_attempts = 0
            logger.info(f"✅ Conectado al servidor como {self.config.agent_id}")

            # Inicializar LoginMonitor solo la primera vez
            if self.login_monitor is None and LOGIN_MONITOR_AVAILABLE:
                self.login_monitor = LoginMonitor(
                    agent_id=self.config.agent_id,
                    http_url=self.config.http_url,
                    token=self.config.token,
                    verify_ssl=self.config.verify_ssl,
                )

                main_loop = asyncio.get_event_loop()

                def on_login(session_data):
                    if self.websocket and self.websocket.close_code is None:
                        asyncio.run_coroutine_threadsafe(
                            self._send_login_notification(session_data), main_loop
                        )
                    # Fuera del if: el aviso de contraseña debe funcionar aunque el
                    # WebSocket esté caído. Se resuelve en su propio hilo.
                    self.password_prompter.maybe_prompt(session_data)

                def on_logout(session_data):
                    if self.websocket and self.websocket.close_code is None:
                        asyncio.run_coroutine_threadsafe(
                            self._send_logout_notification(session_data), main_loop
                        )

                self.login_monitor.set_login_callback(on_login)
                self.login_monitor.set_logout_callback(on_logout)
                self.login_monitor.start()

            return True

        except Exception as e:
            logger.error(f"❌ Error conectando: {e}")
            return False

    async def listen(self):
        """Escuchar mensajes del servidor."""
        monitor_task = None
        try:
            monitor_task = asyncio.create_task(self.monitor_local_services())
            async for message in self.websocket:
                await self.handle_message(message)
        except websockets.exceptions.ConnectionClosed:
            logger.warning("⚠️  Conexión cerrada por el servidor")
        except Exception as e:
            logger.error(f"Error en conexión: {e}")
        finally:
            if monitor_task:
                monitor_task.cancel()

    async def run(self):
        """Ejecutar el agente con reconexión automática."""
        self.running = True
        logger.info(f"🚀 Iniciando agente {self.config.agent_id}")
        logger.info(f"   Hostname: {self.config.hostname}")
        logger.info(f"   Sistema: {platform.system()} {platform.release()}")

        while self.running:
            try:
                if await self.connect():
                    await self.listen()

                if self.running:
                    self.reconnect_attempts += 1
                    if (self.config.max_reconnect_attempts
                            and self.reconnect_attempts >= self.config.max_reconnect_attempts):
                        logger.error(f"❌ Máximo de reintentos alcanzado ({self.reconnect_attempts})")
                        break
                    logger.info(
                        f"🔄 Reintentando conexión en {self.config.reconnect_delay}s... "
                        f"(intento {self.reconnect_attempts})"
                    )
                    await asyncio.sleep(self.config.reconnect_delay)

            except KeyboardInterrupt:
                logger.info("⚠️  Interrupción del usuario")
                self.running = False
                break
            except Exception as e:
                logger.error(f"Error inesperado: {e}")
                if self.running:
                    await asyncio.sleep(self.config.reconnect_delay)

        # Limpieza
        self.screenshot_streamer.stop()
        self.print_tracker.stop()
        if self.login_monitor:
            self.login_monitor.stop()
        if self.websocket and self.websocket.close_code is None:
            await self.websocket.close()

        logger.info("👋 Agente detenido")

    def stop(self):
        """Detener el agente."""
        self.running = False
        self.screenshot_streamer.stop()
        self.print_tracker.stop()
        if self.login_monitor:
            self.login_monitor.stop()
        if self.vnc_manager:
            self.vnc_manager.stop()


# ═════════════════════════════════════════════════════════════════════════════
# CLI
# ═════════════════════════════════════════════════════════════════════════════

def parse_arguments() -> argparse.Namespace:
    """Parsear argumentos de línea de comandos."""
    parser = argparse.ArgumentParser(
        description='EduControl Remote Agent - Agente remoto para gestión de equipos',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument('--server', type=str,
                        help='URL del servidor WebSocket (ej: ws://localhost:8003/ws/agent/)')
    parser.add_argument('--token', type=str, help='Token de autenticación (opcional)')
    parser.add_argument('--config', type=str, default='agent_config.json',
                        help='Archivo de configuración JSON (default: agent_config.json)')
    parser.add_argument('--log-level', type=str, default='INFO',
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help='Nivel de detalle de los logs (default: INFO)')
    return parser.parse_args()


def main():
    """Función principal."""

    args = parse_arguments()

    # Ajustar nivel de log
    numeric_level = getattr(logging, args.log_level.upper(), logging.INFO)
    logging.getLogger().setLevel(numeric_level)
    logger.setLevel(numeric_level)
    if args.log_level == 'DEBUG':
        logger.debug("🐛 Modo DEBUG activado.")

    config = AgentConfig()

    # Buscar archivo de configuración
    config_file = None
    if args.config and args.config != 'agent_config.json':
        config_file = Path(args.config)
    else:
        system_config = Path('/etc/educontrol/agent_config.json')
        local_config = Path('agent_config.json')
        if system_config.exists():
            config_file = system_config
            logger.info("📋 Usando configuración del sistema: /etc/educontrol/agent_config.json")
        elif local_config.exists():
            config_file = local_config
            logger.info("📋 Usando configuración local: agent_config.json")

    if config_file and config_file.exists():
        config.load_from_file(str(config_file))
    else:
        logger.warning("⚠️  No se encontró archivo de configuración, usando valores por defecto")

    if args.server:
        config.server_url = args.server
    if args.token:
        config.token = args.token

    if not config.server_url:
        logger.error("❌ No se especificó URL del servidor. Usa --server o --config")
        sys.exit(1)

    agent = RemoteAgent(config)
    try:
        asyncio.run(agent.run())
    except KeyboardInterrupt:
        logger.info("\n⚠️  Deteniendo agente...")
        agent.stop()


if __name__ == '__main__':
    main()

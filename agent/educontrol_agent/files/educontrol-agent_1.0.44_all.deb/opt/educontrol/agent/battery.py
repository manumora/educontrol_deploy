"""
battery.py — Detección de equipos portátiles y estado de la batería.

Devuelve un diccionario plano con las mismas claves que espera el servidor
(`is_laptop`, `battery_percent`, `battery_health_status`, …) para que tanto el
inventario HTTP como el mensaje WebSocket `battery_info` compartan formato.
"""

import json
import logging
import os
import platform
import subprocess

logger = logging.getLogger('EduControlAgent')

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

# Tipos de chasis DMI/SMBIOS considerados portátiles
# (8 Portable, 9 Laptop, 10 Notebook, 11 Hand Held, 14 Sub Notebook,
#  30 Tablet, 31 Convertible, 32 Detachable)
PORTABLE_CHASSIS_TYPES = {8, 9, 10, 11, 14, 30, 31, 32}

# Umbrales de salud sobre la capacidad máxima actual respecto a la de diseño
HEALTH_GOOD_THRESHOLD = 80      # >= 80 % → buena
HEALTH_FAIR_THRESHOLD = 60      # 60-79 % → regular; < 60 % → mala
CYCLE_COUNT_WARNING = 800       # ciclos a partir de los cuales se avisa
CYCLE_COUNT_CRITICAL = 1200

HEALTH_GOOD = 'good'
HEALTH_FAIR = 'fair'
HEALTH_POOR = 'poor'
HEALTH_UNKNOWN = 'unknown'


# ═════════════════════════════════════════════════════════════════════════════
# utilidades
# ═════════════════════════════════════════════════════════════════════════════

def _read_file(path: str):
    """Leer un fichero de sysfs devolviendo su contenido o None."""
    try:
        with open(path, 'r') as f:
            value = f.read().strip()
        return value or None
    except Exception:
        return None


def _read_int(path: str):
    """Leer un entero de sysfs devolviendo None si no existe o no es numérico."""
    value = _read_file(path)
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _run(cmd: list, timeout: int = 15):
    """Ejecutar un comando devolviendo su stdout o None si falla."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            return None
        return result.stdout
    except Exception:
        return None


def _powershell(script: str):
    """Ejecutar un script de PowerShell devolviendo el JSON parseado o None."""
    output = _run([
        'powershell', '-NoProfile', '-NonInteractive', '-Command', script
    ], timeout=30)
    if not output or not output.strip():
        return None
    try:
        return json.loads(output)
    except ValueError:
        return None


def _percentage(part, total):
    """Porcentaje entero de `part` sobre `total`, o None si no es calculable."""
    try:
        if not total or part is None or float(total) <= 0:
            return None
        return int(round(float(part) / float(total) * 100))
    except (TypeError, ValueError):
        return None


# ═════════════════════════════════════════════════════════════════════════════
# detección de chasis
# ═════════════════════════════════════════════════════════════════════════════

def _linux_is_portable():
    chassis_type = _read_int('/sys/class/dmi/id/chassis_type')
    if chassis_type is None:
        return None
    return chassis_type in PORTABLE_CHASSIS_TYPES


def _windows_is_portable():
    data = _powershell(
        '(Get-CimInstance -ClassName Win32_SystemEnclosure).ChassisTypes | ConvertTo-Json'
    )
    if data is None:
        return None
    if not isinstance(data, list):
        data = [data]
    try:
        return any(int(t) in PORTABLE_CHASSIS_TYPES for t in data)
    except (TypeError, ValueError):
        return None


def _darwin_is_portable():
    output = _run(['sysctl', '-n', 'hw.model'])
    if not output:
        return None
    # MacBook / MacBookAir / MacBookPro son los únicos portátiles de Apple
    return 'book' in output.strip().lower()


def is_portable():
    """Indicar si el equipo es un portátil según el tipo de chasis.

    Returns:
        True/False, o None si no se ha podido determinar.
    """
    try:
        system = platform.system()
        if system == 'Linux':
            return _linux_is_portable()
        if system == 'Windows':
            return _windows_is_portable()
        if system == 'Darwin':
            return _darwin_is_portable()
    except Exception as e:
        logger.debug(f"No se pudo determinar el tipo de chasis: {e}")
    return None


# ═════════════════════════════════════════════════════════════════════════════
# lectura de la batería por plataforma
# ═════════════════════════════════════════════════════════════════════════════

def _linux_battery():
    """Leer la batería desde /sys/class/power_supply."""
    base = '/sys/class/power_supply'
    if not os.path.isdir(base):
        return None

    for name in sorted(os.listdir(base)):
        path = os.path.join(base, name)
        if _read_file(os.path.join(path, 'type')) != 'Battery':
            continue

        data = {
            'percent': _read_int(os.path.join(path, 'capacity')),
            'status': _read_file(os.path.join(path, 'status')),
            'cycle_count': _read_int(os.path.join(path, 'cycle_count')),
            'technology': _read_file(os.path.join(path, 'technology')),
            'manufacturer': _read_file(os.path.join(path, 'manufacturer')),
            'model': _read_file(os.path.join(path, 'model_name')),
            'serial_number': _read_file(os.path.join(path, 'serial_number')),
        }

        # Capacidades: los portátiles exponen energy_* (µWh) o charge_* (µAh)
        design = _read_int(os.path.join(path, 'energy_full_design'))
        full = _read_int(os.path.join(path, 'energy_full'))
        if design is None and full is None:
            charge_design = _read_int(os.path.join(path, 'charge_full_design'))
            charge_full = _read_int(os.path.join(path, 'charge_full'))
            voltage = (
                _read_int(os.path.join(path, 'voltage_min_design'))
                or _read_int(os.path.join(path, 'voltage_now'))
            )
            if voltage:
                # µAh × µV → Wh
                if charge_design is not None:
                    design = charge_design * voltage / 1_000_000
                if charge_full is not None:
                    full = charge_full * voltage / 1_000_000

        if design is not None:
            data['design_capacity_wh'] = round(design / 1_000_000, 2)
        if full is not None:
            data['full_charge_capacity_wh'] = round(full / 1_000_000, 2)

        return data

    return None


def _windows_battery():
    """Leer la batería mediante CIM/WMI."""
    data = {}

    battery = _powershell(
        'Get-CimInstance -ClassName Win32_Battery | '
        'Select-Object -First 1 EstimatedChargeRemaining,BatteryStatus,Chemistry,Name,'
        'DeviceID,EstimatedRunTime | ConvertTo-Json'
    )
    if isinstance(battery, list):
        battery = battery[0] if battery else None
    if not battery:
        return None

    data['percent'] = battery.get('EstimatedChargeRemaining')
    data['model'] = battery.get('Name')
    data['serial_number'] = battery.get('DeviceID')

    # BatteryStatus: 1 descargando, 2 conectado a la red, 3 completa, …
    status_map = {
        1: 'Discharging', 2: 'Charging', 3: 'Full', 4: 'Low',
        5: 'Critical', 6: 'Charging', 7: 'Charging', 8: 'Charging',
        9: 'Charging', 10: 'Unknown', 11: 'Partially Charged',
    }
    data['status'] = status_map.get(battery.get('BatteryStatus'), 'Unknown')

    chemistry_map = {
        1: 'Other', 2: 'Unknown', 3: 'Lead Acid', 4: 'NiCd', 5: 'NiMH',
        6: 'Li-ion', 7: 'Zinc air', 8: 'Li-poly',
    }
    data['technology'] = chemistry_map.get(battery.get('Chemistry'))

    estimated_runtime = battery.get('EstimatedRunTime')
    # 71582788 es el valor centinela de "desconocido" que devuelve Windows
    if isinstance(estimated_runtime, int) and 0 < estimated_runtime < 100000:
        data['secs_left'] = estimated_runtime * 60

    # Capacidades reales y ciclos viven en el espacio de nombres root\wmi
    static_data = _powershell(
        'Get-CimInstance -Namespace root\\wmi -ClassName BatteryStaticData -ErrorAction SilentlyContinue | '
        'Select-Object -First 1 DesignedCapacity,ManufactureName,Chemistry | ConvertTo-Json'
    )
    if isinstance(static_data, list):
        static_data = static_data[0] if static_data else None
    if static_data:
        designed = static_data.get('DesignedCapacity')
        if designed:
            data['design_capacity_wh'] = round(designed / 1000, 2)
        if static_data.get('ManufactureName'):
            data['manufacturer'] = static_data['ManufactureName'].strip()

    full_data = _powershell(
        'Get-CimInstance -Namespace root\\wmi -ClassName BatteryFullChargedCapacity -ErrorAction SilentlyContinue | '
        'Select-Object -First 1 FullChargedCapacity | ConvertTo-Json'
    )
    if isinstance(full_data, list):
        full_data = full_data[0] if full_data else None
    if full_data and full_data.get('FullChargedCapacity'):
        data['full_charge_capacity_wh'] = round(full_data['FullChargedCapacity'] / 1000, 2)

    cycle_data = _powershell(
        'Get-CimInstance -Namespace root\\wmi -ClassName BatteryCycleCount -ErrorAction SilentlyContinue | '
        'Select-Object -First 1 CycleCount | ConvertTo-Json'
    )
    if isinstance(cycle_data, list):
        cycle_data = cycle_data[0] if cycle_data else None
    if cycle_data and cycle_data.get('CycleCount'):
        data['cycle_count'] = cycle_data['CycleCount']

    return data


def _darwin_battery():
    """Leer la batería mediante system_profiler."""
    output = _run(['system_profiler', 'SPPowerDataType', '-json'], timeout=30)
    if not output:
        return None

    try:
        parsed = json.loads(output)
    except ValueError:
        return None

    entries = parsed.get('SPPowerDataType') or []
    battery_entry = None
    for entry in entries:
        if 'sppower_battery_charge_info' in entry or 'sppower_battery_health_info' in entry:
            battery_entry = entry
            break
    if not battery_entry:
        return None

    data = {}

    charge_info = battery_entry.get('sppower_battery_charge_info') or {}
    percent = charge_info.get('sppower_battery_state_of_charge')
    if percent is not None:
        data['percent'] = percent
    if charge_info.get('sppower_battery_is_charging') == 'TRUE':
        data['status'] = 'Charging'
    elif charge_info.get('sppower_battery_fully_charged') == 'TRUE':
        data['status'] = 'Full'
    else:
        data['status'] = 'Discharging'

    health_info = battery_entry.get('sppower_battery_health_info') or {}
    if health_info.get('sppower_battery_cycle_count') is not None:
        data['cycle_count'] = health_info['sppower_battery_cycle_count']
    if health_info.get('sppower_battery_health'):
        data['condition'] = health_info['sppower_battery_health']
    max_capacity = health_info.get('sppower_battery_health_maximum_capacity')
    if isinstance(max_capacity, str) and max_capacity.endswith('%'):
        try:
            data['health_percent'] = int(max_capacity.rstrip('%'))
        except ValueError:
            pass

    model_info = battery_entry.get('sppower_battery_model_info') or {}
    if model_info.get('sppower_battery_manufacturer'):
        data['manufacturer'] = model_info['sppower_battery_manufacturer']
    if model_info.get('sppower_battery_device_name'):
        data['model'] = model_info['sppower_battery_device_name']
    if model_info.get('sppower_battery_serial_number'):
        data['serial_number'] = model_info['sppower_battery_serial_number']

    return data


def _psutil_battery():
    """Datos básicos de psutil, disponibles en las tres plataformas."""
    if not PSUTIL_AVAILABLE:
        return None
    try:
        sensor = psutil.sensors_battery()
    except Exception:
        return None
    if sensor is None:
        return None

    data = {'percent': int(round(sensor.percent)), 'power_plugged': sensor.power_plugged}
    if sensor.secsleft is not None and sensor.secsleft >= 0:
        data['secs_left'] = int(sensor.secsleft)
    return data


# ═════════════════════════════════════════════════════════════════════════════
# evaluación de la salud
# ═════════════════════════════════════════════════════════════════════════════

def _evaluate_health(data: dict):
    """Calcular el porcentaje de salud, su valoración y los problemas detectados.

    Returns:
        (health_percent, health_status, issues)
    """
    issues = []

    health_percent = data.get('health_percent')
    if health_percent is None:
        health_percent = _percentage(
            data.get('full_charge_capacity_wh'), data.get('design_capacity_wh')
        )
    # Una capacidad máxima por encima del diseño es ruido de medición
    if health_percent is not None:
        health_percent = min(health_percent, 100)

    if health_percent is None:
        status = HEALTH_UNKNOWN
    elif health_percent >= HEALTH_GOOD_THRESHOLD:
        status = HEALTH_GOOD
    elif health_percent >= HEALTH_FAIR_THRESHOLD:
        status = HEALTH_FAIR
        issues.append(
            f"La capacidad máxima ha bajado al {health_percent}% de la original: "
            f"la autonomía es notablemente menor que la de fábrica."
        )
    else:
        status = HEALTH_POOR
        issues.append(
            f"La capacidad máxima ha bajado al {health_percent}% de la original: "
            f"la batería está muy degradada y debería sustituirse."
        )

    # Ciclos de carga
    cycles = data.get('cycle_count')
    if isinstance(cycles, int) and cycles > 0:
        if cycles >= CYCLE_COUNT_CRITICAL:
            issues.append(f"Batería con {cycles} ciclos de carga: ha superado su vida útil estimada.")
            status = HEALTH_POOR
        elif cycles >= CYCLE_COUNT_WARNING:
            issues.append(f"Batería con {cycles} ciclos de carga: se acerca al final de su vida útil.")
            if status in (HEALTH_GOOD, HEALTH_UNKNOWN):
                status = HEALTH_FAIR

    # Diagnóstico del propio sistema (macOS y algunos portátiles Windows)
    condition = (data.get('condition') or '').strip()
    normalized = condition.lower()
    if normalized:
        if normalized in ('service battery', 'replace now', 'permanent failure', 'failed'):
            issues.append(f"El sistema informa del estado «{condition}»: requiere servicio técnico.")
            status = HEALTH_POOR
        elif normalized in ('replace soon', 'check battery', 'fair', 'poor'):
            issues.append(f"El sistema informa del estado «{condition}».")
            if status in (HEALTH_GOOD, HEALTH_UNKNOWN):
                status = HEALTH_FAIR

    return health_percent, status, issues


# ═════════════════════════════════════════════════════════════════════════════
# API pública
# ═════════════════════════════════════════════════════════════════════════════

def collect_battery_status() -> dict:
    """Recopilar el estado de la batería del equipo.

    Devuelve siempre un diccionario (nunca None) para que el servidor pueda
    limpiar los datos de un equipo que ya no tiene batería:

        {
            'is_laptop': bool,
            'battery_present': bool,
            'battery_percent': int | None,
            'battery_charging': bool | None,
            'battery_status': str,
            'battery_secs_left': int | None,
            'battery_health_percent': int | None,
            'battery_health_status': 'good' | 'fair' | 'poor' | 'unknown',
            'battery_info': dict | None,
        }
    """
    result = {
        'is_laptop': False,
        'battery_present': False,
        'battery_percent': None,
        'battery_charging': None,
        'battery_status': '',
        'battery_secs_left': None,
        'battery_health_percent': None,
        'battery_health_status': HEALTH_UNKNOWN,
        'battery_info': None,
    }

    try:
        portable = is_portable()

        data = {}
        system = platform.system()
        try:
            if system == 'Linux':
                data = _linux_battery() or {}
            elif system == 'Windows':
                data = _windows_battery() or {}
            elif system == 'Darwin':
                data = _darwin_battery() or {}
        except Exception as e:
            logger.debug(f"Error leyendo la batería del sistema: {e}")

        # psutil completa lo que falte (porcentaje, si está enchufado, autonomía)
        fallback = _psutil_battery() or {}
        for key, value in fallback.items():
            if data.get(key) is None:
                data[key] = value

        present = bool(data) and data.get('percent') is not None
        # Un equipo sin batería puede seguir siendo portátil (batería retirada),
        # y un equipo con batería cuyo chasis no se ha podido leer se considera portátil.
        result['is_laptop'] = bool(portable) if portable is not None else present
        result['battery_present'] = present

        if not present:
            if not result['is_laptop']:
                result['battery_status'] = ''
            return result

        status = (data.get('status') or '').strip()
        charging = data.get('power_plugged')
        if charging is None and status:
            charging = status.lower() in ('charging', 'full', 'not charging')

        health_percent, health_status, issues = _evaluate_health(data)

        result['battery_percent'] = data.get('percent')
        result['battery_charging'] = charging
        result['battery_status'] = status or ('Charging' if charging else 'Discharging')
        result['battery_secs_left'] = data.get('secs_left')
        result['battery_health_percent'] = health_percent
        result['battery_health_status'] = health_status
        result['battery_info'] = {
            'design_capacity_wh': data.get('design_capacity_wh'),
            'full_charge_capacity_wh': data.get('full_charge_capacity_wh'),
            'cycle_count': data.get('cycle_count'),
            'technology': data.get('technology'),
            'manufacturer': data.get('manufacturer'),
            'model': data.get('model'),
            'serial_number': data.get('serial_number'),
            'condition': data.get('condition'),
            'issues': issues,
        }

    except Exception as e:
        logger.error(f"Error recopilando estado de la batería: {e}")

    return result

#!/usr/bin/env python3
"""
EduControl Remote Agent
=======================

Agente remoto que se ejecuta en equipos de la red para recibir y ejecutar
comandos desde el servidor Django vía WebSocket.

Características:
- Conexión WebSocket persistente con reconexión automática
- Ejecución de comandos con salida en tiempo real línea por línea
- Heartbeat para mantener la conexión activa
- Identificación única por hostname y MAC address
- Logs detallados de todas las operaciones

Uso:
    python agent.py --server ws://localhost:8003 --token <token>
    python agent.py --config config.json
"""

import asyncio
import json
import logging
import os
import platform
import socket
import ssl
import subprocess
import sys
import threading
import time
import uuid
import re
from datetime import datetime
from pathlib import Path
from typing import Optional
import argparse

# Imports para terminal PTY (Unix)
try:
    import pty
    import fcntl
    import termios
    PTY_AVAILABLE = True
except ImportError:
    PTY_AVAILABLE = False

try:
    import websockets
except ImportError:
    print("ERROR: websockets no está instalado. Ejecuta: pip install websockets")
    sys.exit(1)

# Librerías opcionales para inventario
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("⚠️  psutil no disponible. Funcionalidades de inventario limitadas.")
    
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    print("⚠️  requests no disponible. Inventario no se enviará al servidor.")

try:
    import struct
    STRUCT_AVAILABLE = True
except ImportError:
    STRUCT_AVAILABLE = False
    print("⚠️  struct no disponible. Monitoreo de logins desactivado.")

# Importar LoginMonitor desde módulo separado
try:
    from login_monitor import LoginMonitor
    LOGIN_MONITOR_AVAILABLE = True
except ImportError as e:
    LOGIN_MONITOR_AVAILABLE = False
    print(f"⚠️  LoginMonitor no disponible: {e}")

# Configuración de logging con rotación automática
from logging.handlers import RotatingFileHandler

# Detectar si estamos en modo sistema o desarrollo
def get_log_path():
    """Determinar ruta de logs según el entorno"""
    system_log_dir = '/var/log/educontrol'
    if os.path.exists(system_log_dir) and os.access(system_log_dir, os.W_OK):
        # Modo sistema (instalado como .deb)
        return os.path.join(system_log_dir, 'agent.log')
    else:
        # Modo desarrollo
        return 'agent.log'

# Crear handler con rotación (10 MB por archivo, mantener 5 archivos antiguos)
log_file = get_log_path()
log_handler = RotatingFileHandler(
    log_file,
    maxBytes=10*1024*1024,  # 10 MB
    backupCount=5,  # Mantener agent.log.1, agent.log.2, etc.
    encoding='utf-8'
)
log_handler.setFormatter(
    logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
)

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(),  # Consola (para desarrollo)
        log_handler  # Archivo con rotación automática
    ]
)
logger = logging.getLogger('EduControlAgent')
logger.info(f"📝 Logs guardándose en: {log_file}")


class VNCManager:
    """Gestor del servicio x11vnc"""
    
    def __init__(self, token: str, port: int = 5900):
        self.token = token
        self.port = port
        self.process = None
        self.passwd_file = '/tmp/.educontrol_vnc.pass'
        self.log_file = '/var/log/educontrol/x11vnc.log'
        
    def _create_passwd_file(self):
        """Crear archivo de password para x11vnc usando el token (primeros 8 chars)"""
        try:
            # VNC standard password length is 8 chars max usually.
            vnc_pass = self.token[:8] if self.token else "educontrol"
            
            # Escribir password usando x11vnc
            cmd = ['x11vnc', '-storepasswd', vnc_pass, self.passwd_file]
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            os.chmod(self.passwd_file, 0o600)
            return True
        except Exception as e:
            logger.error(f"Error creando archivo password VNC: {e}")
            return False

    def _is_port_in_use(self, port: int) -> bool:
        """Comprobar si un puerto está en uso (en localhost y en cualquier IP)"""
        for host in ['127.0.0.1', '0.0.0.0']:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(0.5)
                    if s.connect_ex((host, port)) == 0:
                        return True
            except:
                pass
        return False

    def start(self):
        """Iniciar servicio x11vnc"""
        if self.process and self.process.poll() is None:
            # logger.debug("VNC ya está corriendo")
            return True
        
        # Verificar si x11vnc está instalado
        if subprocess.call(['which', 'x11vnc'], stdout=subprocess.DEVNULL) != 0:
            logger.warning("x11vnc no instalado. Instalando con apt...")
            subprocess.run(['apt-get', 'install', '-y', 'x11vnc'], stdout=subprocess.DEVNULL)
            
        if not self._create_passwd_file():
            return False
            
        # Asegurar que el directorio de logs existe
        log_dir = os.path.dirname(self.log_file)
        if not os.path.exists(log_dir):
            try:
                os.makedirs(log_dir, exist_ok=True)
            except:
                # Fallback a /tmp si no podemos escribir en /var/log
                self.log_file = f'/tmp/x11vnc_{self.port}.log'

        try:
            # Buscar un puerto libre si el actual está ocupado
            original_port = self.port
            max_attempts = 10
            port_found = False
            
            for i in range(max_attempts):
                check_port = original_port + i
                if not self._is_port_in_use(check_port):
                    self.port = check_port
                    port_found = True
                    break
                else:
                    logger.debug(f"Puerto {check_port} ocupado, probando siguiente...")
            
            if not port_found:
                logger.error(f"❌ No se encontró puerto libre para VNC después de {max_attempts} intentos")
                return False

            # Comando: display :0, auth guess, shared, password file, port
            cmd = [
                'x11vnc',
                '-display', ':0',
                '-auth', 'guess',
                '-forever',       # No cerrar al desconectar cliente
                '-shared',        # Permitir múltiples clientes
                '-rfbauth', self.passwd_file,
                '-rfbport', str(self.port),
                '-o', self.log_file,
                '-q'              # Quiet mode
            ]
            
            # Matar SOLAMENTE nuestra instancia previa si existe (usando el archivo de passwd como filtro)
            # Esto evita conflictos con otros servicios VNC del usuario
            try:
                # Buscar PIDs de x11vnc que usen nuestro passwd_file
                p = subprocess.run(['pgrep', '-f', self.passwd_file], capture_output=True, text=True)
                if p.stdout.strip():
                    for pid in p.stdout.strip().split('\n'):
                        logger.debug(f"Matando instancia previa de VNC (PID {pid})")
                        subprocess.run(['kill', '-9', pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except:
                pass

            time.sleep(0.5)
            
            # Iniciar proceso (sin -bg para poder gestionarlo desde python)
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            
            # Esperar un momento para ver si el proceso no muere inmediatamente
            time.sleep(1)
            if self.process.poll() is not None:
                logger.error(f"❌ El proceso x11vnc terminó inmediatamente (Puerto: {self.port})")
                return False

            logger.info(f"✅ Servicio VNC iniciado en puerto {self.port}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error iniciando VNC: {e}")
            return False

    def stop(self):
        """Detener servicio VNC"""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None
            
        # Matar remanentes que usen nuestro archivo de password
        try:
            p = subprocess.run(['pgrep', '-f', self.passwd_file], capture_output=True, text=True)
            if p.stdout.strip():
                for pid in p.stdout.strip().split('\n'):
                    subprocess.run(['kill', '-9', pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except:
            pass

        if os.path.exists(self.passwd_file):
            try:
                os.remove(self.passwd_file)
            except: pass
        logger.info("🛑 Servicio VNC detenido")

    def is_running(self):
        """Verificar si el proceso sigue vivo"""
        if self.process:
             if self.process.poll() is None:
                 return True
             else:
                 # Murió silenciosamente
                 self.process = None
                 return False
        return False
        
    def get_info(self):
        """Obtener info de conexión para el servidor"""
        # Obtener IP real de la interfaz por la que salimos a internet
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
        except:
            ip = "127.0.0.1"
            
        return {
            "type": "vnc_info",
            "available": True,
            "ip": ip,
            "port": self.port,
            "password": self.token[:8] if self.token else "educontrol"
        }


class AgentConfig:
    """Configuración del agente"""
    
    def __init__(self):
        self.host = "localhost"
        self.websocket_port = "8003"
        self.http_port = "8002"
        self.token = None
        self.agent_id = self._generate_agent_id()
        self.hostname = socket.gethostname()
        self.heartbeat_interval = 30  # segundos
        self.reconnect_delay = 5  # segundos
        self.max_reconnect_attempts = None  # None = infinito
        self.auto_inventory = False  # Por defecto desactivado
        self.auto_rename = False  # Por defecto desactivado
        self.vnc_enabled = True  # Por defecto activado
        self.vnc_enabled = True  # Por defecto activado
        self.vnc_port = 5950     # Usar rango 5950+ para evitar conflictos
        self.ssl_enabled = False # Por defecto desactivado (compatibilidad)
        self.verify_ssl = False  # Por defecto desactivado (para self-signed)

    
    @property
    def server_url(self):
        """Construir URL del servidor WebSocket"""
        protocol = "wss" if self.ssl_enabled else "ws"
        return f"{protocol}://{self.host}:{self.websocket_port}/ws/agent/"
    
    @property
    def http_url(self):
        """Construir URL base HTTP del servidor"""
        protocol = "https" if self.ssl_enabled else "http"
        return f"{protocol}://{self.host}:{self.http_port}"
    
    @staticmethod
    def _generate_agent_id():
        """Generar ID único del agente basado en MAC address (prioriza Ethernet sobre WiFi)"""
        try:
            # Preferir psutil para obtener MAC consistente
            if PSUTIL_AVAILABLE:
                # Identificar interfaces Ethernet (prioridad) y WiFi
                ethernet_keywords = ['eth', 'enp', 'eno', 'ens', 'enx', 'enet']
                wifi_keywords = ['wlan', 'wifi', 'wlp', 'wlx', 'wifi0']
                
                ethernet_mac = None
                wifi_mac = None
                fallback_mac = None
                
                for iface, addrs in psutil.net_if_addrs().items():
                    # Saltar loopback
                    if iface.lower() in ['lo', 'loopback']:
                        continue
                    
                    is_ethernet = any(keyword in iface.lower() for keyword in ethernet_keywords)
                    is_wifi = any(keyword in iface.lower() for keyword in wifi_keywords)
                    
                    for addr in addrs:
                        # Detectar MAC por familia de socket
                        mac_family = None
                        if hasattr(psutil, 'AF_LINK'):
                            mac_family = psutil.AF_LINK
                        elif hasattr(socket, 'AF_LINK'):
                            mac_family = socket.AF_LINK
                        elif hasattr(socket, 'AF_PACKET'):
                            mac_family = socket.AF_PACKET
                        
                        is_mac_family = (
                            (mac_family is not None and addr.family == mac_family) or
                            addr.family == 17 or  # Linux
                            addr.family == -1     # Windows
                        )
                        
                        if is_mac_family:
                            mac = addr.address.lower()
                            # Validar MAC (no vacía, no 00:00:00:00:00:00, longitud correcta)
                            if mac and mac != '00:00:00:00:00:00' and len(mac) == 17:
                                if is_ethernet and not ethernet_mac:
                                    ethernet_mac = mac
                                elif is_wifi and not wifi_mac:
                                    wifi_mac = mac
                                elif not fallback_mac:
                                    fallback_mac = mac
                
                # Prioridad: Ethernet > WiFi > Primera interfaz válida
                selected_mac = ethernet_mac or wifi_mac or fallback_mac
                
                if selected_mac:
                    return f"agent_{selected_mac.replace(':', '')}"
            
            # Fallback: usar uuid.getnode() (puede ser inconsistente)
            mac = ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff) 
                           for ele in range(0, 8*6, 8)][::-1])
            return f"agent_{mac.replace(':', '')}"
        except:
            # Último recurso: ID aleatorio (NO recomendado)
            logger.warning("⚠️  No se pudo obtener MAC, usando ID aleatorio")
            return f"agent_{uuid.uuid4().hex[:12]}"
    
    def load_from_file(self, config_file: str):
        """Cargar configuración desde archivo JSON"""
        try:
            with open(config_file, 'r') as f:
                data = json.load(f)
                # Soporte para formato antiguo (server_url) y nuevo (host/ports)
                if 'server_url' in data:
                    # Formato antiguo: extraer host y puerto de server_url
                    import re
                    url_match = re.match(r'ws://([^:]+):(\d+)/', data.get('server_url', ''))
                    if url_match:
                        self.host = url_match.group(1)
                        self.websocket_port = url_match.group(2)
                    logger.warning("Formato antiguo de configuración detectado (server_url). "
                                 "Considera actualizar a host/websocket_port/http_port")
                else:
                    # Formato nuevo
                    self.host = data.get('host', self.host)
                    self.websocket_port = str(data.get('websocket_port', self.websocket_port))
                    self.http_port = str(data.get('http_port', self.http_port))
                
                self.token = data.get('token', self.token)
                self.heartbeat_interval = data.get('heartbeat_interval', self.heartbeat_interval)
                self.reconnect_delay = data.get('reconnect_delay', self.reconnect_delay)
                self.auto_inventory = data.get('auto_inventory', self.auto_inventory)
                self.auto_rename = data.get('auto_rename', self.auto_rename)
                self.vnc_enabled = data.get('vnc_enabled', self.vnc_enabled)
                self.vnc_enabled = data.get('vnc_enabled', self.vnc_enabled)
                self.vnc_port = data.get('vnc_port', self.vnc_port)
                self.ssl_enabled = data.get('ssl_enabled', self.ssl_enabled)
                self.verify_ssl = data.get('verify_ssl', self.verify_ssl)

                logger.info(f"Configuración cargada desde {config_file}")
                logger.info(f"Servidor: {self.host}:{self.websocket_port} (WS), {self.host}:{self.http_port} (HTTP)")
                logger.info(f"Auto-inventario: {'activado' if self.auto_inventory else 'desactivado'}")
                logger.info(f"Auto-renombrado: {'activado' if self.auto_rename else 'desactivado'}")
        except Exception as e:
            logger.error(f"Error cargando configuración: {e}")
    
    def save_to_file(self, config_file: str):
        """Guardar configuración a archivo JSON"""
        try:
            data = {
                'host': self.host,
                'websocket_port': self.websocket_port,
                'http_port': self.http_port,
                'token': self.token,
                'vnc_enabled': self.vnc_enabled,
                'vnc_port': self.vnc_port,
                'heartbeat_interval': self.heartbeat_interval,

                'reconnect_delay': self.reconnect_delay,
                'auto_inventory': self.auto_inventory,
                'auto_inventory': self.auto_inventory,
                'auto_rename': self.auto_rename,
                'ssl_enabled': self.ssl_enabled,
                'verify_ssl': self.verify_ssl
            }
            with open(config_file, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info(f"Configuración guardada en {config_file}")
        except Exception as e:
            logger.error(f"Error guardando configuración: {e}")


class CommandExecutor:
    """Ejecutor de comandos con salida en streaming"""
    
    def __init__(self, websocket, agent_id: str):
        self.websocket = websocket
        self.agent_id = agent_id
        self.running_processes = {}
    
    async def execute(self, command_id: str, command: str, args: list = None, 
                     shell: bool = True, timeout: int = 300):
        """
        Ejecutar comando y enviar salida línea por línea
        
        Args:
            command_id: ID único del comando
            command: Comando a ejecutar
            args: Argumentos del comando (si no es shell)
            shell: Si True, ejecuta en shell
            timeout: Timeout en segundos
        """
        logger.info(f"Ejecutando comando {command_id}: {command}")
        start_time = time.time()
        
        try:
            # Preparar el comando
            if shell:
                cmd = command
            else:
                cmd = [command] + (args or [])
            
            # Crear el proceso
            process = await asyncio.create_subprocess_shell(
                cmd if shell else ' '.join(cmd),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                shell=shell
            )
            
            self.running_processes[command_id] = process
            
            # Leer stdout y stderr concurrentemente
            async def read_stream(stream, stream_name):
                try:
                    while True:
                        line = await stream.readline()
                        if not line:
                            break
                        
                        output = line.decode('utf-8', errors='replace').rstrip()
                        
                        # Verificar que el websocket esté abierto antes de enviar
                        if self.websocket and self.websocket.close_code is None:
                            try:
                                await self.websocket.send(json.dumps({
                                    'type': 'command_output',
                                    'command_id': command_id,
                                    'output': output,
                                    'stream': stream_name
                                }))
                                logger.debug(f"[{command_id}] {stream_name}: {output}")
                            except Exception as send_error:
                                logger.warning(f"No se pudo enviar salida (websocket cerrado): {send_error}")
                                break  # Salir si el websocket se cerró
                        else:
                            logger.warning(f"WebSocket cerrado, deteniendo lectura de {stream_name}")
                            break
                except Exception as e:
                    logger.error(f"Error leyendo {stream_name}: {e}")
            
            # Ejecutar lecturas concurrentemente
            await asyncio.gather(
                read_stream(process.stdout, 'stdout'),
                read_stream(process.stderr, 'stderr')
            )
            
            # Esperar a que termine el proceso
            try:
                exit_code = await asyncio.wait_for(process.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                process.kill()
                exit_code = -1
                if self.websocket and self.websocket.close_code is None:
                    try:
                        await self.websocket.send(json.dumps({
                            'type': 'command_error',
                            'command_id': command_id,
                            'error': f'Timeout: El comando excedió {timeout} segundos'
                        }))
                    except:
                        pass
                logger.warning(f"Comando {command_id} terminado por timeout")
                return
            
            # Enviar completado (solo si el websocket está abierto)
            execution_time = time.time() - start_time
            
            if self.websocket and self.websocket.close_code is None:
                try:
                    await self.websocket.send(json.dumps({
                        'type': 'command_complete',
                        'command_id': command_id,
                        'exit_code': exit_code,
                        'execution_time': round(execution_time, 2)
                    }))
                    logger.info(f"Comando {command_id} completado con código {exit_code} en {execution_time:.2f}s")
                except Exception as e:
                    logger.warning(f"No se pudo enviar completado (websocket cerrado): {e}")
            else:
                logger.warning(f"Comando {command_id} completado pero websocket cerrado (exit_code: {exit_code})")
            
        except Exception as e:
            logger.error(f"Error ejecutando comando {command_id}: {e}")
            if self.websocket and self.websocket.close_code is None:
                try:
                    await self.websocket.send(json.dumps({
                        'type': 'command_error',
                        'command_id': command_id,
                        'error': str(e)
                    }))
                except Exception as send_error:
                    logger.warning(f"No se pudo enviar error (websocket cerrado): {send_error}")
        finally:
            # Limpiar
            if command_id in self.running_processes:
                del self.running_processes[command_id]
    
    async def cancel(self, command_id: str):
        """
        Cancelar un comando en ejecución
        
        Args:
            command_id: ID del comando a cancelar
        """
        if command_id not in self.running_processes:
            logger.warning(f"Comando {command_id} no está en ejecución")
            if self.websocket and self.websocket.close_code is None:
                try:
                    await self.websocket.send(json.dumps({
                        'type': 'command_error',
                        'command_id': command_id,
                        'error': 'El comando no está en ejecución o ya terminó'
                    }))
                except:
                    pass
            return
        
        process = self.running_processes[command_id]
        
        try:
            # Intentar terminar el proceso gracefully
            process.terminate()
            
            # Esperar un poco para que termine
            try:
                await asyncio.wait_for(process.wait(), timeout=2.0)
                logger.info(f"Comando {command_id} terminado gracefully")
            except asyncio.TimeoutError:
                # Si no termina, matarlo forzosamente
                process.kill()
                await process.wait()
                logger.info(f"Comando {command_id} terminado forzosamente (kill)")
            
            # Notificar cancelación al servidor
            if self.websocket and self.websocket.close_code is None:
                try:
                    await self.websocket.send(json.dumps({
                        'type': 'command_complete',
                        'command_id': command_id,
                        'exit_code': -15,  # SIGTERM
                        'execution_time': 0,
                        'cancelled': True
                    }))
                except:
                    pass
            
            logger.info(f"Comando {command_id} cancelado exitosamente")
            
        except Exception as e:
            logger.error(f"Error cancelando comando {command_id}: {e}")
            if self.websocket and self.websocket.close_code is None:
                try:
                    await self.websocket.send(json.dumps({
                        'type': 'command_error',
                        'command_id': command_id,
                        'error': f'Error cancelando comando: {str(e)}'
                    }))
                except:
                    pass
        finally:
            # Limpiar
            if command_id in self.running_processes:
                del self.running_processes[command_id]


class TerminalHandler:
    """Manejador de terminal interactivo con PTY"""
    
    def __init__(self, websocket, agent_id: str, terminal_id: str, terminal_group: str):
        self.websocket = websocket
        self.agent_id = agent_id
        self.terminal_id = terminal_id
        self.terminal_group = terminal_group
        self.process = None
        self.master_fd = None
        self.running = False
        self.read_task = None
    
    async def start(self):
        """Iniciar shell con PTY"""
        try:
            # Determinar shell según el sistema operativo
            system = platform.system()
            
            if system == 'Windows':
                # En Windows no hay PTY nativo, usar subprocess normal
                shell = 'powershell.exe' if platform.system() == 'Windows' else 'cmd.exe'
                logger.info(f"Iniciando terminal Windows: {shell}")
                await self.start_windows_shell(shell)
            else:
                # En Linux/Mac usar PTY
                # Preferir bash sobre sh para mejor soporte de terminal interactivo
                # Determinar shell
                shell = os.environ.get('SHELL', '/bin/bash')
                if shell == '/bin/sh' or not os.path.exists(shell):
                    shell = '/bin/bash'
                    
                logger.info(f"Iniciando terminal Unix con PTY: {shell}")
                await self.start_unix_pty(shell)
            
            logger.info(f"Terminal iniciado exitosamente: {self.terminal_id}")
            
        except Exception as e:
            logger.error(f"Error iniciando terminal: {e}")
            await self.send_error(f"Error iniciando terminal: {str(e)}")
    
    def _get_privileged_shell_command(self, shell: str) -> list:
        """
        Construye el comando para el shell, usando nsenter si es posible
        para escapar del sandbox de systemd (God Mode).
        """
        shell_name = os.path.basename(shell)
        
        # Flags base del shell
        if shell_name in ['bash', 'zsh']:
            cmd = [shell, '-i', '-l']
        else:
            cmd = [shell, '-i']
            
        # Intentar usar nsenter si somos root
        if os.geteuid() == 0:
            nsenter = '/usr/bin/nsenter'
            if os.path.exists(nsenter):
                # Escapar al namespace de init (PID 1)
                # -m: mount (sistema de archivos)
                # -u: uts (hostname)
                # -i: ipc
                # -n: net (red)
                return [nsenter, '-t', '1', '-m', '-u', '-i', '-n', '--'] + cmd
                
        return cmd

    async def start_unix_pty(self, shell: str):
        """Iniciar shell Unix con PTY como root"""
        import pty
        import fcntl
        import termios
        import struct
        
        # Crear PTY
        self.master_fd, slave_fd = pty.openpty()
        
        # Configurar tamaño del terminal
        fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, 
                   struct.pack('HHHH', 24, 80, 0, 0))
        
        # Configurar variables de entorno para el shell
        env = os.environ.copy()
        env['TERM'] = 'xterm-256color'
        env['COLUMNS'] = '80'
        env['LINES'] = '24'
        
        # Obtener comando privilegiado
        shell_cmd = self._get_privileged_shell_command(shell)
        
        if shell_cmd[0].endswith('nsenter'):
            logger.info("🛡️  Modo Dios activado: Terminal corriendo via nsenter")
        
        # Iniciar proceso con el PTY
        loop = asyncio.get_event_loop()
        
        def create_process():
            # Función para crear el proceso en el executor
            def preexec_fn():
                # Convertir este proceso en líder de sesión
                # Esto es necesario para que el shell tenga control de trabajos
                if hasattr(os, 'setsid'):
                    os.setsid()
            
            return subprocess.Popen(
                shell_cmd,
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                env=env,
                cwd='/root',  # Cambiar al directorio home de root
                preexec_fn=preexec_fn if hasattr(os, 'setsid') else None,
                # El proceso hereda el UID/GID del proceso padre (root)
            )
        
        self.process = await loop.run_in_executor(None, create_process)
        
        os.close(slave_fd)
        
        # Hacer el fd no bloqueante
        import fcntl
        flags = fcntl.fcntl(self.master_fd, fcntl.F_GETFL)
        fcntl.fcntl(self.master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
        
        self.running = True
        
        # Iniciar lectura de output
        self.read_task = asyncio.create_task(self.read_pty_output())
    
    async def start_windows_shell(self, shell: str):
        """Iniciar shell Windows sin PTY (fallback)"""
        self.process = await asyncio.create_subprocess_shell(
            shell,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            shell=True
        )
        
        self.running = True
        
        # Iniciar lectura de output
        self.read_task = asyncio.create_task(self.read_subprocess_output())
    
    async def read_pty_output(self):
        """Leer output del PTY y enviar al servidor (Unix)"""
        loop = asyncio.get_event_loop()
        
        while self.running and self.process:
            try:
                # Verificar si el proceso sigue vivo
                if self.process.poll() is not None:
                    logger.info(f"Proceso del terminal terminado: {self.terminal_id}")
                    await self.send_closed("Shell terminado")
                    break
                
                # Leer del PTY de forma no bloqueante
                try:
                    output = await loop.run_in_executor(
                        None,
                        os.read,
                        self.master_fd,
                        4096
                    )
                    
                    if output:
                        # Decodificar y enviar al servidor
                        text = output.decode('utf-8', errors='replace')
                        await self.send_output(text)
                    else:
                        # Si no hay datos, esperar un poco
                        await asyncio.sleep(0.01)
                        
                except (BlockingIOError, OSError):
                    # No hay datos disponibles, esperar un poco
                    await asyncio.sleep(0.01)
                
            except Exception as e:
                if self.running:
                    logger.error(f"Error leyendo PTY: {e}")
                    await self.send_error(f"Error leyendo terminal: {str(e)}")
                break
        
        await self.close()
    
    async def read_subprocess_output(self):
        """Leer output del subprocess (Windows fallback)"""
        try:
            while self.running and self.process:
                # Leer stdout
                line = await self.process.stdout.readline()
                if line:
                    text = line.decode('utf-8', errors='replace')
                    await self.send_output(text)
                else:
                    # Proceso terminado
                    await self.send_closed("Shell terminado")
                    break
                    
        except Exception as e:
            if self.running:
                logger.error(f"Error leyendo subprocess: {e}")
                await self.send_error(f"Error leyendo terminal: {str(e)}")
        
        await self.close()
    
    async def write_input(self, data: str):
        """Escribir input del usuario al terminal"""
        try:
            if not self.running:
                return
            
            system = platform.system()
            
            if system == 'Windows':
                # Windows: escribir al stdin del subprocess
                if self.process and self.process.stdin:
                    self.process.stdin.write(data.encode('utf-8'))
                    await self.process.stdin.drain()
            else:
                # Unix: escribir al PTY
                if self.master_fd:
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(
                        None,
                        os.write,
                        self.master_fd,
                        data.encode('utf-8')
                    )
        
        except Exception as e:
            logger.error(f"Error escribiendo input al terminal: {e}")
            await self.send_error(f"Error escribiendo al terminal: {str(e)}")
    
    async def resize(self, cols: int, rows: int):
        """Redimensionar terminal"""
        try:
            if platform.system() != 'Windows' and self.master_fd:
                import fcntl
                import termios
                import struct
                
                # Cambiar tamaño del PTY
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None,
                    fcntl.ioctl,
                    self.master_fd,
                    termios.TIOCSWINSZ,
                    struct.pack('HHHH', rows, cols, 0, 0)
                )
                
                logger.debug(f"Terminal redimensionado: {cols}x{rows}")
        
        except Exception as e:
            logger.error(f"Error redimensionando terminal: {e}")
    
    async def send_output(self, data: str):
        """Enviar output del terminal al servidor"""
        try:
            if self.websocket and self.websocket.close_code is None:
                message = json.dumps({
                    'type': 'terminal_output',
                    'terminal_id': self.terminal_id,
                    'data': data
                })
                
                # Enviar al grupo del terminal (TerminalConsumer lo reenviará al frontend)
                await self.websocket.send(message)
        
        except Exception as e:
            logger.error(f"Error enviando output del terminal: {e}")
    
    async def send_error(self, error_msg: str):
        """Enviar error del terminal al servidor"""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'terminal_error',
                    'terminal_id': self.terminal_id,
                    'message': error_msg
                }))
        
        except Exception as e:
            logger.error(f"Error enviando error del terminal: {e}")
    
    async def send_closed(self, message: str):
        """Notificar que el terminal se cerró"""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'terminal_closed',
                    'terminal_id': self.terminal_id,
                    'message': message
                }))
        
        except Exception as e:
            logger.error(f"Error enviando cierre del terminal: {e}")
    
    async def close(self):
        """Cerrar terminal"""
        logger.info(f"Cerrando terminal: {self.terminal_id}")
        self.running = False
        
        # Cancelar tarea de lectura
        if self.read_task:
            self.read_task.cancel()
        
        # Terminar proceso
        if self.process:
            try:
                self.process.terminate()
                # Esperar un poco para terminación graceful
                for _ in range(10):
                    if self.process.poll() is not None:
                        break
                    await asyncio.sleep(0.1)
                
                # Si no terminó, kill
                if self.process.poll() is None:
                    self.process.kill()
            except:
                pass
        
        # Cerrar PTY (Unix)
        if self.master_fd:
            try:
                os.close(self.master_fd)
            except:
                pass
        
        self.process = None
        self.master_fd = None


def collect_system_inventory():
    """
    Recopila información del sistema para el inventario
    
    Returns:
        dict: Diccionario con información del hardware y software del equipo
    """
    inventory = {}
    
    try:
        # Información básica
        inventory['hostname'] = platform.node()
        inventory['processor_architecture'] = platform.machine()
        
        # Obtener IP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            inventory['ip_address'] = s.getsockname()[0]
            s.close()
        except:
            inventory['ip_address'] = '127.0.0.1'
        
        # Obtener UUID del sistema
        try:
            if platform.system() == 'Windows':
                import subprocess
                result = subprocess.run(['wmic', 'csproduct', 'get', 'uuid'], 
                                       capture_output=True, text=True)
                uuid_str = result.stdout.strip().split('\n')[-1].strip()
                if uuid_str and uuid_str != 'UUID':
                    inventory['uuid'] = uuid_str
            elif platform.system() == 'Linux':
                try:
                    with open('/sys/class/dmi/id/product_uuid', 'r') as f:
                        inventory['uuid'] = f.read().strip()
                except:
                    pass
            elif platform.system() == 'Darwin':
                result = subprocess.run(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'],
                                       capture_output=True, text=True)
                for line in result.stdout.split('\n'):
                    if 'IOPlatformUUID' in line:
                        inventory['uuid'] = line.split('"')[3]
                        break
        except:
            pass
        
        # Sistema Operativo
        inventory['os_name'] = f"{platform.system()} {platform.release()}"
        inventory['os_version'] = platform.version()
        inventory['os_architecture'] = platform.architecture()[0]
        
        # Kernel version (para Linux/Mac)
        try:
            inventory['os_kernel_version'] = platform.release()
        except:
            pass
        
        # Información con psutil (si está disponible)
        if PSUTIL_AVAILABLE:
            # Procesador
            inventory['processor_name'] = platform.processor()
            inventory['processor_cores'] = psutil.cpu_count(logical=False)
            inventory['processor_threads'] = psutil.cpu_count(logical=True)
            
            try:
                cpu_freq = psutil.cpu_freq()
                if cpu_freq:
                    inventory['processor_speed'] = f"{cpu_freq.max:.2f} GHz" if cpu_freq.max else f"{cpu_freq.current:.2f} GHz"
            except:
                pass
            
            # Memoria RAM
            mem = psutil.virtual_memory()
            inventory['ram_total_mb'] = mem.total // (1024 * 1024)
            
            # Discos
            disks = []
            total_storage = 0
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    size_gb = usage.total // (1024**3)
                    disk_info = {
                        'name': partition.device,
                        'mountpoint': partition.mountpoint,
                        'size_gb': size_gb,
                        'type': partition.fstype,
                    }
                    disks.append(disk_info)
                    total_storage += size_gb
                except:
                    pass
            
            if disks:
                inventory['disks'] = disks
                inventory['total_storage_gb'] = total_storage
            
            # Interfaces de red
            network_interfaces = []
            ethernet_mac = None
            wifi_mac = None
            ethernet_ip = None
            wifi_ip = None
            
            # Identificar interfaces WiFi comunes
            wifi_keywords = ['wlan', 'wifi', 'wlp', 'wlx', 'wifi0']
            
            for iface, addrs in psutil.net_if_addrs().items():
                iface_data = {'name': iface}
                is_wifi = any(keyword in iface.lower() for keyword in wifi_keywords)
                is_ethernet = any(keyword in iface.lower() for keyword in ['eth', 'enp', 'eno', 'ens', 'enx', 'ethernet'])
                
                for addr in addrs:
                    if addr.family == socket.AF_INET:  # IPv4
                        ip = addr.address
                        iface_data['ip'] = ip
                        
                        # Guardar IP de Ethernet (prioridad)
                        if is_ethernet and not ethernet_ip:
                            ethernet_ip = ip
                        # Guardar IP de WiFi
                        elif is_wifi and not wifi_ip:
                            wifi_ip = ip
                    else:
                        # Detectar MAC address por familia de socket
                        # psutil usa diferentes valores según el SO:
                        # - Linux: psutil.AF_LINK (17) o socket.AF_PACKET
                        # - Windows: -1
                        # - macOS: socket.AF_LINK
                        mac_family = None
                        if hasattr(psutil, 'AF_LINK'):
                            mac_family = psutil.AF_LINK
                        elif hasattr(socket, 'AF_LINK'):
                            mac_family = socket.AF_LINK
                        elif hasattr(socket, 'AF_PACKET'):
                            mac_family = socket.AF_PACKET
                        
                        # Verificar si es una familia MAC conocida
                        is_mac_family = (
                            (mac_family is not None and addr.family == mac_family) or
                            addr.family == 17 or  # Linux común
                            addr.family == -1      # Windows
                        )
                        
                        if is_mac_family:
                            try:
                                mac = addr.address.upper()  # Normalizar a mayúsculas
                                # Validar formato MAC (XX:XX:XX:XX:XX:XX)
                                if mac and mac != '00:00:00:00:00:00' and len(mac) == 17:
                                    iface_data['mac'] = mac
                                    
                                    # Guardar MAC de Ethernet (prioridad)
                                    if is_ethernet and not ethernet_mac:
                                        ethernet_mac = mac
                                    # Guardar MAC de WiFi
                                    elif is_wifi and not wifi_mac:
                                        wifi_mac = mac
                            except:
                                pass
                
                if 'ip' in iface_data or 'mac' in iface_data:
                    network_interfaces.append(iface_data)
            
            # Asignar IP principal (prioridad: Ethernet > primera IP válida)
            if ethernet_ip:
                inventory['ip_address'] = ethernet_ip
            elif not inventory.get('ip_address'):
                # Si no hay Ethernet, usar la primera IP válida que no sea WiFi
                for iface_data in network_interfaces:
                    if 'ip' in iface_data and iface_data['ip'] != wifi_ip:
                        inventory['ip_address'] = iface_data['ip']
                        break
            
            # Asignar IP WiFi
            if wifi_ip:
                inventory['wifi_ip_address'] = wifi_ip
            
            # Asignar MAC principal (prioridad: Ethernet > primera MAC válida)
            if ethernet_mac:
                inventory['mac_address'] = ethernet_mac
            elif not inventory.get('mac_address'):
                # Si no hay Ethernet, usar la primera MAC válida que no sea WiFi
                for iface_data in network_interfaces:
                    if 'mac' in iface_data and iface_data['mac'] != wifi_mac:
                        inventory['mac_address'] = iface_data['mac']
                        break
            
            # Asignar MAC WiFi
            if wifi_mac:
                inventory['wifi_mac_address'] = wifi_mac
            
            if network_interfaces:
                inventory['network_interfaces'] = network_interfaces
            
            # Uptime
            boot_time = psutil.boot_time()
            inventory['uptime_seconds'] = int(time.time() - boot_time)
            
            # Usuarios del sistema
            try:
                users = psutil.users()
                if users:
                    inventory['system_users'] = [
                        {'name': user.name, 'terminal': user.terminal}
                        for user in users
                    ]
            except:
                pass
        
        # Información del fabricante (según el SO)
        try:
            if platform.system() == 'Windows':
                import subprocess
                # Fabricante
                result = subprocess.run(['wmic', 'computersystem', 'get', 'manufacturer'],
                                       capture_output=True, text=True)
                manufacturer = result.stdout.strip().split('\n')[-1].strip()
                if manufacturer and manufacturer != 'Manufacturer':
                    inventory['manufacturer'] = manufacturer
                
                # Modelo
                result = subprocess.run(['wmic', 'computersystem', 'get', 'model'],
                                       capture_output=True, text=True)
                model = result.stdout.strip().split('\n')[-1].strip()
                if model and model != 'Model':
                    inventory['model'] = model
                
                # Número de serie
                result = subprocess.run(['wmic', 'bios', 'get', 'serialnumber'],
                                       capture_output=True, text=True)
                serial = result.stdout.strip().split('\n')[-1].strip()
                if serial and serial != 'SerialNumber':
                    inventory['serial_number'] = serial
                
                # BIOS
                result = subprocess.run(['wmic', 'bios', 'get', 'version'],
                                       capture_output=True, text=True)
                bios = result.stdout.strip().split('\n')[-1].strip()
                if bios and bios != 'Version':
                    inventory['bios_version'] = bios
                    
            elif platform.system() == 'Linux':
                # Leer de /sys/class/dmi/id/
                try:
                    with open('/sys/class/dmi/id/sys_vendor', 'r') as f:
                        inventory['manufacturer'] = f.read().strip()
                except:
                    pass
                try:
                    with open('/sys/class/dmi/id/product_name', 'r') as f:
                        inventory['model'] = f.read().strip()
                except:
                    pass
                try:
                    with open('/sys/class/dmi/id/product_serial', 'r') as f:
                        inventory['serial_number'] = f.read().strip()
                except:
                    pass
                try:
                    with open('/sys/class/dmi/id/bios_version', 'r') as f:
                        inventory['bios_version'] = f.read().strip()
                except:
                    pass
                    
            elif platform.system() == 'Darwin':  # macOS
                result = subprocess.run(['system_profiler', 'SPHardwareDataType'],
                                       capture_output=True, text=True)
                for line in result.stdout.split('\n'):
                    line = line.strip()
                    if 'Model Name:' in line:
                        inventory['manufacturer'] = 'Apple'
                        inventory['model'] = line.split(':')[1].strip()
                    elif 'Model Identifier:' in line:
                        if 'model' not in inventory:
                            inventory['model'] = line.split(':')[1].strip()
                    elif 'Serial Number' in line:
                        inventory['serial_number'] = line.split(':')[1].strip().split()[0]
        except Exception as e:
            logger.debug(f"Error obteniendo información del fabricante: {e}")
        
        logger.info(f"📊 Información de inventario recopilada: {len(inventory)} campos")
        
    except Exception as e:
        logger.error(f"Error recopilando inventario: {e}")
    
    return inventory


# LoginMonitor ahora está en login_monitor.py


class RemoteAgent:
    """Agente remoto principal"""
    
    def __init__(self, config: AgentConfig):
        self.config = config
        self.websocket: Optional[websockets.WebSocketClientProtocol] = None
        self.executor: Optional[CommandExecutor] = None
        self.terminals: dict[str, TerminalHandler] = {}  # Terminales activos
        self.login_monitor = None  # Monitor de logins (se inicializa en connect)
        self.vnc_manager = None
        self.running = False
        self.reconnect_attempts = 0
    
    def get_system_info(self) -> dict:
        """Obtener información del sistema"""
        return {
            'os': platform.system(),
            'os_version': platform.version(),
            'platform': platform.platform(),
            'python_version': platform.python_version(),
            'processor': platform.processor(),
            'hostname': self.config.hostname,
            'agent_id': self.config.agent_id
        }
    
    def get_mac_address(self) -> Optional[str]:
        """Obtener MAC address principal del sistema"""
        try:
            if PSUTIL_AVAILABLE:
                # Usar psutil para obtener MAC de Ethernet (prioridad)
                network_interfaces = psutil.net_if_addrs()
                ethernet_mac = None
                
                # Identificar interfaces Ethernet con prioridad
                # Prioridad: eno (onboard), ens (slot), enp (pci), eth (legacy), enx (usb)
                # Obtener todas las interfaces y ordenarlas para consistencia
                interfaces = sorted(network_interfaces.keys())
                
                # Definir prioridades
                wired_patterns = ['eno', 'ens', 'enp', 'eth', 'enx', 'ethernet']
                wifi_patterns = ['wlan', 'wifi', 'wl']
                
                # Función auxiliar para chequear si tiene IP
                def has_ip(iface_addrs):
                    for addr in iface_addrs:
                        if addr.family == socket.AF_INET and not addr.address.startswith('127.'):
                            return True
                    return False
                
                # 1. Buscar Wired con IP
                for pattern in wired_patterns:
                    for iface in interfaces:
                        if iface.lower().startswith(pattern):
                            addrs = network_interfaces[iface]
                            if has_ip(addrs):
                                for addr in addrs:
                                    if addr.family == psutil.AF_LINK:
                                        mac = addr.address.upper()
                                        if mac and mac != '00:00:00:00:00:00':
                                            return mac
                
                # 2. Buscar WiFi con IP
                for pattern in wifi_patterns:
                    for iface in interfaces:
                        if iface.lower().startswith(pattern):
                            addrs = network_interfaces[iface]
                            if has_ip(addrs):
                                for addr in addrs:
                                    if addr.family == psutil.AF_LINK:
                                        mac = addr.address.upper()
                                        if mac and mac != '00:00:00:00:00:00':
                                            return mac
                                            
                # 3. Fallback: Cualquier Wired (aunque no tenga IP)
                for pattern in wired_patterns:
                    for iface in interfaces:
                        if iface.lower().startswith(pattern):
                            addrs = network_interfaces[iface]
                            for addr in addrs:
                                if addr.family == psutil.AF_LINK:
                                    mac = addr.address.upper()
                                    if mac and mac != '00:00:00:00:00:00':
                                        return mac
                
                # Si no hay Ethernet, buscar cualquier MAC válida
                for iface, addrs in network_interfaces.items():
                    if iface.lower() in ['lo', 'loopback']:
                        continue
                    
                    for addr in addrs:
                        if addr.family == psutil.AF_LINK:
                            mac = addr.address.upper()
                            if mac and mac != '00:00:00:00:00:00':
                                return mac
            
            # Fallback: usar uuid.getnode()
            mac = ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff) 
                           for ele in range(0, 8*6, 8)][::-1])
            return mac.upper() if mac else None
            
        except Exception as e:
            logger.error(f"Error obteniendo MAC address: {e}")
            return None
    
    def rename_hostname(self, new_hostname: str) -> bool:
        """Renombrar el hostname del sistema (solo Linux)"""
        try:
            system = platform.system()
            
            if system != 'Linux':
                logger.warning(f"Renombrado de hostname solo soportado en Linux (sistema actual: {system})")
                return False
            
            # Linux: usar hostnamectl
            result = subprocess.run(
                ['hostnamectl', 'set-hostname', new_hostname],
                capture_output=True,
                text=True,
                check=False
            )
            if result.returncode == 0:
                logger.info(f"✅ Hostname renombrado a: {new_hostname}")
                # Actualizar también /etc/hostname
                try:
                    with open('/etc/hostname', 'w') as f:
                        f.write(new_hostname + '\n')
                except Exception as e:
                    logger.warning(f"No se pudo actualizar /etc/hostname: {e}")
                return True
            else:
                logger.error(f"Error renombrando hostname: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Error renombrando hostname: {e}")
            return False
    
    async def check_and_rename_hostname(self):
        """Verificar si debe renombrar el hostname y hacerlo si es necesario (solo Linux)"""
        if not self.config.auto_rename:
            logger.debug("Auto-renombrado desactivado")
            return
        
        # Solo funcionar en Linux
        if platform.system() != 'Linux':
            logger.debug(f"Auto-renombrado solo disponible en Linux (sistema actual: {platform.system()})")
            return
        
        if not REQUESTS_AVAILABLE:
            logger.warning("⚠️  requests no disponible, no se puede verificar renombrado")
            return
        
        try:
            # Obtener MAC address
            mac = self.get_mac_address()
            if not mac:
                logger.warning("⚠️  No se pudo obtener MAC address, no se puede verificar renombrado")
                return
            
            current_hostname = self.config.hostname
            
            logger.info(f"🔍 Verificando si debe renombrarse: MAC={mac}, Hostname={current_hostname}")
            
            # Llamar a la API
            check_url = f"{self.config.http_url}/api/hosts/agent/check-rename/"
            
            headers = {'Content-Type': 'application/json'}
            if self.config.token:
                headers['Authorization'] = f'Token {self.config.token}'
            
            response = requests.post(
                check_url,
                json={
                    'mac': mac,
                    'hostname': current_hostname
                },
                headers=headers,
                timeout=10,
                verify=self.config.verify_ssl
            )
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get('should_rename'):
                    target_hostname = data.get('target_hostname')
                    logger.info(f"📝 Debe renombrarse de '{current_hostname}' a '{target_hostname}'")
                    
                    # Renombrar
                    if self.rename_hostname(target_hostname):
                        logger.info(f"✅ Hostname renombrado exitosamente a: {target_hostname}")
                        # Actualizar el hostname en la configuración
                        self.config.hostname = target_hostname
                        
                        # Notificar al servidor que se renombró (para auditoría)
                        try:
                            notify_url = f"{self.config.http_url}/api/hosts/agent/notify-rename/"
                            requests.post(
                                notify_url,
                                json={
                                    'agent_id': self.config.agent_id,
                                    'mac': mac,
                                    'old_hostname': current_hostname,
                                    'new_hostname': target_hostname
                                },
                                headers=headers,
                                timeout=10,
                                verify=self.config.verify_ssl
                            )
                        except Exception as e:
                            logger.warning(f"No se pudo notificar renombrado al servidor: {e}")
                    else:
                        logger.error(f"❌ Error al renombrar hostname")
                else:
                    if data.get('registered'):
                        logger.info(f"ℹ️  Dispositivo registrado, hostname coincide: {current_hostname}")
                    else:
                        logger.info(f"ℹ️  Dispositivo no registrado en LDAP")
            else:
                logger.error(f"❌ Error verificando renombrado: HTTP {response.status_code}")
                logger.debug(f"Respuesta: {response.text}")
        
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Error de conexión verificando renombrado: {e}")
        except Exception as e:
            logger.error(f"❌ Error verificando renombrado: {e}")
            
    async def check_puppet_stuck(self):
        """Verificar si puppet agent está atascado por problemas de certificado y notificar al servidor"""
        if platform.system() != 'Linux':
            return
            
        if not REQUESTS_AVAILABLE:
            return
            
        try:
            logger.debug("🔍 Verificando estado del agente puppet...")
            
            # Revisar el log de puppet (usar tail para las últimas líneas)
            log_paths = ['/var/log/puppetlabs/puppet/puppet.log', '/var/log/puppet/puppet.log']
            stuck = False
            
            for path in log_paths:
                if os.path.exists(path):
                    # Check for cert errors in the last 100 lines
                    result = subprocess.run(
                        ['tail', '-n', '100', path],
                        capture_output=True, text=True, check=False
                    )
                    
                    if result.returncode == 0:
                        output = result.stdout.lower()
                        if 'certificate verify failed' in output or 'certificate revoked' in output:
                            stuck = True
                            logger.warning(f"⚠️ Detectado error de certificado puppet en {path}")
                            break
            
            # Alternative: check service status via syslog/journalctl if log file not found
            if not stuck and os.path.exists('/bin/journalctl'):
                result = subprocess.run(
                    ['journalctl', '-u', 'puppet', '-n', '50', '--no-pager'],
                    capture_output=True, text=True, check=False
                )
                if result.returncode == 0:
                    output = result.stdout.lower()
                    if 'certificate verify failed' in output or 'certificate revoked' in output:
                        stuck = True
                        logger.warning("⚠️ Detectado error de certificado puppet en journalctl")
            
            if stuck:
                logger.info("🛠️ Intentando recuperar puppet agent (borrando certificados locales)")
                # Delete puppet ssl directory
                ssl_paths = ['/var/lib/puppet/ssl', '/etc/puppetlabs/puppet/ssl']
                for ssl_path in ssl_paths:
                    if os.path.exists(ssl_path):
                        subprocess.run(['rm', '-rf', ssl_path], check=False)
                        logger.info(f"🗑️ Directorio {ssl_path} borrado.")
                
                # Notify server to run `puppetserver ca clean`
                mac = self.get_mac_address()
                current_hostname = self.config.hostname
                
                notify_url = f"{self.config.http_url}/api/hosts/agent/puppet-stuck/"
                headers = {'Content-Type': 'application/json'}
                if self.config.token:
                    headers['Authorization'] = f'Token {self.config.token}'
                
                logger.info("📤 Notificando al servidor para limpiar certificado en puppetmaster...")
                response = requests.post(
                    notify_url,
                    json={
                        'mac': mac,
                        'hostname': current_hostname,
                        'agent_id': self.config.agent_id
                    },
                    headers=headers,
                    timeout=10,
                    verify=self.config.verify_ssl
                )
                
                if response.status_code == 200:
                    logger.info("✅ Servidor notificado correctamente sobre problema de puppet.")
                    # Restart puppet service so it regenerates cert
                    logger.info("🔄 Reiniciando servicio puppet local...")
                    subprocess.run(['systemctl', 'restart', 'puppet'], check=False)
                else:
                    logger.error(f"❌ Error notificando al servidor (HTTP {response.status_code}): {response.text}")

        except Exception as e:
            logger.error(f"❌ Error comprobando estado de puppet: {e}")
            
    async def send_heartbeat(self):
        """Enviar heartbeat periódico y monitorear servicios"""
        while self.running and self.websocket:
            try:
                await asyncio.sleep(self.config.heartbeat_interval)
                if self.websocket and self.websocket.close_code is None:
                    await self.websocket.send(json.dumps({
                        'type': 'heartbeat',
                        'timestamp': datetime.now().isoformat(),
                        'agent_id': self.config.agent_id
                    }))
                    logger.debug("Heartbeat enviado")
                    
                    # Monitorear VNC
                    if self.config.vnc_enabled and self.vnc_manager:
                        if not self.vnc_manager.is_running():
                            logger.warning("⚠️ Servicio VNC caído, reiniciando...")
                            if self.vnc_manager.start():
                                await self.send_json(self.vnc_manager.get_info())
                    elif not self.config.vnc_enabled and self.vnc_manager:
                        if self.vnc_manager.is_running():
                            logger.info("🛑 Servicio VNC desactivado por configuración, deteniendo...")
                            self.vnc_manager.stop()

            except Exception as e:
                logger.error(f"Error enviando heartbeat o monitoreando VNC: {e}")
                break

    async def send_json(self, data):
        """Enviar JSON por WebSocket"""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps(data))
                return True
        except Exception as e:
            logger.error(f"Error enviando JSON: {e}")
        return False

    
    async def _send_login_notification(self, session_data):
        """Enviar notificación de login por WebSocket (método async)"""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'user_login',
                    'agent_id': self.config.agent_id,
                    'username': session_data['username'],
                    'terminal': session_data['terminal'],
                    'session_type': session_data['session_type'],
                    'host': session_data.get('host', 'local'),
                    'timestamp': datetime.now().isoformat(),
                }))
                logger.info(f"👤 Login detectado: {session_data['username']} en {session_data['terminal']}")
        except Exception as e:
            logger.error(f"Error enviando notificación de login: {e}")
    
    async def _send_logout_notification(self, session_data):
        """Enviar notificación de logout por WebSocket (método async)"""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'user_logout',
                    'agent_id': self.config.agent_id,
                    'username': session_data['username'],
                    'terminal': session_data['terminal'],
                    'session_type': session_data['session_type'],
                    'timestamp': datetime.now().isoformat(),
                }))
                logger.info(f"👤 Logout detectado: {session_data['username']} de {session_data['terminal']}")
        except Exception as e:
            logger.error(f"Error enviando notificación de logout: {e}")
    
    async def send_agent_info(self):
        """Enviar información del agente al servidor"""
        try:
            info = self.get_system_info()
            # Obtener IP local
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                info['ip_address'] = s.getsockname()[0]
                s.close()
            except:
                info['ip_address'] = 'unknown'
            
            await self.websocket.send(json.dumps({
                'type': 'agent_info',
                **info
            }))
            logger.info(f"Información del agente enviada: {info['hostname']} ({info['ip_address']})")
        except Exception as e:
            logger.error(f"Error enviando información del agente: {e}")
    
    async def send_inventory_update(self):
        """Enviar actualización de inventario al servidor vía HTTP"""
        if not REQUESTS_AVAILABLE:
            logger.warning("⚠️  requests no disponible, no se puede enviar inventario")
            return
        
        try:
            logger.info("📦 Recopilando información del sistema para inventario...")
            inventory = collect_system_inventory()
            
            # Agregar agent_id
            inventory['agent_id'] = self.config.agent_id
            
            # Usar la URL HTTP del servidor
            inventory_url = f"{self.config.http_url}/api/inventory/update/"
            
            logger.info(f"📤 Enviando inventario a {inventory_url}...")
            
            # Preparar headers con autenticación
            headers = {'Content-Type': 'application/json'}
            
            # Agregar token si está configurado
            if hasattr(self.config, 'token') and self.config.token:
                headers['Authorization'] = f'Token {self.config.token}'
                logger.debug(f"🔑 Usando token de autenticación")
            
            # Enviar inventario al servidor
            response = requests.post(
                inventory_url,
                json=inventory,
                headers=headers,
                timeout=10,
                verify=self.config.verify_ssl
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get('created'):
                    logger.info(f"✅ Equipo registrado en inventario: {inventory.get('hostname')}")
                else:
                    updated = result.get('updated_fields', [])
                    if updated:
                        logger.info(f"✅ Inventario actualizado. Campos modificados: {', '.join(updated)}")
                    else:
                        logger.info(f"✅ Inventario verificado (sin cambios)")
            else:
                logger.error(f"❌ Error enviando inventario: HTTP {response.status_code}")
                logger.debug(f"Respuesta: {response.text}")
        
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Error de conexión enviando inventario: {e}")
        except Exception as e:
            logger.error(f"❌ Error enviando inventario: {e}")
    
    async def handle_message(self, message: str):
        """Manejar mensajes del servidor"""
        try:
            data = json.loads(message)
            msg_type = data.get('type')
            
            logger.debug(f"Mensaje recibido: {msg_type}")
            
            if msg_type == 'connected':
                logger.info(f"✅ Conectado al servidor: {data.get('message')}")
                await self.send_agent_info()
                
                # Iniciar servicio VNC si está configurado
                if self.config.vnc_enabled:
                    if not self.vnc_manager:
                        self.vnc_manager = VNCManager(self.config.token, self.config.vnc_port)
                    
                    if self.vnc_manager.start():
                        vnc_info = self.vnc_manager.get_info()
                        await self.send_json(vnc_info)
                        logger.info(f"🖥️  Servicio VNC activo en {vnc_info['ip']}:{vnc_info['port']}")
                else:
                    logger.info("ℹ️ Servicio VNC desactivado por configuración")

                
                # Enviar inventario al servidor solo si está activado
                if self.config.auto_inventory:
                    logger.info("📦 Auto-inventario activado, enviando datos...")
                    await self.send_inventory_update()
                else:
                    logger.info("ℹ️  Auto-inventario desactivado (configurar 'auto_inventory': true para activar)")
                # Verificar y renombrar hostname si está activado
                if self.config.auto_rename:
                    logger.info("📝 Auto-renombrado activado, verificando...")
                    await self.check_and_rename_hostname()
                else:
                    logger.debug("ℹ️  Auto-renombrado desactivado (configurar 'auto_rename': true para activar)")
                
                # Verify puppet status
                await self.check_puppet_stuck()
            
            elif msg_type == 'execute_command':
                # Ejecutar comando
                command_id = data.get('command_id')
                command = data.get('command')
                args = data.get('args', [])
                shell = data.get('shell', True)
                timeout = data.get('timeout', 300)
                
                logger.info(f"📨 Comando recibido [{command_id}]: {command}")
                
                # Ejecutar en tarea separada para no bloquear
                asyncio.create_task(
                    self.executor.execute(command_id, command, args, shell, timeout)
                )
            
            elif msg_type == 'cancel_command':
                # Cancelar comando en ejecución
                command_id = data.get('command_id')
                logger.info(f"🛑 Cancelación recibida para comando [{command_id}]")
                
                # Cancelar en tarea separada para no bloquear
                asyncio.create_task(
                    self.executor.cancel(command_id)
                )
            
            elif msg_type == 'heartbeat_ack':
                logger.debug("Heartbeat ACK recibido")
            
            elif msg_type == 'ping':
                # Responder a ping
                await self.websocket.send(json.dumps({
                    'type': 'pong',
                    'timestamp': data.get('timestamp')
                }))
            
            elif msg_type == 'start_terminal':
                # Iniciar terminal interactivo
                terminal_id = data.get('terminal_id')
                terminal_group = data.get('terminal_group')
                
                logger.info(f"🖥️  Iniciando terminal [{terminal_id}]")
                
                # Crear y iniciar terminal
                terminal = TerminalHandler(
                    self.websocket,
                    self.config.agent_id,
                    terminal_id,
                    terminal_group
                )
                self.terminals[terminal_id] = terminal
                
                # Iniciar en tarea separada
                asyncio.create_task(terminal.start())
            
            elif msg_type == 'terminal_input':
                # Input del usuario para el terminal
                terminal_id = data.get('terminal_id')
                input_data = data.get('data', '')
                
                if terminal_id in self.terminals:
                    await self.terminals[terminal_id].write_input(input_data)
                else:
                    logger.warning(f"Terminal {terminal_id} no encontrado")
            
            elif msg_type == 'terminal_resize':
                # Redimensionar terminal
                terminal_id = data.get('terminal_id')
                cols = data.get('cols', 80)
                rows = data.get('rows', 24)
                
                if terminal_id in self.terminals:
                    await self.terminals[terminal_id].resize(cols, rows)
                else:
                    logger.warning(f"Terminal {terminal_id} no encontrado para resize")
            
            elif msg_type == 'close_terminal':
                # Cerrar terminal
                terminal_id = data.get('terminal_id')
                
                logger.info(f"🛑 Cerrando terminal [{terminal_id}]")
                
                if terminal_id in self.terminals:
                    await self.terminals[terminal_id].close()
                    del self.terminals[terminal_id]
                else:
                    logger.warning(f"Terminal {terminal_id} no encontrado para cerrar")
            
            else:
                logger.warning(f"Tipo de mensaje desconocido: {msg_type}")
        
        except json.JSONDecodeError:
            logger.error(f"Error decodificando mensaje JSON: {message}")
        except Exception as e:
            logger.error(f"Error manejando mensaje: {e}")
    
    async def connect(self):
        """Conectar al servidor WebSocket"""
        # Construir URL con parámetros
        url = f"{self.config.server_url}?agent_id={self.config.agent_id}&hostname={self.config.hostname}"
        
        logger.info(f"🔌 Conectando a {url}...")
        
        try:
            # Preparar headers adicionales (token de autenticación)
            extra_headers = {}
            if self.config.token:
                extra_headers['Authorization'] = f'Token {self.config.token}'
            
            # Configurar contexto SSL si es necesario
            ssl_context = None
            if self.config.ssl_enabled:
                ssl_context = ssl.create_default_context()
                if not self.config.verify_ssl:
                    ssl_context.check_hostname = False
                    ssl_context.verify_mode = ssl.CERT_NONE

            # Conectar al WebSocket
            self.websocket = await websockets.connect(
                url,
                ping_interval=20,
                ping_timeout=10,
                extra_headers=extra_headers,
                ssl=ssl_context
            )
            
            self.executor = CommandExecutor(self.websocket, self.config.agent_id)
            self.reconnect_attempts = 0
            
            logger.info(f"✅ Conectado al servidor como {self.config.agent_id}")
            
            # Inicializar LoginMonitor si es la primera conexión
            if self.login_monitor is None and LOGIN_MONITOR_AVAILABLE:
                self.login_monitor = LoginMonitor(
                    agent_id=self.config.agent_id,
                    http_url=self.config.http_url,
                    token=self.config.token
                )
                
                # Guardar referencia al event loop principal
                main_loop = asyncio.get_event_loop()
                
                # Configurar callbacks para enviar notificaciones por WebSocket
                def on_login(session_data):
                    """Callback thread-safe para login"""
                    if self.websocket and self.websocket.close_code is None:
                        asyncio.run_coroutine_threadsafe(
                            self._send_login_notification(session_data),
                            main_loop
                        )
                
                def on_logout(session_data):
                    """Callback thread-safe para logout"""
                    if self.websocket and self.websocket.close_code is None:
                        asyncio.run_coroutine_threadsafe(
                            self._send_logout_notification(session_data),
                            main_loop
                        )
                
                self.login_monitor.set_login_callback(on_login)
                self.login_monitor.set_logout_callback(on_logout)
                self.login_monitor.start()
            
            return True
        
        except Exception as e:
            logger.error(f"❌ Error conectando: {e}")
            return False
    
    async def listen(self):
        """Escuchar mensajes del servidor"""
        try:
            # Iniciar heartbeat
            heartbeat_task = asyncio.create_task(self.send_heartbeat())
            
            # Escuchar mensajes
            async for message in self.websocket:
                await self.handle_message(message)
            
            heartbeat_task.cancel()
            
        except websockets.exceptions.ConnectionClosed:
            logger.warning("⚠️  Conexión cerrada por el servidor")
        except Exception as e:
            logger.error(f"Error en conexión: {e}")
    
    async def run(self):
        """Ejecutar el agente con reconexión automática"""
        self.running = True
        logger.info(f"🚀 Iniciando agente {self.config.agent_id}")
        logger.info(f"   Hostname: {self.config.hostname}")
        logger.info(f"   Sistema: {platform.system()} {platform.release()}")
        
        while self.running:
            try:
                # Intentar conectar
                if await self.connect():
                    # Escuchar mensajes
                    await self.listen()
                
                # Si llegamos aquí, la conexión se cerró
                if self.running:
                    self.reconnect_attempts += 1
                    
                    # Verificar límite de reintentos
                    if (self.config.max_reconnect_attempts and 
                        self.reconnect_attempts >= self.config.max_reconnect_attempts):
                        logger.error(f"❌ Máximo de reintentos alcanzado ({self.reconnect_attempts})")
                        break
                    
                    logger.info(f"🔄 Reintentando conexión en {self.config.reconnect_delay}s... "
                              f"(intento {self.reconnect_attempts})")
                    await asyncio.sleep(self.config.reconnect_delay)
            
            except KeyboardInterrupt:
                logger.info("⚠️  Interrupción del usuario")
                self.running = False
                break
            except Exception as e:
                logger.error(f"Error inesperado: {e}")
                if self.running:
                    await asyncio.sleep(self.config.reconnect_delay)
        
        # Limpieza
        if self.login_monitor:
            self.login_monitor.stop()
        
        if self.websocket and self.websocket.close_code is None:
            await self.websocket.close()
        
        logger.info("👋 Agente detenido")
    
    def stop(self):
        """Detener el agente"""
        self.running = False
        if self.login_monitor:
            self.login_monitor.stop()
        if self.vnc_manager:
            self.vnc_manager.stop()


def parse_arguments():
    """Parsear argumentos de línea de comandos"""
    parser = argparse.ArgumentParser(
        description='EduControl Remote Agent - Agente remoto para gestión de equipos',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--server',
        type=str,
        help='URL del servidor WebSocket (ej: ws://localhost:8003/ws/agent/)'
    )
    
    parser.add_argument(
        '--token',
        type=str,
        help='Token de autenticación (opcional)'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        default='agent_config.json',
        help='Archivo de configuración JSON (default: agent_config.json)'
    )
    
    parser.add_argument(
        '--generate-config',
        action='store_true',
        help='Generar archivo de configuración de ejemplo y salir'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Activar modo debug (logs detallados)'
    )
    
    return parser.parse_args()


def main():
    """Función principal"""
    args = parse_arguments()
    
    # Configurar nivel de log
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
        logger.setLevel(logging.DEBUG)
    
    # Crear configuración
    config = AgentConfig()
    
    # Generar configuración de ejemplo si se solicita
    if args.generate_config:
        config.save_to_file('agent_config.example.json')
        print(f"✅ Configuración de ejemplo generada: agent_config.example.json")
        return
    
    # Cargar configuración desde archivo
    # Buscar en orden: argumento CLI > /etc/educontrol/ > directorio actual
    config_file = None
    
    if args.config and args.config != 'agent_config.json':
        # Se especificó un archivo específico
        config_file = Path(args.config)
    else:
        # Buscar en ubicaciones estándar
        system_config = Path('/etc/educontrol/agent_config.json')
        local_config = Path('agent_config.json')
        
        if system_config.exists():
            config_file = system_config
            logger.info("📋 Usando configuración del sistema: /etc/educontrol/agent_config.json")
        elif local_config.exists():
            config_file = local_config
            logger.info("📋 Usando configuración local: agent_config.json")
    
    if config_file and config_file.exists():
        config.load_from_file(str(config_file))
    else:
        logger.warning("⚠️  No se encontró archivo de configuración, usando valores por defecto")
    
    # Sobrescribir con argumentos de línea de comandos
    if args.server:
        config.server_url = args.server
    if args.token:
        config.token = args.token
    
    # Validar configuración
    if not config.server_url:
        logger.error("❌ No se especificó URL del servidor. Usa --server o --config")
        sys.exit(1)
    
    # Crear y ejecutar agente
    agent = RemoteAgent(config)
    
    try:
        asyncio.run(agent.run())
    except KeyboardInterrupt:
        logger.info("\n⚠️  Deteniendo agente...")
        agent.stop()


if __name__ == '__main__':
    main()


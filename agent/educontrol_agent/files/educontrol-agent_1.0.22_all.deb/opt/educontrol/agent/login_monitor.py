#!/usr/bin/env python3
"""
Login Monitor for EduControl Agent
===================================

Monitor de logins/logouts de usuarios en Linux usando D-Bus (systemd-logind).
Ejecuta en un thread separado y se comunica con el agente principal mediante
callbacks síncronos.
"""

import logging
import platform
import subprocess
import threading
import time
import sys
from datetime import datetime
from typing import Optional, Callable, Dict

logger = logging.getLogger('LoginMonitor')


class LoginMonitor:
    """
    Monitor de logins/logouts de usuarios en Linux usando D-Bus (systemd-logind).
    Método más confiable que leer utmp, usando señales del sistema.
    """
    
    def __init__(self, agent_id: str, http_url: str, token: Optional[str] = None):
        """
        Args:
            agent_id: ID del agente
            http_url: URL base HTTP del servidor (ej: http://localhost:8002)
            token: Token de autenticación opcional
        """
        self.agent_id = agent_id
        self.http_url = http_url
        self.token = token
        self.running = False
        self.monitor_thread = None
        self.active_sessions = {}  # {session_id: {'user': username, 'uid': uid, 'login_time': timestamp}}
        self.min_uid_monitor = 1000  # Solo monitorear usuarios normales (no sistema)
        self.last_login_time = {}  # {username: timestamp} - Debounce para login
        self.last_logout_time = {}  # {username: timestamp} - Debounce para logout
        self.debounce_seconds = 10  # Ignorar login/logout repetidos en menos de N segundos
        
        # Callbacks para notificaciones (se llamarán desde thread, deben ser thread-safe)
        self.on_login_callback: Optional[Callable] = None
        self.on_logout_callback: Optional[Callable] = None
        
        # Verificar disponibilidad de D-Bus
        self.available = False
        if platform.system() == 'Linux':
            try:
                import dbus
                import dbus.mainloop.glib
                from gi.repository import GLib
                self.dbus = dbus
                self.dbus_mainloop = dbus.mainloop.glib
                self.GLib = GLib
                self.available = True
                logger.info("✅ D-Bus disponible para monitoreo de logins")
            except ImportError as e:
                logger.warning(f"⚠️  Error importando librerías D-Bus: {e}")
                logger.warning("⚠️  Instalar: apt install python3-dbus python3-gi")
                logger.debug(f"Python path: {sys.path}")
            except Exception as e:
                logger.error(f"❌ Error inesperado al cargar D-Bus: {e}")
        
        if not self.available:
            logger.info("ℹ️  Monitoreo de logins no disponible (requiere Linux con D-Bus)")
    
    def set_login_callback(self, callback: Callable[[Dict], None]):
        """
        Establecer callback para eventos de login.
        El callback recibirá un dict con: username, terminal, session_type, host
        """
        self.on_login_callback = callback
    
    def set_logout_callback(self, callback: Callable[[Dict], None]):
        """
        Establecer callback para eventos de logout.
        El callback recibirá un dict con: username, terminal, session_type, host
        """
        self.on_logout_callback = callback
    
    def get_session_details_via_cli(self, session_id):
        """
        Obtener detalles de una sesión usando loginctl.
        Returns: (username, uid, session_type, session_class, state)
        """
        try:
            sid_str = str(session_id)
            # Usamos formato key=value sin --value para mayor robustez
            output = subprocess.check_output(
                ['loginctl', 'show-session', sid_str, '-p', 'Name', '-p', 'User', '-p', 'Type', '-p', 'Class', '-p', 'State'],
                stderr=subprocess.STDOUT,
                timeout=5
            ).decode('utf-8')
            
            props = {}
            for line in output.splitlines():
                if '=' in line:
                    key, value = line.split('=', 1)
                    props[key.strip()] = value.strip()
            
            user_name = props.get('Name', 'Desconocido')
            user_id = props.get('User', 'N/A')
            session_type = props.get('Type', 'unknown')
            session_class = props.get('Class', 'unknown')
            session_state = props.get('State', 'unknown')
            
            return user_name, user_id, session_type, session_class, session_state
        except Exception as e:
            logger.debug(f"Error obteniendo detalles de sesión {session_id}: {e}")
            return "Error/Expirado", "N/A", "unknown", "unknown", "unknown"
    
    def sync_initial_sessions(self):
        """
        Sincronizar sesiones existentes al arrancar el monitor.
        """
        logger.info("--- Sincronizando sesiones actuales ---")
        try:
            output = subprocess.check_output(
                ['loginctl', 'list-sessions', '--no-legend'],
                stderr=subprocess.DEVNULL,
                timeout=5
            ).decode('utf-8')
            
            logger.info(f"Salida raw de list-sessions:\n{output}")
            
            for line in output.splitlines():
                parts = line.split()
                if parts:
                    s_id = str(parts[0])
                    u_name, u_id, s_type, s_class, s_state = self.get_session_details_via_cli(s_id)
                    
                    logger.info(f"Analizando sesión {s_id}: User={u_name}({u_id}), Type={s_type}, Class={s_class}, State={s_state}")

                    # Filtrar: solo usuarios normales y sesiones de usuario real (no temporales)
                    if (u_id.isdigit() and int(u_id) >= self.min_uid_monitor and 
                        s_class in ['user', 'greeter'] and s_type in ['x11', 'wayland', 'tty'] and
                        s_state in ['active', 'online']):
                        
                        self.active_sessions[s_id] = {
                            'user': u_name,
                            'uid': u_id,
                            'login_time': time.time(),
                            'type': s_type,
                            'class': s_class,
                            'state': s_state
                        }
                        logger.info(f" -> En memoria: {u_name} (Sesión: {s_id}, Tipo: {s_type}, Clase: {s_class})")
                        
                        # Registrar sesión inicial en BD
                        session_data = {
                            'username': u_name,
                            'terminal': s_id,
                            'session_type': 'existing',
                            'host': 'local'
                        }
                        # Registrar de forma síncrona
                        self.register_login_http(session_data)
                    else:
                        logger.info(f" -> Ignorada por filtros: UID={u_id}, Class={s_class}, Type={s_type}, State={s_state}")
            
            logger.info(f"Sesiones activas sincronizadas: {len(self.active_sessions)}")
        except Exception as e:
            logger.error(f"Error sincronizando sesiones: {e}")
        logger.info("---------------------------------------")
    
    def handle_session_new(self, session_id, user_path):
        """
        Handler para señal SessionNew de D-Bus (login detectado).
        Este método se ejecuta en el thread de D-Bus, NO en el event loop de asyncio.
        """
        # Convertir a string de Python puro
        s_id = str(session_id)
        
        u_name, u_id, s_type, s_class, s_state = self.get_session_details_via_cli(s_id)
        
        # Filtrar por UID mínimo (solo usuarios normales)
        if not u_id.isdigit() or int(u_id) < self.min_uid_monitor:
            logger.debug(f"Sesión ignorada: UID={u_id} < {self.min_uid_monitor}")
            return
        
        # Filtrar sesiones temporales/no interactivas
        # Solo registrar: user sessions de tipo x11/wayland/tty
        if s_class not in ['user', 'greeter'] or s_type not in ['x11', 'wayland', 'tty']:
            logger.debug(f"Sesión temporal ignorada: {u_name} - Tipo: {s_type}, Clase: {s_class}")
            return
        
        # Debounce: ignorar si el mismo usuario hizo login hace menos de N segundos
        current_time = time.time()
        last_login = self.last_login_time.get(u_name, 0)
        if current_time - last_login < self.debounce_seconds:
            logger.debug(f"Login duplicado ignorado: {u_name} (hace {current_time - last_login:.1f}s)")
            return
        
        self.last_login_time[u_name] = current_time
        
        # Guardar en memoria
        self.active_sessions[s_id] = {
            'user': u_name,
            'uid': u_id,
            'login_time': current_time,
            'type': s_type,
            'class': s_class,
            'state': s_state
        }
        
        logger.info(f"🟢 LOGIN: Usuario: {u_name} (UID: {u_id}) - Sesión: {s_id} [Tipo: {s_type}, Clase: {s_class}, State: {s_state}]")
        
        # Preparar datos de sesión
        session_data = {
            'username': u_name,
            'terminal': s_id,
            'session_type': 'login',
            'host': 'local'
        }
        
        # Llamar callback síncrono si existe
        if self.on_login_callback:
            try:
                self.on_login_callback(session_data)
            except Exception as e:
                logger.error(f"Error en callback de login: {e}")
        
        # Registrar en BD vía HTTP (sync)
        threading.Thread(target=self.register_login_http, args=(session_data,), daemon=True).start()
    
    def handle_session_removed(self, session_id, user_path):
        """
        Handler para señal SessionRemoved de D-Bus (logout detectado).
        Este método se ejecuta en el thread de D-Bus, NO en el event loop de asyncio.
        """
        # Convertir a string de Python puro
        s_id = str(session_id)
        
        logger.info(f"🔍 Señal SessionRemoved recibida para sesión: {s_id}")
        
        user_info = self.active_sessions.get(s_id)
        
        if user_info:
            u_name = user_info['user']
            
            # Debounce: ignorar si el mismo usuario hizo logout hace menos de N segundos
            current_time = time.time()
            last_logout = self.last_logout_time.get(u_name, 0)
            if current_time - last_logout < self.debounce_seconds:
                logger.debug(f"Logout duplicado ignorado: {u_name} (hace {current_time - last_logout:.1f}s)")
                # Eliminar de memoria pero no registrar
                del self.active_sessions[s_id]
                return
            
            self.last_logout_time[u_name] = current_time
            
            logger.info(f"🔴 LOGOUT: Usuario: {u_name} (UID: {user_info['uid']}) - Sesión: {s_id} [Tipo: {user_info.get('type', 'N/A')}]")
            
            # Preparar datos de sesión
            session_data = {
                'username': u_name,
                'terminal': s_id,
                'session_type': 'logout',
                'host': 'local'
            }
            
            # Llamar callback síncrono si existe
            if self.on_logout_callback:
                try:
                    self.on_logout_callback(session_data)
                except Exception as e:
                    logger.error(f"Error en callback de logout: {e}")
            
            # Registrar en BD vía HTTP (sync)
            threading.Thread(target=self.register_logout_http, args=(session_data,), daemon=True).start()
            
            # Eliminar de memoria
            del self.active_sessions[s_id]
        else:
            # Sesión no estaba en nuestro diccionario (probablemente sistema)
            logger.info(f"LOGOUT de sesión no monitoreada: {s_id}")
            logger.info(f"Sesiones conocidas: {list(self.active_sessions.keys())}")
    
    def register_login_http(self, session_data):
        """Registrar login en el servidor vía HTTP POST"""
        try:
            import requests
        except ImportError:
            logger.debug("requests no disponible, no se puede registrar login en BD")
            return
        
        try:
            url = f"{self.http_url}/api/login/register/"
            headers = {'Content-Type': 'application/json'}
            
            if self.token:
                headers['Authorization'] = f'Token {self.token}'
            
            response = requests.post(
                url,
                json={
                    'agent_id': self.agent_id,
                    'username': session_data['username'],
                    'login_time': datetime.now().isoformat(),
                    'terminal': session_data['terminal'],
                    'ip_address': session_data.get('host') if session_data.get('host') != 'local' else None,
                    'session_type': session_data['session_type'],
                },
                headers=headers,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                logger.debug(f"✅ Login registrado en BD: {session_data['username']}")
            else:
                logger.warning(f"⚠️  Error registrando login: HTTP {response.status_code}")
        
        except Exception as e:
            logger.error(f"Error registrando login vía HTTP: {e}")
    
    def register_logout_http(self, session_data):
        """Registrar logout en el servidor vía HTTP POST"""
        try:
            import requests
        except ImportError:
            logger.debug("requests no disponible, no se puede registrar logout en BD")
            return
        
        logger.info(f"📤 Enviando logout para {session_data['username']}...")
        
        try:
            url = f"{self.http_url}/api/login/logout/"
            headers = {'Content-Type': 'application/json'}
            
            if self.token:
                headers['Authorization'] = f'Token {self.token}'
            
            response = requests.post(
                url,
                json={
                    'agent_id': self.agent_id,
                    'username': session_data['username'],
                    'logout_time': datetime.now().isoformat(),
                },
                headers=headers,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                logger.debug(f"✅ Logout registrado en BD: {session_data['username']}")
            else:
                logger.warning(f"⚠️  Error registrando logout: HTTP {response.status_code}")
        
        except Exception as e:
            logger.error(f"Error registrando logout vía HTTP: {e}")
    
    def poll_sessions_fallback(self):
        """
        Polling periódico para detectar sesiones cerradas que D-Bus pudo haber perdido.
        Se ejecuta en el mainloop de GLib.
        """
        try:
            # Obtener lista actual de sesiones
            current_sessions = set()
            output = subprocess.check_output(
                ['loginctl', 'list-sessions', '--no-legend'],
                stderr=subprocess.DEVNULL,
                timeout=5
            ).decode('utf-8')
            
            for line in output.splitlines():
                parts = line.split()
                if parts:
                    current_sessions.add(str(parts[0]))
            
            # Verificar si alguna sesión en memoria ya no existe
            # Hacemos una copia de las keys para poder modificar el diccionario
            for session_id in list(self.active_sessions.keys()):
                if session_id not in current_sessions:
                    logger.warning(f"⚠️  Sesión {session_id} desapareció sin señal D-Bus. Forzando logout.")
                    # Llamamos manualmente al handler de logout
                    self.handle_session_removed(session_id, None)
                    continue
                
                # Si sigue en la lista, verificar su estado explícito
                _, _, _, _, s_state = self.get_session_details_via_cli(session_id)
                # Solo forzar logout si el estado es 'closing' o desconocido (no 'opening', 'active', 'online')
                if s_state in ['closing']:
                     logger.warning(f"⚠️  Sesión {session_id} cambió a estado '{s_state}'. Forzando logout.")
                     self.handle_session_removed(session_id, None)
                    
        except Exception as e:
            logger.error(f"Error en polling de sesiones: {e}")
            
        return True  # Retornar True para que GLib siga ejecutando el timer

    def monitor_loop_dbus(self):
        """
        Loop principal de monitoreo usando D-Bus (ejecuta en thread separado).
        Este método se ejecuta de forma síncrona en un thread para manejar el GLib.MainLoop.
        """
        logger.info("🔍 Iniciando monitoreo D-Bus de sesiones de usuario...")
        
        try:
            # Configurar D-Bus mainloop
            self.dbus_mainloop.DBusGMainLoop(set_as_default=True)
            bus = self.dbus.SystemBus()
            
            LOGIND_IFACE_MGR = 'org.freedesktop.login1.Manager'
            LOGIND_PATH = '/org/freedesktop/login1'
            
            # Registrar handlers para señales D-Bus
            bus.add_signal_receiver(
                self.handle_session_new,
                dbus_interface=LOGIND_IFACE_MGR,
                signal_name='SessionNew',
                path=LOGIND_PATH
            )
            
            bus.add_signal_receiver(
                self.handle_session_removed,
                dbus_interface=LOGIND_IFACE_MGR,
                signal_name='SessionRemoved',
                path=LOGIND_PATH
            )
            
            # Sincronizar sesiones existentes
            self.sync_initial_sessions()
            
            # Configurar polling de respaldo (cada 5 segundos)
            logger.info("Configurando polling de respaldo (5s)...")
            self.GLib.timeout_add_seconds(5, self.poll_sessions_fallback)
            
            logger.info(f"Monitorizando logins/logouts (UID >= {self.min_uid_monitor})...")
            
            # Iniciar GLib mainloop (bloquea hasta que se detenga)
            self.glib_loop = self.GLib.MainLoop()
            self.glib_loop.run()
            
        except Exception as e:
            logger.error(f"Error en monitor D-Bus: {e}")
        finally:
            logger.info("Monitor D-Bus detenido")
    
    def start(self):
        """Iniciar monitoreo (método síncrono)"""
        if not self.available:
            logger.info("ℹ️  Monitoreo de logins no disponible en este sistema")
            return False
        
        if self.running:
            logger.warning("⚠️  Monitor de logins ya está corriendo")
            return False
        
        self.running = True
        self.glib_loop = None
        
        # Ejecutar D-Bus mainloop en thread separado
        self.monitor_thread = threading.Thread(
            target=self.monitor_loop_dbus,
            daemon=True,
            name="LoginMonitor-DBus"
        )
        self.monitor_thread.start()
        
        logger.info("✅ Monitor de logins iniciado (D-Bus)")
        return True
    
    def stop(self):
        """Detener monitoreo (método síncrono)"""
        if not self.running:
            return
        
        self.running = False
        
        # Detener GLib mainloop si existe
        if hasattr(self, 'glib_loop') and self.glib_loop:
            try:
                self.glib_loop.quit()
            except Exception as e:
                logger.debug(f"Error deteniendo GLib loop: {e}")
        
        # Esperar a que termine el thread (con timeout)
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=2.0)
        
        logger.info("🛑 Monitor de logins detenido")

#!/usr/bin/env python3
"""Acciones locales del agente ejecutadas desde el backend.

Este modulo encapsula acciones de alto nivel para evitar enviar scripts
bash desde el frontend.
"""

from __future__ import annotations

import os
import pwd
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class ActionResult:
    success: bool
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0


@dataclass
class SessionContext:
    user: str
    uid: int
    display: str
    runtime_dir: str
    home: str
    xauthority: Optional[str]

    @property
    def env(self) -> Dict[str, str]:
        env = {
            "DISPLAY": self.display,
            "XDG_RUNTIME_DIR": self.runtime_dir,
            "DBUS_SESSION_BUS_ADDRESS": f"unix:path={self.runtime_dir}/bus",
            "PULSE_SERVER": f"unix:{self.runtime_dir}/pulse/native",
            "HOME": self.home,
            "USER": self.user,
            "LOGNAME": self.user,
        }
        if self.xauthority:
            env["XAUTHORITY"] = self.xauthority
        return env


class AgentActions:
    """Implementa acciones predefinidas del agente."""

    LOCK_FILE = Path("/tmp/educontrol_input_lock_ids")
    PUPPET_BASE = Path("/etc/puppetlabs/code/environments/production")

    # ── path validation ───────────────────────────────────────────────────────

    def _puppet_resolve(self, rel_path: str) -> Path:
        """Resolve *rel_path* relative to PUPPET_BASE and validate no traversal."""
        base = self.PUPPET_BASE.resolve()
        # Strip leading slashes to treat it as relative
        rel_path = rel_path.lstrip("/")
        if rel_path:
            target = (base / rel_path).resolve()
        else:
            target = base
        if not str(target).startswith(str(base)):
            raise ValueError(f"Ruta fuera del directorio permitido: {rel_path!r}")
        return target

    # ── puppet actions ────────────────────────────────────────────────────────

    def _puppet_list_dir(self, rel_path: str) -> ActionResult:
        """Return a JSON tree of the puppet production directory."""
        import json as _json

        try:
            root = self._puppet_resolve(rel_path)
            if not root.exists():
                return ActionResult(False, stderr=f"Directorio no encontrado: {rel_path}", exit_code=1)

            def _walk(p: Path) -> dict:
                if p.is_file():
                    return {"name": p.name, "type": "file", "path": str(p.relative_to(self.PUPPET_BASE))}
                children = []
                try:
                    for child in sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
                        children.append(_walk(child))
                except PermissionError:
                    pass
                return {
                    "name": p.name,
                    "type": "directory",
                    "path": str(p.relative_to(self.PUPPET_BASE)),
                    "children": children,
                }

            if root == self.PUPPET_BASE:
                # Return list of top-level entries
                entries = []
                try:
                    for child in sorted(root.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
                        entries.append(_walk(child))
                except PermissionError as exc:
                    return ActionResult(False, stderr=str(exc), exit_code=1)
                return ActionResult(True, stdout=_json.dumps(entries), exit_code=0)
            else:
                return ActionResult(True, stdout=_json.dumps([_walk(root)]), exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_read_file(self, rel_path: str) -> ActionResult:
        """Return the raw text content of a puppet file."""
        try:
            target = self._puppet_resolve(rel_path)
            if not target.exists():
                return ActionResult(False, stderr=f"Archivo no encontrado: {rel_path}", exit_code=1)
            if not target.is_file():
                return ActionResult(False, stderr=f"La ruta no es un archivo: {rel_path}", exit_code=1)
            content = target.read_text(encoding="utf-8", errors="replace")
            return ActionResult(True, stdout=content, exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_save_file(self, rel_path: str, content: str) -> ActionResult:
        """Write *content* to a puppet file, creating parent directories as needed."""
        try:
            target = self._puppet_resolve(rel_path)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            return ActionResult(True, stdout=f"Archivo guardado: {rel_path}", exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_validate(self, rel_path: str) -> ActionResult:
        """Run syntax validation on a .pp or .yaml file."""
        try:
            target = self._puppet_resolve(rel_path)
            if not target.exists():
                return ActionResult(False, stderr=f"Archivo no encontrado: {rel_path}", exit_code=1)

            ext = target.suffix.lower()

            if ext == ".pp":
                # Buscar el binario de puppet en las rutas habituales
                import shutil as _shutil
                puppet_bin = (
                    _shutil.which("puppet")
                    or (_shutil.which("/opt/puppetlabs/bin/puppet") and "/opt/puppetlabs/bin/puppet")
                    or (Path("/opt/puppetlabs/bin/puppet").exists() and str(Path("/opt/puppetlabs/bin/puppet")))
                    or None
                )
                if not puppet_bin:
                    return ActionResult(
                        False,
                        stderr="No se encontró el ejecutable de Puppet. Asegúrate de que está instalado en /opt/puppetlabs/bin/puppet o en el PATH.",
                        exit_code=1,
                    )
                proc = subprocess.run(
                    [puppet_bin, "parser", "validate", str(target)],
                    capture_output=True, text=True, timeout=30, check=False,
                )
                combined = (proc.stdout or "").strip() + ("\n" + (proc.stderr or "").strip() if proc.stderr else "")
                if proc.returncode == 0 and not combined.strip():
                    combined = "Sintaxis válida"
                return ActionResult(
                    success=proc.returncode == 0,
                    stdout=combined.strip(),
                    stderr="",
                    exit_code=proc.returncode,
                )

            elif ext in (".yaml", ".yml"):
                ruby_script = f"require 'yaml'; YAML.load_file('{target}'); puts 'Sintaxis YAML válida'"
                proc = subprocess.run(
                    ["ruby", "-e", ruby_script],
                    capture_output=True, text=True, timeout=30, check=False,
                )
                combined = (proc.stdout or "").strip() + ("\n" + (proc.stderr or "").strip() if proc.stderr else "")
                return ActionResult(
                    success=proc.returncode == 0,
                    stdout=combined.strip(),
                    stderr="",
                    exit_code=proc.returncode,
                )

            else:
                return ActionResult(
                    False,
                    stderr=f"Tipo de archivo no soportado para validación: {ext}",
                    exit_code=1,
                )
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except subprocess.TimeoutExpired:
            return ActionResult(False, stderr="Timeout durante la validación", exit_code=1)
        except FileNotFoundError as exc:
            return ActionResult(False, stderr=f"Herramienta no encontrada: {exc}", exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_validate_all(self) -> ActionResult:
        """Run puppet parser validate on the entire production environment."""
        try:
            import shutil as _shutil
            puppet_bin = (
                _shutil.which("puppet")
                or (_shutil.which("/opt/puppetlabs/bin/puppet") and "/opt/puppetlabs/bin/puppet")
                or (Path("/opt/puppetlabs/bin/puppet").exists() and str(Path("/opt/puppetlabs/bin/puppet")))
                or None
            )
            if not puppet_bin:
                return ActionResult(
                    False,
                    stderr="No se encontró el ejecutable de Puppet. Asegúrate de que está instalado en /opt/puppetlabs/bin/puppet o en el PATH.",
                    exit_code=1,
                )
            proc = subprocess.run(
                [puppet_bin, "parser", "validate", str(self.PUPPET_BASE) + "/"],
                capture_output=True, text=True, timeout=60, check=False,
            )
            combined = (proc.stdout or "").strip() + ("\n" + (proc.stderr or "").strip() if proc.stderr else "")
            if proc.returncode == 0 and not combined.strip():
                combined = "Todos los manifests son válidos"
            return ActionResult(
                success=proc.returncode == 0,
                stdout=combined.strip(),
                stderr="",
                exit_code=proc.returncode,
            )
        except subprocess.TimeoutExpired:
            return ActionResult(False, stderr="Timeout durante la validación global", exit_code=1)
        except FileNotFoundError as exc:
            return ActionResult(False, stderr=f"Herramienta no encontrada: {exc}", exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_create_dir(self, rel_path: str) -> ActionResult:
        """Create a directory inside the puppet production environment."""
        try:
            target = self._puppet_resolve(rel_path)
            target.mkdir(parents=True, exist_ok=True)
            return ActionResult(True, stdout=f"Directorio creado: {rel_path}", exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_delete(self, rel_path: str) -> ActionResult:
        """Delete a file or directory (recursive) inside the puppet environment."""
        import shutil as _shutil

        try:
            target = self._puppet_resolve(rel_path)
            if not target.exists():
                return ActionResult(False, stderr=f"Ruta no encontrada: {rel_path}", exit_code=1)
            if target == self.PUPPET_BASE:
                return ActionResult(False, stderr="No se puede eliminar el directorio raíz", exit_code=1)
            if target.is_dir():
                _shutil.rmtree(target)
            else:
                target.unlink()
            return ActionResult(True, stdout=f"Eliminado: {rel_path}", exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _puppet_rename(self, rel_path: str, new_rel_path: str) -> ActionResult:
        """Rename/move a file or directory inside the puppet environment."""
        try:
            src = self._puppet_resolve(rel_path)
            dst = self._puppet_resolve(new_rel_path)
            if not src.exists():
                return ActionResult(False, stderr=f"Origen no encontrado: {rel_path}", exit_code=1)
            if dst.exists():
                return ActionResult(False, stderr=f"El destino ya existe: {new_rel_path}", exit_code=1)
            dst.parent.mkdir(parents=True, exist_ok=True)
            src.rename(dst)
            return ActionResult(True, stdout=f"Renombrado: {rel_path} → {new_rel_path}", exit_code=0)
        except ValueError as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def execute(self, action: str, params: Optional[Dict] = None) -> ActionResult:
        params = params or {}

        try:
            if action == "mute":
                return self._set_mute(bool(params.get("mute", True)))
            if action == "input_lock":
                return self._set_input_lock(bool(params.get("lock", True)))
            if action == "launch_url":
                url = str(params.get("url", "")).strip()
                if not url:
                    return ActionResult(False, stderr="URL vacia", exit_code=1)
                return self._launch_url(url)
            # Puppet file manager actions
            if action == "puppet_list_dir":
                return self._puppet_list_dir(str(params.get("path", "")))
            if action == "puppet_read_file":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                return self._puppet_read_file(path)
            if action == "puppet_save_file":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                content = params.get("content", "")
                return self._puppet_save_file(path, str(content))
            if action == "puppet_validate":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                return self._puppet_validate(path)
            if action == "puppet_validate_all":
                return self._puppet_validate_all()
            if action == "puppet_create_dir":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                return self._puppet_create_dir(path)
            if action == "puppet_delete":
                path = str(params.get("path", "")).strip()
                if not path:
                    return ActionResult(False, stderr="Parámetro 'path' requerido", exit_code=1)
                return self._puppet_delete(path)
            if action == "puppet_rename":
                path = str(params.get("path", "")).strip()
                new_path = str(params.get("new_path", "")).strip()
                if not path or not new_path:
                    return ActionResult(False, stderr="Parámetros 'path' y 'new_path' requeridos", exit_code=1)
                return self._puppet_rename(path, new_path)
            return ActionResult(False, stderr=f"Accion no soportada: {action}", exit_code=1)
        except Exception as exc:
            return ActionResult(False, stderr=str(exc), exit_code=1)

    def _run(
        self,
        cmd: List[str],
        *,
        as_user: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
        background: bool = False,
    ) -> ActionResult:
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)

        def build_runuser_cmd() -> List[str]:
            env_parts = [f"{k}={v}" for k, v in (env or {}).items()]
            return ["runuser", "-u", as_user, "--", "env", *env_parts, *cmd]

        # Caso 1: Background con runuser (lanzar proceso como otro usuario en background)
        if background and as_user and os.geteuid() == 0 and shutil.which("runuser"):
            try:
                real_cmd = build_runuser_cmd()
                subprocess.Popen(
                    real_cmd,
                    env=merged_env,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
                return ActionResult(True, stdout="Proceso lanzado en background", exit_code=0)
            except OSError as exc:
                return ActionResult(False, stderr=str(exc), exit_code=1)

        # Caso 2: Background sin runuser (lanzar proceso simple en background)
        if background:
            try:
                subprocess.Popen(
                    cmd,
                    env=merged_env,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
                return ActionResult(True, stdout="Proceso lanzado", exit_code=0)
            except OSError as exc:
                return ActionResult(False, stderr=str(exc), exit_code=1)

        # Caso 3: Foreground con runuser
        if as_user and os.geteuid() == 0 and shutil.which("runuser"):
            real_cmd = build_runuser_cmd()
            proc = subprocess.run(real_cmd, env=merged_env, capture_output=True, text=True, check=False)
        else:
            # Caso 4: Foreground simple
            proc = subprocess.run(cmd, env=merged_env, capture_output=True, text=True, check=False)

        return ActionResult(
            success=proc.returncode == 0,
            stdout=(proc.stdout or "").strip(),
            stderr=(proc.stderr or "").strip(),
            exit_code=proc.returncode,
        )

    def _find_graphical_session(self) -> Optional[SessionContext]:
        if not shutil.which("loginctl"):
            return None

        list_proc = subprocess.run(
            ["loginctl", "list-sessions", "--no-legend"],
            capture_output=True,
            text=True,
            check=False,
        )
        if list_proc.returncode != 0:
            return None

        candidates: List[SessionContext] = []

        for line in list_proc.stdout.splitlines():
            parts = line.split()
            if not parts:
                continue
            sid = parts[0]

            def prop(session_id: str, name: str) -> str:
                p = subprocess.run(
                    ["loginctl", "show-session", session_id, "-p", name, "--value"],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                return (p.stdout or "").strip()

            user_id = prop(sid, "User")
            user_name = prop(sid, "Name")
            session_type = prop(sid, "Type")
            session_class = prop(sid, "Class")
            session_state = prop(sid, "State")
            session_remote = prop(sid, "Remote")
            display = prop(sid, "Display")
            tty = prop(sid, "TTY")

            if not user_id.isdigit() or int(user_id) < 1000:
                continue
            # Nunca usar sesiones greeter (gdm/sddm/lightdm), no son el usuario autenticado.
            if session_class != "user":
                continue
            if session_type not in {"x11", "wayland"}:
                continue
            if session_state not in {"active", "online"}:
                continue
            if session_remote == "yes":
                continue
            if user_name in {"gdm", "sddm", "lightdm"}:
                continue

            if not display:
                if tty in {"tty7", "tty1"}:
                    display = ":0"
                elif tty in {"tty8", "tty2"}:
                    display = ":1"
                else:
                    display = ":0"

            uid = int(user_id)
            runtime_dir = f"/run/user/{uid}"
            home = pwd.getpwnam(user_name).pw_dir

            xauth_candidates = [
                f"{runtime_dir}/gdm/Xauthority",
                f"{home}/.Xauthority",
            ]
            xauth = next((path for path in xauth_candidates if os.path.exists(path)), None)

            candidates.append(SessionContext(
                user=user_name,
                uid=uid,
                display=display,
                runtime_dir=runtime_dir,
                home=home,
                xauthority=xauth,
            ))

        if candidates:
            # Priorizamos la primera sesión de usuario válida que devuelve logind.
            return candidates[0]

        return None

    def _set_mute(self, mute: bool) -> ActionResult:
        mute_value = "1" if mute else "0"
        amixer_action = "mute" if mute else "unmute"

        applied = False
        messages: List[str] = []

        session = self._find_graphical_session()
        if session:
            for cmd in (
                ["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", mute_value],
                ["pactl", "set-sink-mute", "@DEFAULT_SINK@", mute_value],
                ["amixer", "-D", "pulse", "sset", "Master", amixer_action],
            ):
                if not shutil.which(cmd[0]):
                    continue
                res = self._run(cmd, as_user=session.user, env=session.env)
                if res.success:
                    applied = True
                    messages.append(f"Aplicado con {cmd[0]} en sesion de usuario")
                    break

        if not applied and shutil.which("amixer"):
            controls = ["Master", "PCM", "Speaker", "Headphone", "Front"]
            for ctl in controls:
                res = self._run(["amixer", "sset", ctl, amixer_action])
                if res.success:
                    applied = True
            for card in range(10):
                info = self._run(["amixer", "-c", str(card), "info"])
                if not info.success:
                    continue
                for ctl in controls:
                    res = self._run(["amixer", "-c", str(card), "sset", ctl, amixer_action])
                    if res.success:
                        applied = True
            if applied:
                messages.append("Aplicado via ALSA")

        if not applied:
            return ActionResult(False, stderr="No se pudo aplicar mute/unmute", exit_code=1)

        return ActionResult(True, stdout="; ".join(messages) or "Mute aplicado", exit_code=0)

    def _list_xinput_ids(self, session: SessionContext) -> List[str]:
        res = self._run(["xinput", "--list", "--short"], as_user=session.user, env=session.env)
        if not res.success:
            return []
        ids: List[str] = []
        for line in res.stdout.splitlines():
            low = line.lower()
            if "slave" not in low:
                continue
            if "pointer" not in low and "keyboard" not in low:
                continue
            if "xtest" in low or "virtual core" in low:
                continue
            match = re.search(r"\bid=(\d+)\b", line)
            if match:
                ids.append(match.group(1))
        return ids

    def _set_input_lock(self, lock: bool) -> ActionResult:
        if not shutil.which("xinput"):
            return ActionResult(False, stderr="xinput no disponible", exit_code=1)

        session = self._find_graphical_session()
        if not session:
            return ActionResult(False, stderr="No se detecto sesion grafica activa", exit_code=1)

        if lock:
            ids = self._list_xinput_ids(session)
            if not ids:
                return ActionResult(False, stderr="No se encontraron dispositivos para bloquear", exit_code=1)

            locked: List[str] = []
            for dev_id in ids:
                res = self._run(["xinput", "--disable", dev_id], as_user=session.user, env=session.env)
                if res.success:
                    locked.append(dev_id)

            if not locked:
                return ActionResult(False, stderr="No se pudo bloquear ningun dispositivo", exit_code=1)

            self.LOCK_FILE.write_text("\n".join(locked), encoding="utf-8")
            return ActionResult(True, stdout=f"Bloqueados {len(locked)} dispositivos", exit_code=0)

        if not self.LOCK_FILE.exists():
            return ActionResult(False, stderr="No hay bloqueo registrado", exit_code=1)

        ids = [line.strip() for line in self.LOCK_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]
        for dev_id in ids:
            self._run(["xinput", "--enable", dev_id], as_user=session.user, env=session.env)
        try:
            self.LOCK_FILE.unlink(missing_ok=True)
        except Exception:
            pass

        return ActionResult(True, stdout="Teclado y raton desbloqueados", exit_code=0)

    def _launch_url(self, url: str) -> ActionResult:
        session = self._find_graphical_session()
        if not session:
            return ActionResult(False, stderr="No se detecto sesion grafica activa", exit_code=1)

        browser = shutil.which("google-chrome") or shutil.which("chromium-browser") or shutil.which("chromium")
        if not browser:
            return ActionResult(False, stderr="No se encontro Chrome/Chromium instalado", exit_code=1)

        # Usar el entorno completo de sesión para DBus/Pulse/XDG además de DISPLAY.
        launch_env = dict(session.env)
        # Evitar enviar XAUTHORITY vacío explícito.
        if not session.xauthority:
            launch_env.pop("XAUTHORITY", None)

        attempts: List[List[str]] = [[browser, "--new-window", url], [browser, url]]
        if shutil.which("xdg-open"):
            attempts.append(["xdg-open", url])
        if shutil.which("gio"):
            attempts.append(["gio", "open", url])

        last_error = ""
        # Primer pase: entorno completo
        for cmd in attempts:
            res = self._run(cmd, as_user=session.user, env=launch_env, background=True)
            if res.success:
                return ActionResult(
                    True,
                    stdout=(
                        f"URL lanzada con {' '.join(cmd[:2])} "
                        f"(user={session.user}, display={session.display})"
                    ),
                    exit_code=0,
                )
            last_error = res.stderr or f"exit_code={res.exit_code}"

        # Segundo pase: sin XAUTHORITY explícito
        if "XAUTHORITY" in launch_env:
            launch_env.pop("XAUTHORITY", None)
            for cmd in attempts:
                res = self._run(cmd, as_user=session.user, env=launch_env, background=True)
                if res.success:
                    return ActionResult(
                        True,
                        stdout=(
                            f"URL lanzada sin XAUTHORITY con {' '.join(cmd[:2])} "
                            f"(user={session.user}, display={session.display})"
                        ),
                        exit_code=0,
                    )
                last_error = res.stderr or f"exit_code={res.exit_code}"

        return ActionResult(
            False,
            stderr=(
                "No se pudo abrir navegador "
                f"(user={session.user}, display={session.display}, browser={browser}): {last_error}"
            ),
            exit_code=1,
        )

"""
printing_client.py — Cliente de impresión centralizada para EduControl Agent.

Opt-in: solo actúa si la configuración local tiene `"printing": true` (o la forma
antigua `"printing": {"managed": true}`). Lo invoca el servidor mediante acciones
(`printing_apply`, `printing_revert`, `printing_report_queues`,
`printing_remove_local_queue`, `printing_sync_queues`).

- Escribe /etc/cups/client.conf con el ServerName del servidor de impresión,
  guardando antes una copia del fichero anterior.
- Instala una tabla nftables propia (`inet educontrol_print`) que impide imprimir
  directamente contra las impresoras (9100, 515 y 631 salvo al servidor, y
  cualquier tráfico a las IPs de las impresoras). No toca ninguna otra regla.
- Crea en el cupsd local las colas de las impresoras asignadas al equipo en la web
  (`ipp://servidor:631/printers/COLA`), con su predeterminada, y quita las que
  dejan de estarlo. Solo toca las colas que creó él (`managed_queues` en el estado).
- Informa al servidor de las colas del cupsd local.
- Nunca borra otras colas locales salvo orden explícita con su nombre.
"""

import ipaddress
import json
import logging
import os
import re
import socket
import subprocess
import tempfile
from typing import List, Optional, Tuple

logger = logging.getLogger('EduControlAgent')

CLIENT_CONF = '/etc/cups/client.conf'
CLIENT_CONF_BACKUP = '/etc/cups/client.conf.educontrol-bak'
NFT_FILE = '/etc/educontrol/printing.nft'
STATE_FILE = '/etc/educontrol/printing-state.json'
NFT_TABLE = 'educontrol_print'
LOCAL_CUPS_SOCKET = '/run/cups/cups.sock'
LOCAL_PPD_DIR = '/etc/cups/ppd'
BLOCKED_PORTS = (9100, 515, 631)

HOST_RE = re.compile(r'^[A-Za-z0-9.-]{1,253}$')
CUPS_PORT = 631
QUEUE_NAME_RE = re.compile(r'^[A-Za-z0-9_.@-]{1,127}$')

# Colas que crea cups-browsed por su cuenta al descubrir impresoras en la red.
TEMPORARY_URI_PREFIXES = ('implicitclass://', 'dnssd://')

Result = Tuple[bool, str, str]  # (éxito, stdout, stderr)


class PrintingClient:
    """Aplica en el equipo la configuración de impresión centralizada que envía el servidor."""

    def __init__(self, config):
        self.config = config

    # ── helpers privados ──────────────────────────────────────────────────────

    @property
    def managed(self) -> bool:
        return bool(getattr(self.config, 'printing', {}).get('managed', False))

    def _not_managed(self) -> Result:
        message = ('Gestión de impresión desactivada en este equipo '
                   '(falta "printing": true en agent_config.json)')
        logger.warning(f"⚠️ Impresión: orden del servidor ignorada. {message}")
        return False, '', message

    @staticmethod
    def _run(cmd: List[str], timeout: int = 30) -> subprocess.CompletedProcess:
        # Mensajes en inglés: la salida de lpstat/lpadmin se interpreta y no debe depender
        # del idioma del equipo ("No se han añadido destinos" frente a "No destinations added").
        env = dict(os.environ, LC_ALL='C', LANG='C', LANGUAGE='')
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False, env=env)

    @staticmethod
    def _atomic_write(path: str, content: str, mode: int = 0o644):
        directory = os.path.dirname(path)
        os.makedirs(directory, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix='.educontrol-', dir=directory)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as fh:
                fh.write(content)
            os.chmod(tmp, mode)
            os.replace(tmp, path)
        except Exception:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise

    def _load_state(self) -> dict:
        try:
            with open(STATE_FILE, encoding='utf-8') as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return {}

    def _save_state(self, state: dict):
        self._atomic_write(STATE_FILE, json.dumps(state, indent=2), mode=0o600)

    @staticmethod
    def _resolve(host: str) -> Tuple[List[str], List[str]]:
        """IPs v4 y v6 del servidor de impresión."""
        try:
            ip = ipaddress.ip_address(host)
            return ([str(ip)], []) if ip.version == 4 else ([], [str(ip)])
        except ValueError:
            pass
        v4, v6 = set(), set()
        for family, _, _, _, sockaddr in socket.getaddrinfo(host, None):
            if family == socket.AF_INET:
                v4.add(sockaddr[0])
            elif family == socket.AF_INET6:
                v6.add(sockaddr[0])
        return sorted(v4), sorted(v6)

    @staticmethod
    def _split_ips(values) -> Tuple[List[str], List[str]]:
        v4, v6 = set(), set()
        for value in values or []:
            try:
                ip = ipaddress.ip_address(str(value).strip())
            except ValueError:
                continue
            (v4 if ip.version == 4 else v6).add(str(ip))
        return sorted(v4), sorted(v6)

    @staticmethod
    def build_nft_ruleset(server_v4: List[str], server_v6: List[str],
                          printer_v4: List[str], printer_v6: List[str]) -> str:
        """
        Tabla propia que se reemplaza entera. Las dos primeras líneas hacen la
        carga idempotente: crean la tabla si no existe y la vacían.
        """
        ports = ', '.join(str(p) for p in BLOCKED_PORTS)
        rules = ['        oifname "lo" accept']
        if server_v4:
            rules.append(f'        ip daddr {{ {", ".join(server_v4)} }} tcp dport {{ {ports} }} accept')
        if server_v6:
            rules.append(f'        ip6 daddr {{ {", ".join(server_v6)} }} tcp dport {{ {ports} }} accept')
        if printer_v4:
            rules.append(f'        ip daddr {{ {", ".join(printer_v4)} }} counter reject')
        if printer_v6:
            rules.append(f'        ip6 daddr {{ {", ".join(printer_v6)} }} counter reject')
        rules.append(f'        tcp dport {{ {ports} }} counter reject')
        return (
            '# Generado por EduControl: impresión solo a través del servidor central.\n'
            f'table inet {NFT_TABLE} {{}}\n'
            f'delete table inet {NFT_TABLE}\n'
            f'table inet {NFT_TABLE} {{\n'
            '    chain output {\n'
            '        type filter hook output priority 0; policy accept;\n'
            + '\n'.join(rules) + '\n'
            '    }\n'
            '}\n'
        )

    def _load_nft(self, path: str) -> Optional[str]:
        """Valida (`nft -c`) y carga un fichero. Devuelve el error o None."""
        try:
            check = self._run(['nft', '-c', '-f', path])
        except FileNotFoundError:
            return 'nft no está instalado'
        if check.returncode != 0:
            return f'Regla nftables no válida: {check.stderr.strip()}'
        load = self._run(['nft', '-f', path])
        if load.returncode != 0:
            return f'No se pudo cargar la regla nftables: {load.stderr.strip()}'
        return None

    def _local_cups_args(self) -> List[str]:
        """Apunta lpstat/lpadmin al cupsd local: con client.conf irían al servidor central."""
        if os.path.exists(LOCAL_CUPS_SOCKET):
            return ['-h', LOCAL_CUPS_SOCKET]
        return ['-h', 'localhost:631']

    # ── acciones ──────────────────────────────────────────────────────────────

    def apply(self, server: str, printer_ips=None) -> Result:
        if not self.managed:
            return self._not_managed()
        server = (server or '').strip()
        if not HOST_RE.match(server):
            return False, '', f'Servidor de impresión no válido: {server!r}'

        try:
            server_v4, server_v6 = self._resolve(server)
        except OSError as e:
            return False, '', f'No se pudo resolver {server}: {e}'
        if not server_v4 and not server_v6:
            # Sin IP del servidor la regla bloquearía toda la impresión.
            return False, '', f'{server} no resuelve a ninguna IP; no se aplica nada'

        printer_v4, printer_v6 = self._split_ips(printer_ips)
        state = self._load_state()
        messages = []

        # 1. Regla nftables (primero: si falla, client.conf queda como estaba).
        ruleset = self.build_nft_ruleset(server_v4, server_v6, printer_v4, printer_v6)
        previous_nft = None
        if os.path.exists(NFT_FILE):
            with open(NFT_FILE, encoding='utf-8') as fh:
                previous_nft = fh.read()
        self._atomic_write(NFT_FILE, ruleset, mode=0o600)
        error = self._load_nft(NFT_FILE)
        if error:
            if previous_nft is not None:
                self._atomic_write(NFT_FILE, previous_nft, mode=0o600)
            else:
                os.unlink(NFT_FILE)
            return False, '', error
        messages.append(f'Regla nftables aplicada (servidor {", ".join(server_v4 + server_v6)}, '
                        f'{len(printer_v4) + len(printer_v6)} impresoras bloqueadas)')

        # 2. client.conf con copia del original la primera vez. Si el equipo tiene colas
        #    asignadas no se escribe: con él vería todas las colas del servidor.
        if state.get('managed_queues'):
            messages.append(f'{CLIENT_CONF} no se escribe: el equipo usa sus colas asignadas')
            state.update({'applied': True, 'server': server, 'printer_ips': printer_v4 + printer_v6})
            self._save_state(state)
            logger.info(f"🖨️ Impresión centralizada aplicada: {'; '.join(messages)}")
            return True, '\n'.join(messages), ''
        if 'client_conf_existed' not in state:
            state['client_conf_existed'] = os.path.exists(CLIENT_CONF)
            if state['client_conf_existed'] and not os.path.exists(CLIENT_CONF_BACKUP):
                with open(CLIENT_CONF, encoding='utf-8') as fh:
                    self._atomic_write(CLIENT_CONF_BACKUP, fh.read())
                messages.append(f'Copia de seguridad en {CLIENT_CONF_BACKUP}')
        self._atomic_write(
            CLIENT_CONF,
            '# Generado por EduControl: todas las colas están en el servidor de impresión.\n'
            f'ServerName {server}\n',
        )
        messages.append(f'{CLIENT_CONF}: ServerName {server}')

        state.update({'applied': True, 'server': server, 'printer_ips': printer_v4 + printer_v6})
        self._save_state(state)

        logger.info(f"🖨️ Impresión centralizada aplicada: {'; '.join(messages)}")
        return True, '\n'.join(messages), ''

    def revert(self) -> Result:
        if not self.managed:
            return self._not_managed()
        state = self._load_state()
        messages = []

        try:
            result = self._run(['nft', 'delete', 'table', 'inet', NFT_TABLE])
            if result.returncode == 0:
                messages.append('Regla nftables eliminada')
        except FileNotFoundError:
            pass
        if os.path.exists(NFT_FILE):
            os.unlink(NFT_FILE)

        if os.path.exists(CLIENT_CONF_BACKUP):
            os.replace(CLIENT_CONF_BACKUP, CLIENT_CONF)
            messages.append(f'{CLIENT_CONF} restaurado desde la copia')
        elif state.get('client_conf_existed') is False and os.path.exists(CLIENT_CONF):
            os.unlink(CLIENT_CONF)
            messages.append(f'{CLIENT_CONF} eliminado (no existía antes)')

        if os.path.exists(STATE_FILE):
            os.unlink(STATE_FILE)
        logger.info(f"🖨️ Impresión centralizada revertida: {'; '.join(messages) or 'nada que revertir'}")
        return True, '\n'.join(messages) or 'Nada que revertir', ''

    def reapply_on_startup(self):
        """Las reglas nftables no sobreviven a un reinicio: se recargan al arrancar el agente."""
        if not self.managed or not self._load_state().get('applied') or not os.path.exists(NFT_FILE):
            return
        error = self._load_nft(NFT_FILE)
        if error:
            logger.error(f"❌ Impresión: {error}")
        else:
            logger.info("🖨️ Regla nftables de impresión recargada")

    def list_local_queues(self) -> Tuple[List[dict], Optional[str]]:
        """Colas del cupsd local (`lpstat -v`). Devuelve (colas, error)."""
        try:
            result = self._run(['lpstat'] + self._local_cups_args() + ['-v'])
        except FileNotFoundError:
            return [], 'lpstat no está instalado'
        output = (result.stdout or '') + (result.stderr or '')
        if result.returncode != 0:
            lowered = output.lower()
            if any(text in lowered for text in ('no destinations', 'no hay destinos', 'no se han añadido destinos')):
                return [], None
            return [], output.strip() or f'lpstat terminó con código {result.returncode}'

        queues = []
        for line in result.stdout.splitlines():
            # "device for COLA: uri" (o traducido: "dispositivo para COLA: uri")
            match = re.match(r'^\S+\s+\S+\s+([^:]+):\s*(\S+)', line.strip())
            if not match:
                continue
            name, uri = match.group(1).strip(), match.group(2).strip()
            queues.append({'name': name, 'uri': uri, 'temporary': uri.startswith(TEMPORARY_URI_PREFIXES)})
        return queues, None

    def report_queues(self) -> Result:
        if not self.managed:
            return self._not_managed()
        queues, error = self.list_local_queues()
        if error:
            return False, '', f'No se pudieron listar las colas locales: {error}'
        managed = set(self._load_state().get('managed_queues') or [])
        for q in queues:
            q['managed'] = q['name'] in managed
        try:
            import requests as _requests
            headers = {'Content-Type': 'application/json'}
            if self.config.token:
                headers['Authorization'] = f'Token {self.config.token}'
            resp = _requests.post(
                f'{self.config.http_url}/api/printing/local-queues/',
                json={'agent_id': self.config.agent_id, 'queues': queues},
                headers=headers, timeout=10, verify=self.config.verify_ssl,
            )
        except Exception as e:
            return False, '', f'No se pudo enviar el informe de colas: {e}'
        if resp.status_code >= 300:
            return False, '', f'El servidor rechazó el informe de colas (HTTP {resp.status_code})'

        persistent = [q['name'] for q in queues if not q['temporary'] and not q['managed']]
        if persistent:
            logger.warning(f"⚠️ Impresión: colas locales detectadas: {', '.join(persistent)}")
        summary = ', '.join(f"{q['name']} ({q['uri']})" for q in queues) or 'ninguna'
        return True, f'Colas locales: {summary}', ''

    def remove_local_queue(self, name: str) -> Result:
        """Solo por orden explícita del administrador y con el nombre exacto de la cola."""
        if not self.managed:
            return self._not_managed()
        name = (name or '').strip()
        if not QUEUE_NAME_RE.match(name):
            return False, '', f'Nombre de cola no válido: {name!r}'
        result = self._run(['lpadmin'] + self._local_cups_args() + ['-x', name])
        if result.returncode != 0:
            return False, '', result.stderr.strip() or f'lpadmin terminó con código {result.returncode}'
        logger.info(f"🖨️ Cola local eliminada por orden del administrador: {name}")
        return True, f'Cola local {name} eliminada', ''

    # ── colas asignadas desde la web ──────────────────────────────────────────

    def _default_queue(self) -> Optional[str]:
        """Predeterminada del cupsd local (`lpstat -d`), o None."""
        try:
            result = self._run(['lpstat'] + self._local_cups_args() + ['-d'])
        except FileNotFoundError:
            return None
        line = (result.stdout or '').strip().splitlines()
        if result.returncode != 0 or not line or ':' not in line[0]:
            return None  # "no system default destination"
        return line[0].rsplit(':', 1)[1].strip() or None

    def _add_queue(self, name: str, uri: str) -> Optional[str]:
        """
        Crea o actualiza la cola local. `everywhere` da al diálogo las opciones de la
        impresora (dúplex, papel) y envía el PDF sin convertir; si la cola del servidor no
        responde a la consulta, se crea `raw`. Devuelve el error o None.
        """
        base = ['lpadmin'] + self._local_cups_args() + ['-p', name, '-E', '-v', uri]
        error = ''
        for model in ('everywhere', 'raw'):
            result = self._run(base + ['-m', model], timeout=90)
            if result.returncode == 0:
                return None
            error = result.stderr.strip() or f'lpadmin terminó con código {result.returncode}'
        return error

    def _server_client_conf(self, server: str) -> bool:
        """¿Existe un client.conf que apunta al servidor de impresión?"""
        try:
            with open(CLIENT_CONF, encoding='utf-8') as fh:
                content = fh.read()
        except OSError:
            return False
        names = re.findall(r'^\s*ServerName\s+(\S+)', content, re.MULTILINE | re.IGNORECASE)
        return any(n.split(':')[0].lower() == server.lower() for n in names)

    def sync_queues(self, server: str, queues, default: Optional[str] = None) -> Result:
        """
        Deja en el equipo exactamente las colas asignadas en la web (`queues`: [{name, uri}]).
        Solo crea, cambia o borra colas creadas por EduControl; una cola local con el mismo
        nombre se reutiliza (pasa a ser gestionada). Una lista vacía quita las creadas.
        """
        if not self.managed:
            return self._not_managed()
        server = (server or '').strip()
        if not HOST_RE.match(server):
            return False, '', f'Servidor de impresión no válido: {server!r}'
        prefixes = tuple(f'{scheme}://{server}:{CUPS_PORT}/printers/' for scheme in ('ipp', 'ipps'))
        desired = {}
        for q in queues or []:
            name, uri = str(q.get('name', '')).strip(), str(q.get('uri', '')).strip()
            if not QUEUE_NAME_RE.match(name) or not uri.startswith(prefixes) or not uri.endswith('/' + name):
                return False, '', f'Cola no válida: {name!r} ({uri!r})'
            desired[name] = uri

        state = self._load_state()
        managed = set(state.get('managed_queues') or [])
        if not desired and not managed:
            return True, 'Sin impresoras asignadas: nada que hacer', ''

        current, error = self.list_local_queues()
        if error:
            return False, '', f'No se pudieron listar las colas locales: {error}'
        current_uris = {q['name']: q['uri'] for q in current}
        messages, errors = [], []

        # 1. client.conf del servidor fuera: con él se verían todas sus colas.
        if desired and self._server_client_conf(server):
            if not os.path.exists(CLIENT_CONF_BACKUP):
                with open(CLIENT_CONF, encoding='utf-8') as fh:
                    self._atomic_write(CLIENT_CONF_BACKUP, fh.read())
            state.setdefault('client_conf_existed', True)
            os.unlink(CLIENT_CONF)
            state['client_conf_removed'] = True
            messages.append(f'{CLIENT_CONF} retirado (copia en {CLIENT_CONF_BACKUP})')

        # 2. Crear o actualizar las asignadas. Una cola sin PPD (raw) se vuelve a crear: queda
        #    así si la cola del servidor no respondía al crearla, y Chrome no imprime en ella.
        for name, uri in sorted(desired.items()):
            if current_uris.get(name) == uri and os.path.exists(os.path.join(LOCAL_PPD_DIR, f'{name}.ppd')):
                if name not in managed:
                    messages.append(f'{name}: ya existía, pasa a gestionarla EduControl')
                managed.add(name)
                continue
            error = self._add_queue(name, uri)
            if error:
                errors.append(f'{name}: {error}')
                continue
            verb = 'actualizada' if name in current_uris else 'creada'
            messages.append(f'{name}: {verb} ({uri})')
            managed.add(name)

        # 3. Quitar las que ya no están asignadas (solo las nuestras).
        for name in sorted(managed - set(desired)):
            if name in current_uris:
                result = self._run(['lpadmin'] + self._local_cups_args() + ['-x', name])
                if result.returncode != 0:
                    errors.append(f'{name}: {result.stderr.strip() or "no se pudo eliminar"}')
                    continue
                messages.append(f'{name}: eliminada (ya no está asignada)')
            managed.discard(name)

        # 4. Predeterminada: la de la web; si no hay, se respeta la actual si es asignada,
        #    y si no, la primera por orden alfabético.
        installed = sorted(n for n in desired if n in managed)
        if installed:
            current_default = self._default_queue()
            target = default if default in installed else (
                current_default if current_default in installed else installed[0])
            if target != current_default:
                result = self._run(['lpadmin'] + self._local_cups_args() + ['-d', target])
                if result.returncode == 0:
                    messages.append(f'Predeterminada: {target}')
                else:
                    errors.append(f'Predeterminada {target}: {result.stderr.strip() or "no se pudo fijar"}')

        # 5. Sin colas asignadas, el client.conf que se retiró vuelve a su sitio.
        if not desired and state.pop('client_conf_removed', False) and os.path.exists(CLIENT_CONF_BACKUP):
            os.replace(CLIENT_CONF_BACKUP, CLIENT_CONF)
            messages.append(f'{CLIENT_CONF} restaurado')

        state['managed_queues'] = sorted(managed)
        state['server'] = server
        self._save_state(state)

        rep_ok, rep_out, rep_err = self.report_queues()
        summary = '\n'.join(messages) or 'Las colas ya estaban al día'
        logger.info(f"🖨️ Colas de impresión sincronizadas: {'; '.join(messages) or 'sin cambios'}")
        if errors:
            logger.error(f"❌ Impresión: {'; '.join(errors)}")
            return False, summary, '\n'.join(errors)
        return True, f"{summary}\n{rep_out if rep_ok else rep_err}", ''

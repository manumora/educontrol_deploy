"""
inventory.py — Recopilación de inventario de hardware/software para EduControl Agent.
"""

import logging
import platform
import socket
import subprocess
import time

logger = logging.getLogger('EduControlAgent')

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False


def collect_system_inventory() -> dict:
    """Recopila información del sistema para el inventario.

    Returns:
        dict con información del hardware y software del equipo.
    """
    inventory: dict = {}

    try:
        # Información básica
        inventory['hostname'] = platform.node()
        inventory['processor_architecture'] = platform.machine()

        # IP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            inventory['ip_address'] = s.getsockname()[0]
            s.close()
        except Exception:
            inventory['ip_address'] = '127.0.0.1'

        # UUID del sistema
        try:
            if platform.system() == 'Windows':
                result = subprocess.run(
                    ['wmic', 'csproduct', 'get', 'uuid'], capture_output=True, text=True
                )
                uuid_str = result.stdout.strip().split('\n')[-1].strip()
                if uuid_str and uuid_str != 'UUID':
                    inventory['uuid'] = uuid_str
            elif platform.system() == 'Linux':
                try:
                    with open('/sys/class/dmi/id/product_uuid', 'r') as f:
                        inventory['uuid'] = f.read().strip()
                except Exception:
                    pass
            elif platform.system() == 'Darwin':
                result = subprocess.run(
                    ['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'], capture_output=True, text=True
                )
                for line in result.stdout.split('\n'):
                    if 'IOPlatformUUID' in line:
                        inventory['uuid'] = line.split('"')[3]
                        break
        except Exception:
            pass

        # Sistema operativo
        inventory['os_name'] = f"{platform.system()} {platform.release()}"
        inventory['os_version'] = platform.version()
        inventory['os_architecture'] = platform.architecture()[0]

        try:
            inventory['os_kernel_version'] = platform.release()
        except Exception:
            pass

        # Información con psutil
        if PSUTIL_AVAILABLE:
            inventory['processor_name'] = platform.processor()
            inventory['processor_cores'] = psutil.cpu_count(logical=False)
            inventory['processor_threads'] = psutil.cpu_count(logical=True)

            try:
                cpu_freq = psutil.cpu_freq()
                if cpu_freq:
                    inventory['processor_speed'] = (
                        f"{cpu_freq.max:.2f} GHz" if cpu_freq.max else f"{cpu_freq.current:.2f} GHz"
                    )
            except Exception:
                pass

            mem = psutil.virtual_memory()
            inventory['ram_total_mb'] = mem.total // (1024 * 1024)

            # Discos
            disks = []
            total_storage = 0
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    size_gb = usage.total // (1024 ** 3)
                    disks.append({
                        'name': partition.device,
                        'mountpoint': partition.mountpoint,
                        'size_gb': size_gb,
                        'type': partition.fstype,
                    })
                    total_storage += size_gb
                except Exception:
                    pass
            if disks:
                inventory['disks'] = disks
                inventory['total_storage_gb'] = total_storage

            # Interfaces de red
            network_interfaces = []
            ethernet_mac = None
            wifi_mac = None
            ethernet_ip = None
            wifi_ip = None

            wifi_keywords = ['wlan', 'wifi', 'wlp', 'wlx', 'wifi0']

            for iface, addrs in psutil.net_if_addrs().items():
                if iface.lower() in ['lo', 'loopback'] or iface.lower().startswith(
                        ('veth', 'br-', 'docker', 'virbr')):
                    continue

                iface_data = {'name': iface}
                is_wifi = any(iface.lower().startswith(k) for k in wifi_keywords)
                is_ethernet = any(
                    iface.lower().startswith(k)
                    for k in ['eth', 'enp', 'eno', 'ens', 'enx', 'ethernet']
                )

                for addr in addrs:
                    if addr.family == socket.AF_INET:
                        ip = addr.address
                        iface_data['ip'] = ip
                        if is_ethernet and not ethernet_ip:
                            ethernet_ip = ip
                        elif is_wifi and not wifi_ip:
                            wifi_ip = ip
                    else:
                        mac_family = None
                        if hasattr(psutil, 'AF_LINK'):
                            mac_family = psutil.AF_LINK
                        elif hasattr(socket, 'AF_LINK'):
                            mac_family = socket.AF_LINK
                        elif hasattr(socket, 'AF_PACKET'):
                            mac_family = socket.AF_PACKET

                        is_mac_family = (
                            (mac_family is not None and addr.family == mac_family)
                            or addr.family == 17
                            or addr.family == -1
                        )

                        if is_mac_family:
                            try:
                                mac = addr.address.upper()
                                if mac and mac != '00:00:00:00:00:00' and len(mac) == 17:
                                    iface_data['mac'] = mac
                                    if is_ethernet and not ethernet_mac:
                                        ethernet_mac = mac
                                    elif is_wifi and not wifi_mac:
                                        wifi_mac = mac
                            except Exception:
                                pass

                if 'ip' in iface_data or 'mac' in iface_data:
                    network_interfaces.append(iface_data)

            # Garantizar que ethernet_mac proviene de la misma interfaz que ethernet_ip
            # para evitar identificadores inconsistentes entre ejecuciones
            if ethernet_ip:
                for iface_data in network_interfaces:
                    if iface_data.get('ip') == ethernet_ip and 'mac' in iface_data:
                        ethernet_mac = iface_data['mac']
                        break

            inventory['ip_address'] = ethernet_ip or ''
            if wifi_ip:
                inventory['wifi_ip_address'] = wifi_ip

            if ethernet_mac:
                inventory['mac_address'] = ethernet_mac
            elif not inventory.get('mac_address'):
                for iface_data in network_interfaces:
                    if 'mac' in iface_data and iface_data['mac'] != wifi_mac:
                        inventory['mac_address'] = iface_data['mac']
                        break
            if wifi_mac:
                inventory['wifi_mac_address'] = wifi_mac
            if network_interfaces:
                inventory['network_interfaces'] = network_interfaces

            # Uptime
            inventory['uptime_seconds'] = int(time.time() - psutil.boot_time())

            # Usuarios del sistema
            try:
                users = psutil.users()
                if users:
                    inventory['system_users'] = [
                        {'name': u.name, 'terminal': u.terminal} for u in users
                    ]
            except Exception:
                pass

        # Fabricante / modelo
        try:
            if platform.system() == 'Windows':
                for field, cmd in [
                    ('manufacturer', ['wmic', 'computersystem', 'get', 'manufacturer']),
                    ('model', ['wmic', 'computersystem', 'get', 'model']),
                    ('serial_number', ['wmic', 'bios', 'get', 'serialnumber']),
                    ('bios_version', ['wmic', 'bios', 'get', 'version']),
                ]:
                    result = subprocess.run(cmd, capture_output=True, text=True)
                    value = result.stdout.strip().split('\n')[-1].strip()
                    if value and value not in ('Manufacturer', 'Model', 'SerialNumber', 'Version'):
                        inventory[field] = value

            elif platform.system() == 'Linux':
                dmi_fields = {
                    'manufacturer': '/sys/class/dmi/id/sys_vendor',
                    'model': '/sys/class/dmi/id/product_name',
                    'serial_number': '/sys/class/dmi/id/product_serial',
                    'bios_version': '/sys/class/dmi/id/bios_version',
                }
                for field, path in dmi_fields.items():
                    try:
                        with open(path, 'r') as f:
                            inventory[field] = f.read().strip()
                    except Exception:
                        pass

            elif platform.system() == 'Darwin':
                result = subprocess.run(
                    ['system_profiler', 'SPHardwareDataType'], capture_output=True, text=True
                )
                for line in result.stdout.split('\n'):
                    line = line.strip()
                    if 'Model Name:' in line:
                        inventory['manufacturer'] = 'Apple'
                        inventory['model'] = line.split(':')[1].strip()
                    elif 'Serial Number' in line:
                        inventory['serial_number'] = line.split(':')[1].strip().split()[0]
        except Exception as e:
            logger.debug(f"Error obteniendo información del fabricante: {e}")

        logger.info(f"📊 Información de inventario recopilada: {len(inventory)} campos")

    except Exception as e:
        logger.error(f"Error recopilando inventario: {e}")

    return inventory

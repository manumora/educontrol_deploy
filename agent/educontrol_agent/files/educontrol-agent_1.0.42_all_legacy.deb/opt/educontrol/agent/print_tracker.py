"""
print_tracker.py — Monitor en tiempo real de impresiones CUPS para EduControl Agent.

Utiliza inotify para observar el directorio /var/log/cups/ y parsea el archivo
page_log para enviar cada trabajo de impresión al servidor EduControl.
"""

import logging
import os
import re
import threading
import time
from datetime import datetime
from typing import Optional

logger = logging.getLogger('EduControlAgent')

# ── dependencias opcionales ──────────────────────────────────────────────────

try:
    # v1.x API: Watcher + flags
    from inotify_simple import Watcher, flags
    INOTIFY_AVAILABLE = True
    INOTIFY_V2 = False
except ImportError:
    try:
        # v2.x API: INotify + flags
        import inotify_simple
        INOTIFY_AVAILABLE = True
        INOTIFY_V2 = True
    except ImportError:
        INOTIFY_AVAILABLE = False
        INOTIFY_V2 = False

try:
    import cups
    PYCUPS_AVAILABLE = True
except ImportError:
    PYCUPS_AVAILABLE = False

# ── constantes ───────────────────────────────────────────────────────────────

PAGE_LOG_DIR = '/var/log/cups/'
PAGE_LOG_FILE = os.path.join(PAGE_LOG_DIR, 'page_log')
PAGE_LOG_STATE_FILE = os.path.join(PAGE_LOG_DIR, '.educontrol_page_log_pos')

# Regex para la línea CUPS:
#   <Printer> <User> <Job_ID> [<Date>] total <Total_Sheets> <Host> <Document_Name>
LINE_RE = re.compile(
    r'^(\S+)\s+(\S+)\s+(\d+)\s+\[(.*?)\]\s+total\s+(\d+)\s+(\S+)\s+(.*)$'
)


class PrintTracker:
    """Monitoriza /var/log/cups/page_log y envía registros al backend."""

    def __init__(self, config):
        """
        Args:
            config: instancia de AgentConfig con http_url, token, agent_id,
                    verify_ssl, hostname y print_tracking.
        """
        self.config = config
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        # Posición en el archivo page_log (offset en bytes) para no
        # reenviar registros ya procesados en arranques anteriores.
        self._last_pos = self._load_position()

    # ── helpers privados ─────────────────────────────────────────────────────

    def _get_copies(self, job_id: int) -> int:
        """
        Consulta el servidor CUPS local para obtener el número de copias
        del trabajo.

        Returns:
            Número de copias si CUPS lo devuelve, o None si no se pudo
            obtener (el backend enviará null al frontend, que mostrará '—').
        """
        if not PYCUPS_AVAILABLE:
            return None

        try:
            conn = cups.Connection()
            job = conn.getJobAttributes(job_id)

            # Número de copias — la clave IPP estándar es 'copies'
            for key in ('copies', 'num-copies', 'number-of-copies'):
                if key in job:
                    try:
                        val = int(job[key])
                        if val > 0:
                            return val
                    except (ValueError, TypeError):
                        pass

            return None

        except Exception as e:
            logger.debug(
                f"PrintTracker: no se pudo consultar Job {job_id} en CUPS: {e}"
            )
            return None

    def _send_print_log(self, data: dict) -> bool:
        """
        Envía un registro de impresión al servidor EduControl vía HTTP POST.

        Returns:
            True si el servidor respondió con 2xx.
        """
        try:
            import requests as _requests

            url = f"{self.config.http_url}/api/print-logs/create/"
            headers = {'Content-Type': 'application/json'}
            if self.config.token:
                headers['Authorization'] = f'Token {self.config.token}'

            payload = {
                'agent_id': self.config.agent_id,
                'hostname': self.config.hostname,
                **data,
            }

            resp = _requests.post(
                url, json=payload, headers=headers,
                timeout=10, verify=self.config.verify_ssl,
            )
            if resp.status_code == 201:
                logger.info(f"PrintTracker: envío OK — {data.get('user')}/{data.get('document_name')} en {data.get('printer_name')}")
                return True
            else:
                logger.warning(
                    f"PrintTracker: fallo al enviar (HTTP {resp.status_code}): {resp.text[:200]}"
                )
                return False
        except ImportError:
            logger.warning("PrintTracker: requests no disponible, no se puede enviar registro")
            return False
        except Exception as e:
            logger.warning(f"PrintTracker: error al enviar registro: {e}")
            return False

    def _load_position(self) -> int:
        """Lee la posición última procesada desde el archivo de estado."""
        try:
            if os.path.isfile(PAGE_LOG_STATE_FILE):
                with open(PAGE_LOG_STATE_FILE, 'r') as f:
                    return int(f.read().strip())
        except (ValueError, OSError):
            pass
        return 0

    def _save_position(self, pos: int):
        """Guarda la posición actual procesada en el archivo de estado."""
        try:
            with open(PAGE_LOG_STATE_FILE, 'w') as f:
                f.write(str(pos))
        except OSError as e:
            logger.warning(f"PrintTracker: no se pudo guardar posición: {e}")

    def _parse_and_send(self, filepath: str):
        """
        Lee las nuevas líneas del archivo (desde la última posición
        conocida) y envía cada registro.
        """
        try:
            with open(filepath, 'r') as f:
                # Saltar a la posición última procesada
                f.seek(self._last_pos)

                for line in f:
                    line = line.strip()
                    if not line or 'total' not in line:
                        continue

                    m = LINE_RE.match(line)
                    if not m:
                        continue

                    printer_name = m.group(1)
                    user = m.group(2)
                    job_id = int(m.group(3))
                    date_str = m.group(4)
                    total_sheets = int(m.group(5))
                    host = m.group(6)
                    document_name = m.group(7).strip()

                    # Consultar CUPS para el número de copias
                    copies = self._get_copies(job_id)

                    # Si hay copias, se calculan las páginas del documento;
                    # si no, ambos se envían como null (mostrará '—' en el grid)
                    if copies is not None:
                        document_pages = total_sheets // copies
                    else:
                        document_pages = None

                    # Intentar parsear la fecha de CUPS; fallback a now()
                    timestamp = datetime.now().isoformat()
                    try:
                        dt = datetime.strptime(date_str, '%d/%b/%Y:%H:%M:%S %z')
                        timestamp = dt.isoformat()
                    except ValueError:
                        pass

                    logger.info(
                        f"PrintTracker: nueva impresión detectada — "
                        f"user={user}, printer={printer_name}, doc={document_name}, "
                        f"job_id={job_id}, sheets={total_sheets}"
                    )

                    self._send_print_log({
                        'user': user,
                        'printer_name': printer_name,
                        'document_name': document_name,
                        'copies': copies,
                        'document_pages': document_pages,
                        'total_sheets': total_sheets,
                        'timestamp': timestamp,
                    })

                # Actualizar posición (fin del archivo leído)
                new_pos = f.tell()
                with self._lock:
                    self._last_pos = new_pos
                    self._save_position(new_pos)

        except OSError as e:
            logger.warning(f"PrintTracker: error leyendo {filepath}: {e}")

    def _watch(self):
        """
        Bucle principal del hilo: inicializa inotify y espera eventos en el
        directorio de logs.  Compatible con inotify-simple v1.x y v2.x.
        """
        if not os.path.isdir(PAGE_LOG_DIR):
            logger.warning(f"PrintTracker: directorio {PAGE_LOG_DIR} no existe; omitiendo")
            return

        # Si el archivo ya existe y tiene contenido, procesarlo antes de vigilar.
        if os.path.isfile(PAGE_LOG_FILE):
            logger.info("PrintTracker: procesando registros previos de page_log...")
            self._parse_and_send(PAGE_LOG_FILE)

        logger.info("PrintTracker: iniciando watcher en %s (inotify-simple v%s)",
                    PAGE_LOG_DIR, "2.x" if INOTIFY_V2 else "1.x")

        while not self._stop_event.is_set():
            try:
                if INOTIFY_V2:
                    self._watch_v2()
                else:
                    self._watch_v1()

            except Exception as e:
                logger.warning(f"PrintTracker: error en watcher: {e}")
                if self._stop_event.is_set():
                    break
                time.sleep(3)

    # ── watchers por versión ───────────────────────────────────────────────

    def _watch_v1(self):
        """inotify-simple v1.x: API Watcher."""
        watcher = Watcher()
        watcher.add_watch(PAGE_LOG_DIR, flags.MODIFY | flags.CREATE)

        while not self._stop_event.is_set():
            events = watcher.event(timeout=1000)

            for event in events:
                # Ignorar eventos de directorio o ignorados
                if 'ISDIR' in event.mask_names or 'IGNORE' in event.mask_names:
                    continue

                # Filtrar para el archivo page_log
                if event.name and 'page_log' in event.name:
                    logger.debug(f"PrintTracker: evento inotify en page_log ({event.mask_names})")
                    time.sleep(0.1)
                    if os.path.isfile(PAGE_LOG_FILE):
                        self._parse_and_send(PAGE_LOG_FILE)

    def _watch_v2(self):
        """inotify-simple v2.x: API INotify."""
        import inotify_simple as inotify

        inf = inotify.INotify()
        inf.add_watch(
            PAGE_LOG_DIR,
            inotify.flags.MODIFY | inotify.flags.CREATE,
        )

        while not self._stop_event.is_set():
            events = inf.read(timeout=1000)

            for ev in events:
                # Ignorar eventos de directorio o ignorados
                if inotify.flags.ISDIR.value & ev.mask:
                    continue
                if inotify.flags.IGNORED.value & ev.mask:
                    continue

                # Filtrar para el archivo page_log
                if ev.name and 'page_log' in ev.name:
                    logger.debug(f"PrintTracker: evento inotify en page_log (mask={ev.mask:#x})")
                    time.sleep(0.1)
                    if os.path.isfile(PAGE_LOG_FILE):
                        self._parse_and_send(PAGE_LOG_FILE)

    # ── control del hilo ────────────────────────────────────────────────────

    def start(self):
        """Inicia el hilo de monitoreo de impresiones."""
        if not INOTIFY_AVAILABLE:
            logger.warning("PrintTracker: inotify_simple no disponible; monitoreo desactivado")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._watch, daemon=True, name='PrintTracker')
        self._thread.start()
        logger.info("PrintTracker: hilo iniciado")

    def stop(self):
        """Detiene el hilo de monitoreo."""
        self._stop_event.set()
        if hasattr(self, '_thread') and self._thread.is_alive():
            self._thread.join(timeout=5)
        logger.info("PrintTracker: hilo detenido")

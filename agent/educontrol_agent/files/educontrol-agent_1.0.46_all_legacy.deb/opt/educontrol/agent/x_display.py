"""
x_display.py — Localización de los servidores X activos del equipo.

La pantalla de login y la sesión del usuario son servidores X distintos, con
número de display y cookie de autenticación propios, y el gestor de sesiones
destruye uno y crea el otro en cada inicio y cierre de sesión. Todo lo que
necesite pintar o leer la pantalla física (VNC, thumbnails del mosaico) necesita
saber cuál está activo en cada momento, de ahí este módulo compartido.
"""

import glob
import logging
import os
import re
from typing import List, Optional, Tuple

logger = logging.getLogger('EduControlAgent')


def find_x_servers() -> List[Tuple[str, Optional[str]]]:
    """Devolver los servidores X activos como (display, fichero -auth).

    Se lee la línea de comandos de los procesos Xorg porque, además del número
    de display, da el fichero `-auth`: la cookie del greeter del gestor de
    sesiones y la de la sesión del usuario son distintas y viven en rutas
    distintas. La lista va del más reciente al más antiguo, que es el orden útil
    cuando durante la transición de un login o un logout conviven dos.
    """
    candidates = []  # (start_time, display, auth)

    for cmdline_path in glob.glob('/proc/[0-9]*/cmdline'):
        try:
            with open(cmdline_path, 'rb') as f:
                args = [a.decode('utf-8', 'ignore') for a in f.read().split(b'\0') if a]
            if not args:
                continue
            # Xwayland no sirve: sólo expone los clientes X11 de la sesión,
            # no el escritorio completo.
            if os.path.basename(args[0]) not in ('Xorg', 'X'):
                continue

            display = next((a for a in args[1:] if re.fullmatch(r':\d+', a)), None)
            if not display:
                continue

            auth = None
            if '-auth' in args:
                idx = args.index('-auth')
                if idx + 1 < len(args):
                    auth = args[idx + 1]
            if auth and not os.path.exists(auth):
                auth = None

            # Campo 22 de /proc/pid/stat (starttime); el nombre del proceso va
            # entre paréntesis y puede contener espacios, de ahí el split
            stat_path = os.path.join(os.path.dirname(cmdline_path), 'stat')
            with open(stat_path) as f:
                start_time = int(f.read().rsplit(')', 1)[1].split()[19])

            candidates.append((start_time, display, auth))
        except Exception:
            continue

    candidates.sort(key=lambda c: c[0], reverse=True)
    return [(display, auth) for _, display, auth in candidates]


def find_x_display() -> Tuple[Optional[str], Optional[str]]:
    """Display y cookie del servidor X más reciente, que es el visible.

    Vale tanto para la pantalla de login como para la sesión del usuario: no
    distingue quién la está usando, sólo qué servidor X está pintando.
    """
    servers = find_x_servers()
    return servers[0] if servers else (None, None)

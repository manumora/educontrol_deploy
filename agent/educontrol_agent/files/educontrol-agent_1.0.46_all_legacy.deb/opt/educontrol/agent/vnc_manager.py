"""
vnc_manager.py — Gestión del servicio x11vnc para EduControl Agent.
"""

import glob
import logging
import os
import socket
import subprocess
import time
from typing import Optional

from x_display import find_x_display

logger = logging.getLogger('EduControlAgent')

# Segundos que se espera a que quede libre el puerto RFB del proceso anterior
# antes de buscar otro puerto distinto.
PORT_RELEASE_WAIT = 3


class VNCManager:
    """Gestor del servicio x11vnc."""

    def __init__(self, token: str, port: int = 5900):
        self.token = token
        self.base_port = port
        self.port = port
        self.process = None
        self.passwd_file = '/tmp/.educontrol_vnc.pass'
        self.log_file = '/var/log/educontrol/x11vnc.log'
        # Display X y cookie a los que está atado el proceso actual
        self.display: Optional[str] = None
        self.auth_file: Optional[str] = None
        self._start_failed = False

    # ── helpers ─────────────────────────────────────────────────────────────

    def _create_passwd_file(self) -> bool:
        """Crear archivo de password para x11vnc (primeros 8 chars del token)."""
        try:
            vnc_pass = self.token[:8] if self.token else "educontrol"
            cmd = ['x11vnc', '-storepasswd', vnc_pass, self.passwd_file]
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            os.chmod(self.passwd_file, 0o600)
            return True
        except Exception as e:
            logger.error(f"Error creando archivo password VNC: {e}")
            return False

    def _is_port_in_use(self, port: int) -> bool:
        """Comprobar si un puerto está en uso."""
        for host in ['127.0.0.1', '0.0.0.0']:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(0.5)
                    if s.connect_ex((host, port)) == 0:
                        return True
            except Exception:
                pass
        return False

    def _kill_stale(self):
        """Matar instancias previas de x11vnc lanzadas por el agente.

        Se comprueba el nombre del proceso además del fichero de password: un
        `pgrep -f` a secas también acierta con cualquier proceso que mencione esa
        ruta en su línea de comandos, y matarlo sería un estropicio.
        """
        for cmdline_path in glob.glob('/proc/[0-9]*/cmdline'):
            try:
                with open(cmdline_path, 'rb') as f:
                    args = [a.decode('utf-8', 'ignore') for a in f.read().split(b'\0') if a]
                if not args or os.path.basename(args[0]) != 'x11vnc':
                    continue
                if self.passwd_file not in args:
                    continue
                pid = int(os.path.basename(os.path.dirname(cmdline_path)))
                logger.debug(f"Matando instancia previa de VNC (PID {pid})")
                os.kill(pid, 9)
            except Exception:
                continue

    def _prepare_port(self) -> bool:
        """Reservar el puerto RFB, reutilizando el ya publicado si se puede.

        El servidor guarda ip:puerto en base de datos y el proxy VNC se conecta
        exactamente ahí, así que cambiar de puerto en cada reinicio dejaría la
        consola apuntando a un puerto muerto hasta el siguiente vnc_info. Se
        espera un momento a que el socket del proceso anterior se libere antes
        de buscar otro.
        """
        deadline = time.time() + PORT_RELEASE_WAIT
        while self._is_port_in_use(self.port) and time.time() < deadline:
            time.sleep(0.2)

        if not self._is_port_in_use(self.port):
            return True

        for i in range(10):
            candidate = self.base_port + i
            if not self._is_port_in_use(candidate):
                logger.info(f"Puerto {self.port} ocupado, usando {candidate}")
                self.port = candidate
                return True

        logger.error("❌ No se encontró puerto libre para VNC")
        return False

    def _ensure_log_dir(self):
        log_dir = os.path.dirname(self.log_file)
        if not os.path.exists(log_dir):
            try:
                os.makedirs(log_dir, exist_ok=True)
            except Exception:
                self.log_file = f'/tmp/x11vnc_{self.port}.log'

    # ── ciclo de vida ────────────────────────────────────────────────────────

    def start(self) -> bool:
        """Iniciar servicio x11vnc contra el servidor X que esté activo."""
        if self.process and self.process.poll() is None:
            return True

        if subprocess.call(['which', 'x11vnc'], stdout=subprocess.DEVNULL) != 0:
            logger.warning("x11vnc no instalado. Instalando con apt...")
            subprocess.run(['apt-get', 'install', '-y', 'x11vnc'], stdout=subprocess.DEVNULL)

        if not self._create_passwd_file():
            return False

        self._ensure_log_dir()

        try:
            display, auth = find_x_display()
            if not display:
                # Momento entre que el gestor de sesiones mata un servidor X y
                # arranca el siguiente: no hay nada que compartir todavía.
                self._log_start_failure("⏳ Sin servidor X activo, se reintentará")
                return False

            self._kill_stale()

            if not self._prepare_port():
                return False

            cmd = [
                'x11vnc',
                '-display', display,
                '-auth', auth or 'guess',
                '-forever',
                '-shared',
                '-xrandr', 'resize',
                '-rfbauth', self.passwd_file,
                '-rfbport', str(self.port),
                '-o', self.log_file,
                '-q',
            ]

            env = os.environ.copy()
            if not auth:
                # Permite que "guess" mire también las cookies del gestor de
                # sesiones (lightdm/gdm), no sólo las de usuarios normales.
                env['FD_XDM'] = '1'

            self.process = subprocess.Popen(
                cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env
            )
            time.sleep(1)

            if self.process.poll() is not None:
                self.process = None
                self._log_start_failure(
                    f"❌ x11vnc terminó inmediatamente (display {display}, puerto {self.port})"
                )
                return False

            self.display = display
            self.auth_file = auth
            self._start_failed = False
            logger.info(f"✅ Servicio VNC iniciado en puerto {self.port} (display {display})")
            return True

        except Exception as e:
            logger.error(f"❌ Error iniciando VNC: {e}")
            return False

    def restart(self) -> bool:
        """Relanzar x11vnc contra el servidor X actual."""
        self._terminate_process()
        return self.start()

    def needs_restart(self) -> bool:
        """Decidir si hay que relanzar x11vnc.

        En cada login y en cada logout el gestor de sesiones destruye el
        servidor X y arranca otro: x11vnc pierde la conexión y termina, porque
        `-forever` sólo mantiene el puerto abierto entre clientes VNC, no entre
        servidores X. Además el display puede cambiar de número, así que un
        x11vnc vivo pero atado al display anterior también hay que relanzarlo.
        """
        if not self.is_running():
            return True

        display, _ = find_x_display()
        if display and self.display and display != self.display:
            logger.info(f"🔄 El servidor X pasó de {self.display} a {display}, relanzando VNC")
            return True

        return False

    def _log_start_failure(self, message: str):
        """Avisar del primer fallo y bajar a debug los siguientes.

        El vigilante reintenta cada pocos segundos: sin esto, un equipo apagado
        gráficamente llenaría el log de avisos idénticos.
        """
        if self._start_failed:
            logger.debug(message)
        else:
            logger.warning(message)
            self._start_failed = True

    def _terminate_process(self):
        """Parar el proceso x11vnc dejando intacto el archivo de password."""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None

        self._kill_stale()
        self.display = None
        self.auth_file = None

    def stop(self):
        """Detener servicio VNC."""
        self._terminate_process()

        if os.path.exists(self.passwd_file):
            try:
                os.remove(self.passwd_file)
            except Exception:
                pass

        logger.info("🛑 Servicio VNC detenido")

    def is_running(self) -> bool:
        """Verificar si el proceso sigue vivo."""
        if self.process:
            if self.process.poll() is None:
                return True
            self.process = None
        return False

    def get_info(self) -> dict:
        """Obtener info de conexión para el servidor."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
        except Exception:
            ip = "127.0.0.1"

        return {
            "type": "vnc_info",
            "available": True,
            "ip": ip,
            "port": self.port,
            "password": self.token[:8] if self.token else "educontrol",
        }

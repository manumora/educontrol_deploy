#!/usr/bin/env python3
"""
Password Change Prompt for EduControl Agent
===========================================

Cuando un usuario inicia sesión, consulta al servidor el estado de su cuenta: si es
cualquier cosa distinta de "cuenta correcta" (bloqueada, se la restableció un
administrador, ya ha caducado, está a punto de hacerlo o nunca la ha cambiado), le
abre el navegador en la página de cambio.

El comportamiento está desactivado por defecto y se controla desde agent_config.json:

    "password_prompt_enabled": false,
    "password_prompt_url": "https://educontrol.santaeulalia/change-password",
    "password_prompt_delay": 15

Cada apertura del navegador (y cada fallo al abrirlo) se registra en la auditoría
del servidor.
"""

import logging
import threading
import time
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlencode

logger = logging.getLogger('PasswordPrompt')

# Tipos de sesión en los que tiene sentido abrir un navegador
GRAPHICAL_SESSION_TYPES = ('x11', 'wayland')

# Cómo se explica cada motivo en el log
REASON_LABELS = {
    'locked': 'la cuenta está bloqueada',
    'must_change': 'debe cambiarla tras un restablecimiento',
    'expired': 'la contraseña ha caducado',
    'expiring_soon': 'la contraseña caduca pronto',
    'never_changed': 'nunca ha cambiado la contraseña',
}


def should_prompt(
    payload: Optional[Dict],
    enabled_reasons: Optional[Dict[str, bool]] = None,
) -> Tuple[bool, List[str]]:
    """Decidir, a partir de la respuesta del servidor, si hay que avisar al usuario.

    Función pura, sin red ni efectos: recibe el JSON de
    `users/<uid>/password-change-required/` y devuelve (avisar, motivos).

    `enabled_reasons` son los motivos habilitados en la configuración del agente;
    los motivos desactivados se descartan. Si no se indica, valen todos.

    No se avisa si el servidor no ha podido leer el estado de la cuenta
    (`state_readable: false`): más vale no molestar que hacerlo por datos sin confirmar.
    """
    if not payload:
        return False, []

    if not payload.get('state_readable', False):
        return False, []

    reasons = [str(r) for r in (payload.get('reasons') or [])]

    if enabled_reasons is not None:
        reasons = [r for r in reasons if enabled_reasons.get(r, False)]

    return bool(payload.get('required')) and bool(reasons), reasons


def build_prompt_url(base_url: str, username: str, reasons: List[str],
                     days_left: Optional[int] = None) -> str:
    """Añadir a la URL el motivo del aviso, para que la página pueda explicárselo al usuario.

    Función pura. Ejemplo:
        …/change-password?uid=jperez&reason=expiring_soon&days=5
    """
    if not reasons:
        return base_url

    params = {
        'uid': username,
        # El primero es el más urgente; la página muestra ese
        'reason': reasons[0],
    }
    if len(reasons) > 1:
        params['reasons'] = ','.join(reasons)
    if days_left is not None:
        params['days'] = str(days_left)

    separator = '&' if '?' in base_url else '?'
    return f"{base_url}{separator}{urlencode(params)}"


class PasswordChangePrompter:
    """Abre el navegador al usuario que acaba de entrar si debe cambiar su contraseña."""

    def __init__(self, config, actions):
        """
        Args:
            config: AgentConfig con password_prompt_* , token, http_url y verify_ssl
            actions: AgentActions, que ya sabe abrir una URL en la sesión gráfica
        """
        self.config = config
        self.actions = actions

    # ── entrada pública ────────────────────────────────────────────────────

    def maybe_prompt(self, session_data: Dict):
        """Lanzar la comprobación en un hilo aparte.

        El callback de login se ejecuta en el hilo de D-Bus: bloquearlo con una espera
        y una petición HTTP retrasaría la detección de otras sesiones.
        """
        if not self.config.password_prompt_enabled:
            return

        username = (session_data or {}).get('username')
        if not username:
            return

        session_type = (session_data or {}).get('type')
        # Si no conocemos el tipo, seguimos: _launch_url ya exige una sesión gráfica activa
        if session_type and session_type not in GRAPHICAL_SESSION_TYPES:
            logger.debug(f"Sesión no gráfica ({session_type}) para {username}: no se avisa")
            return

        threading.Thread(
            target=self._prompt_worker,
            args=(username,),
            daemon=True,
            name=f"PasswordPrompt-{username}",
        ).start()

    # ── trabajo en segundo plano ───────────────────────────────────────────

    def _prompt_worker(self, username: str):
        """Consultar al servidor y, si procede, abrir el navegador. No propaga errores."""
        try:
            delay = max(0, int(self.config.password_prompt_delay or 0))
            if delay:
                # Dar tiempo a que el escritorio termine de arrancar: si no, aún no hay
                # DISPLAY ni XDG_RUNTIME_DIR donde lanzar el navegador
                time.sleep(delay)

            payload = self._fetch_status(username)
            enabled = getattr(self.config, 'password_prompt_reasons', None)
            prompt, reasons = should_prompt(payload, enabled)

            if not prompt:
                logger.debug(f"{username} no necesita cambiar la contraseña")
                return

            motivos = ', '.join(REASON_LABELS.get(r, r) for r in reasons)
            logger.info(f"🔐 {username}: {motivos}. Abriendo el navegador...")

            # La URL lleva el motivo para que la página pueda explicárselo al usuario
            url = build_prompt_url(
                self.config.password_prompt_url,
                username,
                reasons,
                (payload or {}).get('days_left'),
            )
            result = self.actions.execute("launch_url", {"url": url, "user": username})

            if result.success:
                logger.info(f"✅ Aviso de cambio de contraseña abierto para {username}")
            else:
                logger.warning(f"⚠️  No se pudo abrir el navegador para {username}: {result.stderr}")

            self._report(username, reasons, url, result.success, result.stderr)

        except Exception as e:
            # Un fallo aquí no puede afectar al inicio de sesión del usuario
            logger.error(f"Error avisando del cambio de contraseña a {username}: {e}")

    # ── llamadas al servidor ───────────────────────────────────────────────

    def _headers(self) -> Dict[str, str]:
        headers = {'Content-Type': 'application/json'}
        if self.config.token:
            headers['Authorization'] = f'Token {self.config.token}'
        return headers

    def _fetch_status(self, username: str) -> Optional[Dict]:
        """Preguntar al servidor si el usuario debe cambiar su contraseña."""
        try:
            import requests
        except ImportError:
            logger.debug("requests no disponible: no se puede consultar la política")
            return None

        url = f"{self.config.http_url}/api/users/{username}/password-change-required/"
        try:
            response = requests.get(
                url,
                headers=self._headers(),
                timeout=10,
                verify=self.config.verify_ssl,
            )
            if response.status_code == 200:
                return response.json()

            logger.warning(
                f"⚠️  No se pudo consultar la política de {username}: HTTP {response.status_code}"
            )
            return None
        except Exception as e:
            logger.error(f"Error consultando la política de {username}: {e}")
            return None

    def _report(self, username: str, reasons: List[str], url: str, success: bool, error: str):
        """Registrar en la auditoría del servidor que se ha abierto (o intentado) el aviso."""
        try:
            import requests
        except ImportError:
            return

        endpoint = f"{self.config.http_url}/api/users/{username}/password-change-prompted/"
        try:
            requests.post(
                endpoint,
                json={
                    'agent_id': self.config.agent_id,
                    'reasons': reasons,
                    'url': url,
                    'success': success,
                    'error': error or '',
                },
                headers=self._headers(),
                timeout=10,
                verify=self.config.verify_ssl,
            )
        except Exception as e:
            logger.error(f"Error registrando el aviso de {username} en auditoría: {e}")

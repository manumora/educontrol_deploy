#!/usr/bin/env python3
"""
Screenshot Streamer para EduControl Agent
==========================================

Captura periódica de la pantalla del equipo y envío como thumbnail
JPEG comprimido vía WebSocket al servidor.

Usa `mss` para captura rápida y `Pillow` para redimensionar y comprimir.
"""

import asyncio
import base64
import io
import glob
import logging
import os
from typing import Optional

from x_display import find_x_servers, find_x_display

logger = logging.getLogger(__name__)

# Importaciones opcionales
try:
    import mss
    MSS_AVAILABLE = True
except ImportError:
    MSS_AVAILABLE = False
    logger.debug("mss no disponible – screenshot streaming desactivado")

try:
    from PIL import Image
    PILLOW_AVAILABLE = True
except ImportError:
    PILLOW_AVAILABLE = False
    logger.debug("Pillow no disponible – screenshot streaming desactivado")


THUMBNAIL_WIDTH = 320
JPEG_QUALITY = 40


class ScreenshotStreamer:
    """Captura la pantalla periódicamente y envía thumbnails por WebSocket."""

    def __init__(self, actions=None):
        self._task: Optional[asyncio.Task] = None
        self._interval: float = 5.0
        self._quality: int = JPEG_QUALITY
        self._width: int = THUMBNAIL_WIDTH
        self._actions = actions

    def _find_x11_env(self, uid: int):
        import glob
        display = None
        xauth = None
        # Buscar en los procesos del usuario para extraer DISPLAY y XAUTHORITY reales
        for env_file in glob.glob("/proc/*/environ"):
            try:
                stat = os.stat(env_file)
                if stat.st_uid == uid:
                    with open(env_file, 'rb') as f:
                        env = f.read().split(b'\0')
                        d = None
                        xa = None
                        for e in env:
                            if e.startswith(b'DISPLAY='):
                                d = e.split(b'=', 1)[1].decode('utf-8', 'ignore')
                            elif e.startswith(b'XAUTHORITY='):
                                xa = e.split(b'=', 1)[1].decode('utf-8', 'ignore')
                        if d:
                            if not display or xa:
                                display = d
                                xauth = xa
                                if xauth:
                                    return display, xauth
            except Exception:
                pass
        return display, xauth

    @property
    def is_running(self) -> bool:
        return self._task is not None and not self._task.done()

    # ── captura ───────────────────────────────────────────────────────────

    def _capture_thumbnail(self) -> Optional[str]:
        """Capturar pantalla, redimensionar y devolver base64 JPEG.

        Se ejecuta en un hilo para no bloquear el event-loop.
        """
        if not MSS_AVAILABLE or not PILLOW_AVAILABLE:
            return None

        session = None
        if self._actions:
            session = self._actions._find_graphical_session()

        if session:
            display_kw = session.display
            xauth = session.xauthority
            if not xauth or not os.path.exists(xauth):
                proc_disp, proc_xauth = self._find_x11_env(session.uid)
                if proc_xauth and os.path.exists(proc_xauth):
                    xauth = proc_xauth
        else:
            # En la pantalla de login no hay sesión de usuario, pero el servidor
            # X del greeter sí está pintando: el mosaico debe mostrarlo igual,
            # que para eso se vigila un aula antes de que entre nadie.
            display_kw, xauth = find_x_display()
            if not display_kw:
                return None

        orig_display = os.environ.get("DISPLAY")
        orig_xauthority = os.environ.get("XAUTHORITY")
        os.environ["DISPLAY"] = display_kw

        # Recopilar todos los paths de XAUTHORITY posibles (brute-force)
        xauth_paths: list = []
        if xauth and os.path.exists(xauth):
            xauth_paths.append(xauth)

        # El -auth de los propios servidores X es la fuente más fiable
        for _, server_auth in find_x_servers():
            if server_auth and server_auth not in xauth_paths:
                xauth_paths.insert(0, server_auth)

        # Añadir candidatos comunes
        candidates = []
        if session:
            candidates += [
                f"/home/{session.user}/.Xauthority",
                f"/run/lightdm/{session.user}/xauthority",
                f"/run/user/{session.uid}/gdm/Xauthority",
                f"/run/user/{session.uid}/Xauthority",
            ]
        candidates += [
            "/var/run/lightdm/root/:0",
            "/var/run/lightdm/root/:1",
            "/run/lightdm/root/:0",
            "/run/lightdm/root/:1",
        ]
        candidates.extend(glob.glob("/tmp/xauth-*"))

        for cand in candidates:
            if cand not in xauth_paths and os.path.exists(cand):
                xauth_paths.append(cand)

        # Como último recurso, intentar sin XAUTHORITY (xhost +local:, etc.)
        xauth_paths.append(None)

        raw = None

        for auth_path in xauth_paths:
            if auth_path:
                os.environ["XAUTHORITY"] = auth_path
            else:
                os.environ.pop("XAUTHORITY", None)
            try:
                with mss.mss(display=display_kw) as sct:
                    monitor = sct.monitors[1] if len(sct.monitors) > 1 else sct.monitors[0]
                    raw = sct.grab(monitor)
                break
            except Exception:
                continue

        # Restaurar entorno original siempre
        if orig_display is not None:
            os.environ["DISPLAY"] = orig_display
        elif "DISPLAY" in os.environ:
            del os.environ["DISPLAY"]

        if orig_xauthority is not None:
            os.environ["XAUTHORITY"] = orig_xauthority
        elif "XAUTHORITY" in os.environ:
            del os.environ["XAUTHORITY"]

        if raw is None:
            logger.debug("No se pudo capturar screenshot para display %s", display_kw)
            return None

        try:
            img = Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")

            ratio = self._width / img.width
            new_height = int(img.height * ratio)
            img = img.resize((self._width, new_height), Image.LANCZOS)

            buffer = io.BytesIO()
            img.save(buffer, format="JPEG", quality=self._quality, optimize=True)
            buffer.seek(0)

            return base64.b64encode(buffer.read()).decode("ascii")

        except Exception as exc:
            logger.error("Error procesando screenshot: %s", exc)
            return None

    # ── loop asíncrono ────────────────────────────────────────────────────

    async def _stream_loop(self, send_fn):
        """Loop principal: captura → envía → espera."""
        logger.info(
            f"📸 Screenshot streamer iniciado "
            f"(intervalo={self._interval}s, quality={self._quality}, width={self._width})"
        )
        try:
            while True:
                data = await asyncio.to_thread(self._capture_thumbnail)
                if data:
                    await send_fn({
                        "type": "thumbnail_frame",
                        "data": data,
                    })
                await asyncio.sleep(self._interval)
        except asyncio.CancelledError:
            logger.info("📸 Screenshot streamer detenido")
        except Exception as exc:
            logger.error(f"Error en screenshot stream loop: {exc}")

    # ── API pública ───────────────────────────────────────────────────────

    def start(
        self,
        send_fn,
        interval: float = 5.0,
        quality: int = JPEG_QUALITY,
        width: int = THUMBNAIL_WIDTH,
    ):
        """Iniciar captura periódica.

        Args:
            send_fn: Coroutine que envía un dict por WebSocket (agent.send_json).
            interval: Segundos entre capturas.
            quality: Calidad JPEG (1-95).
            width: Ancho del thumbnail en píxeles.
        """
        if not MSS_AVAILABLE or not PILLOW_AVAILABLE:
            logger.warning("⚠️  mss/Pillow no disponibles, no se puede iniciar screenshot streaming")
            return

        if self.is_running:
            logger.debug("Screenshot streamer ya en ejecución, reiniciando…")
            self.stop()

        self._interval = max(interval, 1.0)  # Mínimo 1 segundo
        self._quality = min(max(int(quality), 1), 95)
        self._width = min(max(int(width), 160), 1920)
        self._task = asyncio.create_task(self._stream_loop(send_fn))

    def stop(self):
        """Detener captura."""
        if self._task and not self._task.done():
            self._task.cancel()
            self._task = None
            logger.info("📸 Screenshot streamer cancelado")

"""
vnc_manager.py — Gestión del servicio x11vnc para EduControl Agent.
"""

import logging
import os
import socket
import subprocess
import time

logger = logging.getLogger('EduControlAgent')


class VNCManager:
    """Gestor del servicio x11vnc."""

    def __init__(self, token: str, port: int = 5900):
        self.token = token
        self.port = port
        self.process = None
        self.passwd_file = '/tmp/.educontrol_vnc.pass'
        self.log_file = '/var/log/educontrol/x11vnc.log'

    # ── helpers ─────────────────────────────────────────────────────────────

    def _create_passwd_file(self) -> bool:
        """Crear archivo de password para x11vnc (primeros 8 chars del token)."""
        try:
            vnc_pass = self.token[:8] if self.token else "educontrol"
            cmd = ['x11vnc', '-storepasswd', vnc_pass, self.passwd_file]
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            os.chmod(self.passwd_file, 0o600)
            return True
        except Exception as e:
            logger.error(f"Error creando archivo password VNC: {e}")
            return False

    def _is_port_in_use(self, port: int) -> bool:
        """Comprobar si un puerto está en uso."""
        for host in ['127.0.0.1', '0.0.0.0']:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(0.5)
                    if s.connect_ex((host, port)) == 0:
                        return True
            except Exception:
                pass
        return False

    # ── ciclo de vida ────────────────────────────────────────────────────────

    def start(self) -> bool:
        """Iniciar servicio x11vnc."""
        if self.process and self.process.poll() is None:
            return True

        if subprocess.call(['which', 'x11vnc'], stdout=subprocess.DEVNULL) != 0:
            logger.warning("x11vnc no instalado. Instalando con apt...")
            subprocess.run(['apt-get', 'install', '-y', 'x11vnc'], stdout=subprocess.DEVNULL)

        if not self._create_passwd_file():
            return False

        # Asegurar directorio de logs
        log_dir = os.path.dirname(self.log_file)
        if not os.path.exists(log_dir):
            try:
                os.makedirs(log_dir, exist_ok=True)
            except Exception:
                self.log_file = f'/tmp/x11vnc_{self.port}.log'

        try:
            # Buscar puerto libre
            original_port = self.port
            max_attempts = 10
            port_found = False

            for i in range(max_attempts):
                check_port = original_port + i
                if not self._is_port_in_use(check_port):
                    self.port = check_port
                    port_found = True
                    break
                logger.debug(f"Puerto {check_port} ocupado, probando siguiente...")

            if not port_found:
                logger.error(f"❌ No se encontró puerto libre para VNC después de {max_attempts} intentos")
                return False

            cmd = [
                'x11vnc',
                '-display', ':0',
                '-auth', 'guess',
                '-forever',
                '-shared',
                '-rfbauth', self.passwd_file,
                '-rfbport', str(self.port),
                '-o', self.log_file,
                '-q',
            ]

            # Matar instancia previa que use nuestro passwd_file
            try:
                p = subprocess.run(['pgrep', '-f', self.passwd_file], capture_output=True, text=True)
                if p.stdout.strip():
                    for pid in p.stdout.strip().split('\n'):
                        logger.debug(f"Matando instancia previa de VNC (PID {pid})")
                        subprocess.run(['kill', '-9', pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass

            time.sleep(0.5)

            self.process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(1)

            if self.process.poll() is not None:
                logger.error(f"❌ El proceso x11vnc terminó inmediatamente (Puerto: {self.port})")
                return False

            logger.info(f"✅ Servicio VNC iniciado en puerto {self.port}")
            return True

        except Exception as e:
            logger.error(f"❌ Error iniciando VNC: {e}")
            return False

    def stop(self):
        """Detener servicio VNC."""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None

        try:
            p = subprocess.run(['pgrep', '-f', self.passwd_file], capture_output=True, text=True)
            if p.stdout.strip():
                for pid in p.stdout.strip().split('\n'):
                    subprocess.run(['kill', '-9', pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

        if os.path.exists(self.passwd_file):
            try:
                os.remove(self.passwd_file)
            except Exception:
                pass

        logger.info("🛑 Servicio VNC detenido")

    def is_running(self) -> bool:
        """Verificar si el proceso sigue vivo."""
        if self.process:
            if self.process.poll() is None:
                return True
            self.process = None
        return False

    def get_info(self) -> dict:
        """Obtener info de conexión para el servidor."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
        except Exception:
            ip = "127.0.0.1"

        return {
            "type": "vnc_info",
            "available": True,
            "ip": ip,
            "port": self.port,
            "password": self.token[:8] if self.token else "educontrol",
        }

"""
command_executor.py — Ejecución paralela de comandos para EduControl Agent.

Cada comando se ejecuta en su propio hilo del SO usando subprocess.Popen,
lo que permite verdadera ejecución en paralelo sin contención en el event
loop de asyncio.

Arquitectura de envíos al WebSocket
------------------------------------
Los hilos de ejecución NO llaman a websocket.send() directamente. En su
lugar depositan los mensajes en una asyncio.Queue y un worker coroutine
(``_send_worker``) los consume en orden y los envía de uno en uno al WS.

Ventajas:
  - Nunca hay dos websocket.send() simultáneos → sin ConcurrentError.
  - Los hilos no se bloquean esperando el envío → sin deadlocks por timeout.
  - El orden de los mensajes se preserva por dispositivo (FIFO de la queue).
"""

import asyncio
import json
import logging
import subprocess
import threading
import time
from typing import Optional

logger = logging.getLogger('EduControlAgent')

# Sentinela: indica al worker que debe terminar
_STOP_SENTINEL = object()


class CommandExecutor:
    """Ejecutor de comandos con ejecución en hilos paralelos y salida en streaming."""

    def __init__(self, websocket, agent_id: str):
        self.websocket = websocket
        self.agent_id = agent_id
        self.running_processes: dict = {}
        self._cancel_events: dict[str, threading.Event] = {}
        self._lock = threading.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        # Cola de mensajes hacia el WS. Los hilos depositan dicts aquí.
        self._send_queue: Optional[asyncio.Queue] = None
        # Tarea asyncio que drena la cola de forma serializada
        self._worker_task: Optional[asyncio.Task] = None

    # ── worker de envíos ──────────────────────────────────────────────────────

    async def _send_worker(self):
        """Coroutine que consume la cola y envía mensajes al WebSocket en serie.

        Al ser la única coroutine que llama a websocket.send(), garantiza que
        no habrá nunca dos envíos simultáneos (sin ConcurrentError).
        """
        while True:
            try:
                item = await self._send_queue.get()

                if item is _STOP_SENTINEL:
                    self._send_queue.task_done()
                    break

                if self.websocket and self.websocket.close_code is None:
                    try:
                        await self.websocket.send(json.dumps(item))
                    except Exception as e:
                        logger.warning(f"Error enviando mensaje WS: {e}")

                self._send_queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error en _send_worker: {e}")

    def _enqueue(self, data: dict):
        """Encola un mensaje para enviarlo al WS desde un hilo.

        No bloquea: deposita el mensaje y regresa inmediatamente.
        """
        if not self._loop or not self._send_queue:
            return
        try:
            # put_nowait es thread-safe vía call_soon_threadsafe
            self._loop.call_soon_threadsafe(self._send_queue.put_nowait, data)
        except Exception as e:
            logger.warning(f"No se pudo encolar mensaje WS: {e}")

    # ── ejecución ─────────────────────────────────────────────────────────────

    async def execute(self, command_id: str, command: str,
                      args: list = None, shell: bool = True, timeout: int = 300):
        """Lanza la ejecución del comando en un hilo dedicado.

        Retorna casi inmediatamente; el trabajo pesado corre en un Thread
        independiente, permitiendo ejecutar múltiples comandos en paralelo.
        """
        self._loop = asyncio.get_running_loop()

        # Inicializar cola y worker la primera vez
        if self._send_queue is None:
            self._send_queue = asyncio.Queue()
            self._worker_task = asyncio.create_task(self._send_worker())

        cancel_event = threading.Event()
        with self._lock:
            self._cancel_events[command_id] = cancel_event

        thread = threading.Thread(
            target=self._execute_in_thread,
            args=(command_id, command, args, shell, timeout, cancel_event),
            daemon=True,
            name=f"cmd-{command_id}",
        )
        thread.start()
        logger.info(
            f"Comando {command_id} lanzado en hilo paralelo "
            f"({threading.active_count()} hilos activos)"
        )

    def _execute_in_thread(self, command_id: str, command: str,
                           args: list, shell: bool, timeout: int,
                           cancel_event: threading.Event):
        """Ejecuta un comando de forma sincrónica en su propio hilo."""
        import queue as _queue

        POLL_INTERVAL = 0.5  # segundos entre comprobaciones

        logger.info(f"[Thread {command_id}] Ejecutando: {command}")
        start_time = time.time()

        try:
            if shell:
                process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    shell=True,
                )
            else:
                cmd_list = [command] + (args or [])
                process = subprocess.Popen(
                    cmd_list,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )

            with self._lock:
                self.running_processes[command_id] = process

            output_q: _queue.Queue = _queue.Queue()
            last_activity = [time.time()]

            def _read_stream(stream, stream_name):
                try:
                    for raw_line in iter(stream.readline, b''):
                        if not raw_line:
                            break
                        last_activity[0] = time.time()
                        line = raw_line.decode('utf-8', errors='replace').rstrip()
                        output_q.put((stream_name, line))
                except Exception as e:
                    logger.error(f"[{command_id}] Error leyendo {stream_name}: {e}")
                finally:
                    output_q.put((stream_name, None))

            t_out = threading.Thread(
                target=_read_stream, args=(process.stdout, 'stdout'), daemon=True,
            )
            t_err = threading.Thread(
                target=_read_stream, args=(process.stderr, 'stderr'), daemon=True,
            )
            t_out.start()
            t_err.start()

            streams_done = 0
            while streams_done < 2:
                if cancel_event.is_set():
                    logger.info(f"[Thread {command_id}] Cancelación detectada, finalizando hilo")
                    return

                try:
                    stream_name, line = output_q.get(timeout=POLL_INTERVAL)
                except _queue.Empty:
                    idle = time.time() - last_activity[0]
                    if idle >= timeout:
                        logger.warning(f"[{command_id}] Timeout por inactividad ({timeout}s)")
                        process.kill()
                        self._enqueue({
                            'type': 'command_error',
                            'command_id': command_id,
                            'error': f'Timeout por inactividad: sin output durante {timeout} segundos',
                        })
                        return
                    continue

                if line is None:
                    streams_done += 1
                    continue

                self._enqueue({
                    'type': 'command_output',
                    'command_id': command_id,
                    'output': line,
                    'stream': stream_name,
                })
                logger.debug(f"[{command_id}] {stream_name}: {line}")

            t_out.join(timeout=5)
            t_err.join(timeout=5)

            if cancel_event.is_set():
                logger.info(f"[Thread {command_id}] Cancelación detectada tras streams, finalizando hilo")
                return

            try:
                exit_code = process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
                exit_code = -1

            execution_time = time.time() - start_time

            self._enqueue({
                'type': 'command_complete',
                'command_id': command_id,
                'exit_code': exit_code,
                'execution_time': round(execution_time, 2),
            })
            logger.info(
                f"[Thread {command_id}] Completado con código {exit_code} "
                f"en {execution_time:.2f}s — mensaje command_complete encolado"
            )

        except Exception as e:
            if cancel_event.is_set():
                logger.info(f"[Thread {command_id}] Excepción post-cancelación ignorada: {e}")
                return
            logger.error(f"[Thread {command_id}] Error: {e}")
            self._enqueue({
                'type': 'command_error',
                'command_id': command_id,
                'error': str(e),
            })
        finally:
            with self._lock:
                self.running_processes.pop(command_id, None)
                self._cancel_events.pop(command_id, None)

    # ── cancelación ───────────────────────────────────────────────────────────

    async def cancel(self, command_id: str):
        """Cancela un comando en ejecución.

        1. Señaliza el cancel_event para que el hilo salga en ≤0.5s
        2. Mata el proceso (terminate → kill)
        3. Encola command_complete con cancelled=True
        """
        with self._lock:
            process = self.running_processes.get(command_id)
            cancel_event = self._cancel_events.get(command_id)

        if not process:
            logger.warning(f"Comando {command_id} no está en ejecución")
            self._enqueue({
                'type': 'command_error',
                'command_id': command_id,
                'error': 'El comando no está en ejecución o ya terminó',
            })
            return

        if cancel_event:
            cancel_event.set()

        try:
            process.terminate()
            loop = asyncio.get_running_loop()
            try:
                await asyncio.wait_for(
                    loop.run_in_executor(None, process.wait), timeout=2.0,
                )
                logger.info(f"Comando {command_id} terminado gracefully")
            except asyncio.TimeoutError:
                process.kill()
                await loop.run_in_executor(None, process.wait)
                logger.info(f"Comando {command_id} terminado forzosamente (kill)")

            self._enqueue({
                'type': 'command_complete',
                'command_id': command_id,
                'exit_code': -15,
                'execution_time': 0,
                'cancelled': True,
            })
            logger.info(f"Comando {command_id} cancelado exitosamente")

        except Exception as e:
            logger.error(f"Error cancelando comando {command_id}: {e}")
            self._enqueue({
                'type': 'command_error',
                'command_id': command_id,
                'error': f'Error cancelando comando: {str(e)}',
            })
        finally:
            with self._lock:
                self.running_processes.pop(command_id, None)
                self._cancel_events.pop(command_id, None)

    async def stop(self):
        """Detener el worker de envíos limpiamente."""
        if self._send_queue and self._worker_task:
            self._loop.call_soon_threadsafe(self._send_queue.put_nowait, _STOP_SENTINEL)
            try:
                await asyncio.wait_for(self._worker_task, timeout=5.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._worker_task.cancel()

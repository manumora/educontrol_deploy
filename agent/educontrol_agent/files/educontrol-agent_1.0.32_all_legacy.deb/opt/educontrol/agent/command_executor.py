"""
command_executor.py — Ejecución paralela de comandos para EduControl Agent.

Cada comando se ejecuta en su propio hilo del SO usando subprocess.Popen,
lo que permite verdadera ejecución en paralelo sin contención en el event
loop de asyncio. La comunicación con el websocket se hace de forma
thread-safe mediante asyncio.run_coroutine_threadsafe.
"""

import asyncio
import json
import logging
import subprocess
import threading
import time
from typing import Optional

logger = logging.getLogger('EduControlAgent')


class CommandExecutor:
    """Ejecutor de comandos con ejecución en hilos paralelos y salida en streaming."""

    def __init__(self, websocket, agent_id: str):
        self.websocket = websocket
        self.agent_id = agent_id
        self.running_processes: dict = {}
        self._cancel_events: dict[str, threading.Event] = {}
        self._lock = threading.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        # Lock asyncio para serializar envíos al WebSocket.
        # El protocolo WS no admite envíos concurrentes: si dos coroutines llaman a
        # websocket.send() de forma intercalada (en distintos await) se produce un
        # ConcurrentError silencioso que hace que el output de los comandos 2..N no
        # llegue al servidor y el backend los declare en timeout por inactividad.
        self._ws_lock: Optional[asyncio.Lock] = None

    # ── helpers ──────────────────────────────────────────────────────────────

    async def _locked_send(self, json_str: str):
        """Coroutine interna: adquiere el lock y envía al WebSocket."""
        async with self._ws_lock:
            await self.websocket.send(json_str)

    def _send_ws(self, data: dict):
        """Envío thread-safe al websocket a través del event loop.

        El lock garantiza que nunca haya dos websocket.send() simultáneos
        aunque varios hilos llamen a este método en paralelo.
        """
        if not self._loop or not self.websocket:
            return
        try:
            if self.websocket.close_code is not None:
                return
            future = asyncio.run_coroutine_threadsafe(
                self._locked_send(json.dumps(data)),
                self._loop,
            )
            future.result(timeout=10)
        except Exception as e:
            logger.warning(f"No se pudo enviar por websocket desde hilo: {e}")

    # ── ejecución ─────────────────────────────────────────────────────────────

    async def execute(self, command_id: str, command: str,
                      args: list = None, shell: bool = True, timeout: int = 300):
        """Lanza la ejecución del comando en un hilo dedicado.

        Retorna casi inmediatamente; el trabajo pesado corre en un Thread
        independiente, permitiendo ejecutar múltiples comandos en paralelo.
        """
        self._loop = asyncio.get_running_loop()
        # Crear el lock la primera vez (debe vivir en este event loop)
        if self._ws_lock is None:
            self._ws_lock = asyncio.Lock()

        cancel_event = threading.Event()
        with self._lock:
            self._cancel_events[command_id] = cancel_event
        thread = threading.Thread(
            target=self._execute_in_thread,
            args=(command_id, command, args, shell, timeout, cancel_event),
            daemon=True,
            name=f"cmd-{command_id}",
        )
        thread.start()
        logger.info(
            f"Comando {command_id} lanzado en hilo paralelo "
            f"({threading.active_count()} hilos activos)"
        )

    def _execute_in_thread(self, command_id: str, command: str,
                           args: list, shell: bool, timeout: int,
                           cancel_event: threading.Event):
        """Ejecuta un comando de forma sincrónica en su propio hilo."""
        import queue as _queue

        POLL_INTERVAL = 1  # segundos entre comprobaciones de cancelación

        logger.info(f"[Thread {command_id}] Ejecutando: {command}")
        start_time = time.time()

        try:
            if shell:
                process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    shell=True,
                )
            else:
                cmd_list = [command] + (args or [])
                process = subprocess.Popen(
                    cmd_list,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )

            with self._lock:
                self.running_processes[command_id] = process

            output_q: _queue.Queue = _queue.Queue()
            last_activity = [time.time()]

            def _read_stream(stream, stream_name):
                try:
                    for raw_line in iter(stream.readline, b''):
                        if not raw_line:
                            break
                        last_activity[0] = time.time()
                        line = raw_line.decode('utf-8', errors='replace').rstrip()
                        output_q.put((stream_name, line))
                except Exception as e:
                    logger.error(f"[{command_id}] Error leyendo {stream_name}: {e}")
                finally:
                    output_q.put((stream_name, None))

            t_out = threading.Thread(
                target=_read_stream, args=(process.stdout, 'stdout'), daemon=True,
            )
            t_err = threading.Thread(
                target=_read_stream, args=(process.stderr, 'stderr'), daemon=True,
            )
            t_out.start()
            t_err.start()

            streams_done = 0
            while streams_done < 2:
                if cancel_event.is_set():
                    logger.info(f"[Thread {command_id}] Cancelación detectada, finalizando hilo")
                    return

                try:
                    stream_name, line = output_q.get(timeout=POLL_INTERVAL)
                except _queue.Empty:
                    idle = time.time() - last_activity[0]
                    if idle >= timeout:
                        logger.warning(f"[{command_id}] Timeout por inactividad ({timeout}s)")
                        process.kill()
                        self._send_ws({
                            'type': 'command_error',
                            'command_id': command_id,
                            'error': f'Timeout por inactividad: sin output durante {timeout} segundos',
                        })
                        return
                    continue

                if line is None:
                    streams_done += 1
                    continue

                self._send_ws({
                    'type': 'command_output',
                    'command_id': command_id,
                    'output': line,
                    'stream': stream_name,
                })
                logger.debug(f"[{command_id}] {stream_name}: {line}")

            t_out.join(timeout=5)
            t_err.join(timeout=5)

            if cancel_event.is_set():
                logger.info(f"[Thread {command_id}] Cancelación detectada tras streams, finalizando hilo")
                return

            try:
                exit_code = process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
                exit_code = -1

            execution_time = time.time() - start_time

            self._send_ws({
                'type': 'command_complete',
                'command_id': command_id,
                'exit_code': exit_code,
                'execution_time': round(execution_time, 2),
            })
            logger.info(
                f"[Thread {command_id}] Completado con código {exit_code} "
                f"en {execution_time:.2f}s"
            )

        except Exception as e:
            if cancel_event.is_set():
                logger.info(f"[Thread {command_id}] Excepción post-cancelación ignorada: {e}")
                return
            logger.error(f"[Thread {command_id}] Error: {e}")
            self._send_ws({
                'type': 'command_error',
                'command_id': command_id,
                'error': str(e),
            })
        finally:
            with self._lock:
                self.running_processes.pop(command_id, None)
                self._cancel_events.pop(command_id, None)

    # ── cancelación ───────────────────────────────────────────────────────────

    async def cancel(self, command_id: str):
        """Cancela un comando en ejecución.

        1. Señaliza el cancel_event para que el hilo salga en ≤1s
        2. Mata el proceso (terminate → kill)
        3. Envía command_complete con cancelled=True
        """
        with self._lock:
            process = self.running_processes.get(command_id)
            cancel_event = self._cancel_events.get(command_id)

        if not process:
            logger.warning(f"Comando {command_id} no está en ejecución")
            if self.websocket and self.websocket.close_code is None:
                try:
                    await self.websocket.send(json.dumps({
                        'type': 'command_error',
                        'command_id': command_id,
                        'error': 'El comando no está en ejecución o ya terminó',
                    }))
                except Exception:
                    pass
            return

        if cancel_event:
            cancel_event.set()

        try:
            process.terminate()
            loop = asyncio.get_running_loop()
            try:
                await asyncio.wait_for(
                    loop.run_in_executor(None, process.wait), timeout=2.0,
                )
                logger.info(f"Comando {command_id} terminado gracefully")
            except asyncio.TimeoutError:
                process.kill()
                await loop.run_in_executor(None, process.wait)
                logger.info(f"Comando {command_id} terminado forzosamente (kill)")

            if self.websocket and self.websocket.close_code is None:
                try:
                    await self.websocket.send(json.dumps({
                        'type': 'command_complete',
                        'command_id': command_id,
                        'exit_code': -15,
                        'execution_time': 0,
                        'cancelled': True,
                    }))
                except Exception:
                    pass

            logger.info(f"Comando {command_id} cancelado exitosamente")

        except Exception as e:
            logger.error(f"Error cancelando comando {command_id}: {e}")
            if self.websocket and self.websocket.close_code is None:
                try:
                    await self.websocket.send(json.dumps({
                        'type': 'command_error',
                        'command_id': command_id,
                        'error': f'Error cancelando comando: {str(e)}',
                    }))
                except Exception:
                    pass
        finally:
            with self._lock:
                self.running_processes.pop(command_id, None)
                self._cancel_events.pop(command_id, None)

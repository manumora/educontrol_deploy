"""
command_executor.py — Ejecución paralela de comandos para EduControl Agent.

Cada comando se ejecuta en su propio hilo del SO usando subprocess.Popen,
lo que permite verdadera ejecución en paralelo sin contención en el event
loop de asyncio.

Arquitectura de envíos al WebSocket
------------------------------------
Los hilos de ejecución NO llaman a websocket.send() directamente. En su
lugar depositan los mensajes en una asyncio.Queue y un worker coroutine
(``_send_worker``) los consume en orden y los envía de uno en uno al WS.

Buffering de output
-------------------
Por defecto, stdout/stderr se almacenan localmente en memoria y se envían
completos junto al mensaje ``command_complete``.  Esto evita que un comando
con mucho output sature la cola y bloquee señales de completación de otros
comandos que corren en paralelo.

El streaming línea a línea se activa bajo demanda
(``enable_streaming(command_id)``) cuando el usuario abre la vista de
ejecución en el frontend.  Al activarse, se envía primero el output
acumulado hasta ese momento (catch-up) y luego cada línea nueva en tiempo
real.
"""

import asyncio
import json
import logging
import subprocess
import threading
import time
from typing import Optional

logger = logging.getLogger('EduControlAgent')

_STOP_SENTINEL = object()

_PRIO_CONTROL = 0   # command_complete, command_error
_PRIO_OUTPUT = 10    # command_output


class CommandExecutor:
    """Ejecutor de comandos con ejecución en hilos paralelos y salida en streaming."""

    def __init__(self, websocket, agent_id: str):
        self.websocket = websocket
        self.agent_id = agent_id
        self.running_processes: dict = {}
        self._cancel_events: dict[str, threading.Event] = {}
        self._lock = threading.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._send_queue: Optional[asyncio.PriorityQueue] = None
        self._worker_task: Optional[asyncio.Task] = None
        self._seq = 0
        self._seq_lock = threading.Lock()

        # Streaming on-demand: solo los command_ids aquí envían output línea a línea
        self._streaming_commands: set[str] = set()

        # Buffers de output por comando (acceso protegido por _lock)
        # {command_id: {'stdout': [líneas], 'stderr': [líneas]}}
        self._output_buffers: dict[str, dict[str, list[str]]] = {}

    # ── worker de envíos ──────────────────────────────────────────────────────

    async def _send_worker(self):
        """Coroutine que consume la cola y envía mensajes al WebSocket en serie."""
        while True:
            try:
                prio, seq, item = await self._send_queue.get()

                if item is _STOP_SENTINEL:
                    self._send_queue.task_done()
                    break

                if self.websocket and self.websocket.close_code is None:
                    try:
                        await self.websocket.send(json.dumps(item))
                    except Exception as e:
                        logger.warning(f"Error enviando mensaje WS: {e}")

                self._send_queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error en _send_worker: {e}")

    def _next_seq(self) -> int:
        with self._seq_lock:
            self._seq += 1
            return self._seq

    def _enqueue(self, data: dict, priority: int = _PRIO_OUTPUT):
        """Encola un mensaje para enviarlo al WS desde un hilo."""
        if not self._loop or not self._send_queue:
            return
        try:
            seq = self._next_seq()
            self._loop.call_soon_threadsafe(
                self._send_queue.put_nowait, (priority, seq, data)
            )
        except Exception as e:
            logger.warning(f"No se pudo encolar mensaje WS: {e}")

    # ── streaming on-demand ───────────────────────────────────────────────────

    STREAM_BATCH_SIZE = 50

    def _send_lines_batched(self, command_id: str, stream: str, lines: list[str]):
        """Envía líneas al backend en bloques de STREAM_BATCH_SIZE."""
        bs = self.STREAM_BATCH_SIZE
        for i in range(0, len(lines), bs):
            chunk = lines[i:i + bs]
            self._enqueue({
                'type': 'command_output',
                'command_id': command_id,
                'output': '\n'.join(chunk),
                'stream': stream,
            })

    def enable_streaming(self, command_id: str):
        """Activa streaming por bloques para un comando en ejecución.

        Envía primero todo el output acumulado (catch-up) en bloques y
        luego cada bloque nuevo llegará en tiempo real.
        """
        with self._lock:
            if command_id not in self.running_processes:
                logger.debug(f"enable_streaming: {command_id} no está en ejecución, ignorando")
                return

            self._streaming_commands.add(command_id)
            buf = self._output_buffers.get(command_id, {})
            stdout_lines = list(buf.get('stdout', []))
            stderr_lines = list(buf.get('stderr', []))

        self._send_lines_batched(command_id, 'stdout', stdout_lines)
        self._send_lines_batched(command_id, 'stderr', stderr_lines)

        logger.info(
            f"Streaming activado para {command_id} "
            f"(catch-up: {len(stdout_lines)} stdout, {len(stderr_lines)} stderr)"
        )

    def disable_streaming(self, command_id: str):
        """Desactiva el streaming para un comando."""
        self._streaming_commands.discard(command_id)
        logger.debug(f"Streaming desactivado para {command_id}")

    # ── ejecución ─────────────────────────────────────────────────────────────

    async def execute(self, command_id: str, command: str,
                      args: list = None, shell: bool = True, timeout: int = 300):
        """Lanza la ejecución del comando en un hilo dedicado."""
        self._loop = asyncio.get_running_loop()

        if self._send_queue is None:
            self._send_queue = asyncio.PriorityQueue()
            self._worker_task = asyncio.create_task(self._send_worker())

        cancel_event = threading.Event()
        with self._lock:
            self._cancel_events[command_id] = cancel_event
            self._output_buffers[command_id] = {'stdout': [], 'stderr': []}

        thread = threading.Thread(
            target=self._execute_in_thread,
            args=(command_id, command, args, shell, timeout, cancel_event),
            daemon=True,
            name=f"cmd-{command_id}",
        )
        thread.start()
        logger.info(
            f"Comando {command_id} lanzado en hilo paralelo "
            f"({threading.active_count()} hilos activos)"
        )

    def _execute_in_thread(self, command_id: str, command: str,
                           args: list, shell: bool, timeout: int,
                           cancel_event: threading.Event):
        """Ejecuta un comando de forma sincrónica en su propio hilo."""
        import queue as _queue

        POLL_INTERVAL = 0.5

        logger.info(f"[Thread {command_id}] Ejecutando: {command}")
        start_time = time.time()

        try:
            if shell:
                process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    shell=True,
                )
            else:
                cmd_list = [command] + (args or [])
                process = subprocess.Popen(
                    cmd_list,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )

            with self._lock:
                self.running_processes[command_id] = process

            output_q: _queue.Queue = _queue.Queue()
            last_activity = [time.time()]

            def _read_stream(stream, stream_name):
                try:
                    for raw_line in iter(stream.readline, b''):
                        if not raw_line:
                            break
                        last_activity[0] = time.time()
                        line = raw_line.decode('utf-8', errors='replace').rstrip()
                        output_q.put((stream_name, line))
                except Exception as e:
                    logger.error(f"[{command_id}] Error leyendo {stream_name}: {e}")
                finally:
                    output_q.put((stream_name, None))

            t_out = threading.Thread(
                target=_read_stream, args=(process.stdout, 'stdout'), daemon=True,
            )
            t_err = threading.Thread(
                target=_read_stream, args=(process.stderr, 'stderr'), daemon=True,
            )
            t_out.start()
            t_err.start()

            HEARTBEAT_INTERVAL = 10
            last_heartbeat = time.time()
            is_task = command_id.startswith('task_')

            # Batches de streaming: acumular líneas antes de enviar
            stream_batch: dict[str, list[str]] = {'stdout': [], 'stderr': []}

            def _flush_stream_batch(force: bool = False):
                """Enviar batches acumulados si alcanzan el tamaño o si force=True."""
                for sname in ('stdout', 'stderr'):
                    lines = stream_batch[sname]
                    if not lines:
                        continue
                    if force or len(lines) >= self.STREAM_BATCH_SIZE:
                        self._enqueue({
                            'type': 'command_output',
                            'command_id': command_id,
                            'output': '\n'.join(lines),
                            'stream': sname,
                        })
                        stream_batch[sname] = []

            streams_done = 0
            while streams_done < 2:
                if cancel_event.is_set():
                    logger.info(f"[Thread {command_id}] Cancelación detectada, finalizando hilo")
                    return

                try:
                    stream_name, line = output_q.get(timeout=POLL_INTERVAL)
                except _queue.Empty:
                    idle = time.time() - last_activity[0]
                    if idle >= timeout:
                        logger.warning(f"[{command_id}] Timeout por inactividad ({timeout}s)")
                        process.kill()
                        self._enqueue({
                            'type': 'command_error',
                            'command_id': command_id,
                            'error': f'Timeout por inactividad: sin output durante {timeout} segundos',
                        }, priority=_PRIO_CONTROL)
                        return

                    now = time.time()
                    if is_task and (now - last_heartbeat) >= HEARTBEAT_INTERVAL:
                        self._enqueue({
                            'type': 'command_activity',
                            'command_id': command_id,
                        }, priority=_PRIO_CONTROL)
                        last_heartbeat = now

                    # Flush parcial de streaming en pausa de output
                    if command_id in self._streaming_commands:
                        _flush_stream_batch(force=True)

                    continue

                if line is None:
                    streams_done += 1
                    continue

                with self._lock:
                    buf = self._output_buffers.get(command_id)
                    if buf is not None:
                        buf[stream_name].append(line)

                if command_id in self._streaming_commands:
                    stream_batch[stream_name].append(line)
                    _flush_stream_batch()

                if is_task:
                    now = time.time()
                    if (now - last_heartbeat) >= HEARTBEAT_INTERVAL:
                        self._enqueue({
                            'type': 'command_activity',
                            'command_id': command_id,
                        }, priority=_PRIO_CONTROL)
                        last_heartbeat = now

                logger.debug(f"[{command_id}] {stream_name}: {line}")

            # Flush final de cualquier batch pendiente
            if command_id in self._streaming_commands:
                _flush_stream_batch(force=True)

            t_out.join(timeout=5)
            t_err.join(timeout=5)

            if cancel_event.is_set():
                logger.info(f"[Thread {command_id}] Cancelación detectada tras streams, finalizando hilo")
                return

            try:
                exit_code = process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
                exit_code = -1

            execution_time = time.time() - start_time

            # Obtener output completo del buffer
            with self._lock:
                buf = self._output_buffers.get(command_id, {})
                full_stdout = '\n'.join(buf.get('stdout', []))
                full_stderr = '\n'.join(buf.get('stderr', []))

            self._enqueue({
                'type': 'command_complete',
                'command_id': command_id,
                'exit_code': exit_code,
                'execution_time': round(execution_time, 2),
                'stdout': full_stdout,
                'stderr': full_stderr,
            }, priority=_PRIO_CONTROL)
            logger.info(
                f"[Thread {command_id}] Completado con código {exit_code} "
                f"en {execution_time:.2f}s"
            )

        except Exception as e:
            if cancel_event.is_set():
                logger.info(f"[Thread {command_id}] Excepción post-cancelación ignorada: {e}")
                return
            logger.error(f"[Thread {command_id}] Error: {e}")
            self._enqueue({
                'type': 'command_error',
                'command_id': command_id,
                'error': str(e),
            }, priority=_PRIO_CONTROL)
        finally:
            with self._lock:
                self.running_processes.pop(command_id, None)
                self._cancel_events.pop(command_id, None)
                self._output_buffers.pop(command_id, None)
            self._streaming_commands.discard(command_id)

    # ── cancelación ───────────────────────────────────────────────────────────

    async def cancel(self, command_id: str):
        """Cancela un comando en ejecución."""
        with self._lock:
            process = self.running_processes.get(command_id)
            cancel_event = self._cancel_events.get(command_id)

        if not process:
            logger.warning(f"Comando {command_id} no está en ejecución")
            self._enqueue({
                'type': 'command_error',
                'command_id': command_id,
                'error': 'El comando no está en ejecución o ya terminó',
            }, priority=_PRIO_CONTROL)
            return

        if cancel_event:
            cancel_event.set()

        try:
            process.terminate()
            loop = asyncio.get_running_loop()
            try:
                await asyncio.wait_for(
                    loop.run_in_executor(None, process.wait), timeout=2.0,
                )
                logger.info(f"Comando {command_id} terminado gracefully")
            except asyncio.TimeoutError:
                process.kill()
                await loop.run_in_executor(None, process.wait)
                logger.info(f"Comando {command_id} terminado forzosamente (kill)")

            self._enqueue({
                'type': 'command_complete',
                'command_id': command_id,
                'exit_code': -15,
                'execution_time': 0,
                'cancelled': True,
            }, priority=_PRIO_CONTROL)
            logger.info(f"Comando {command_id} cancelado exitosamente")

        except Exception as e:
            logger.error(f"Error cancelando comando {command_id}: {e}")
            self._enqueue({
                'type': 'command_error',
                'command_id': command_id,
                'error': f'Error cancelando comando: {str(e)}',
            }, priority=_PRIO_CONTROL)
        finally:
            with self._lock:
                self.running_processes.pop(command_id, None)
                self._cancel_events.pop(command_id, None)
                self._output_buffers.pop(command_id, None)
            self._streaming_commands.discard(command_id)

    async def stop(self):
        """Detener el worker de envíos limpiamente."""
        if self._send_queue and self._worker_task:
            self._loop.call_soon_threadsafe(
                self._send_queue.put_nowait, (-1, 0, _STOP_SENTINEL)
            )
            try:
                await asyncio.wait_for(self._worker_task, timeout=5.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._worker_task.cancel()

"""
logging_setup.py — Configuración de logging para EduControl Agent.
"""

import logging
import os
from logging.handlers import RotatingFileHandler


def get_log_path() -> str:
    """Determinar ruta de logs según el entorno."""
    system_log_dir = '/var/log/educontrol'
    if os.path.exists(system_log_dir) and os.access(system_log_dir, os.W_OK):
        return os.path.join(system_log_dir, 'agent.log')
    return 'agent.log'


def setup_logging(level: int = logging.INFO) -> logging.Logger:
    """Configurar logging con rotación automática.

    Retorna el logger raíz del agente.
    """
    log_file = get_log_path()

    log_handler = RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=5,
        encoding='utf-8',
    )
    log_handler.setFormatter(
        logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    )

    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            log_handler,
        ],
    )

    logger = logging.getLogger('EduControlAgent')
    logger.info(f"📝 Logs guardándose en: {log_file}")
    return logger

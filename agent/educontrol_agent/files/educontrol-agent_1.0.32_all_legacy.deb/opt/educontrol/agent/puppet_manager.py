"""
puppet_manager.py — Gestión y recuperación del agente Puppet para EduControl Agent.
"""

import logging
import os
import platform
import socket
import subprocess
import time
from typing import Optional

logger = logging.getLogger('EduControlAgent')

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


class PuppetManager:
    """Encapsula toda la lógica de detección/recuperación de Puppet."""

    def __init__(self, config):
        """
        Args:
            config: instancia de AgentConfig con http_url, token, hostname,
                    agent_id, verify_ssl y puppet_check_enabled.
        """
        self.config = config

    # ── helpers privados ─────────────────────────────────────────────────────

    def _get_puppet_certname(self) -> str:
        """Intenta obtener el certname exacto de Puppet."""
        puppet_certname = None

        conf_paths = ['/etc/puppet/puppet.conf', '/etc/puppetlabs/puppet/puppet.conf']
        for cp in conf_paths:
            if not puppet_certname and os.path.exists(cp):
                try:
                    with open(cp, 'r') as f:
                        for line in f:
                            if line.strip().startswith('certname'):
                                parts = line.split('=')
                                if len(parts) > 1:
                                    puppet_certname = parts[1].strip()
                                    break
                except Exception as e:
                    logger.debug(f"Error leyendo {cp}: {e}")

        if not puppet_certname:
            try:
                res = subprocess.run(
                    ['puppet', 'config', 'print', 'certname'],
                    capture_output=True, text=True, timeout=5,
                )
                if res.returncode == 0:
                    puppet_certname = res.stdout.strip()
            except Exception:
                pass

        if not puppet_certname:
            cert_dirs = ['/var/lib/puppet/ssl/certs', '/etc/puppetlabs/puppet/ssl/certs']
            for cd in cert_dirs:
                if not puppet_certname and os.path.exists(cd):
                    try:
                        for f in os.listdir(cd):
                            if f.endswith('.pem') and f != 'ca.pem':
                                puppet_certname = f[:-4]
                                break
                    except Exception:
                        pass

        if not puppet_certname:
            puppet_certname = socket.getfqdn()

        if not puppet_certname or puppet_certname == 'localhost':
            puppet_certname = self.config.hostname

        return puppet_certname

    def _update_trusted_certs(self) -> bool:
        """Sincroniza CA y CRL directamente desde el servidor puppet vía HTTPS."""
        try:
            puppet_server = "puppetinstituto"
            res = subprocess.run(
                ['puppet', 'config', 'print', 'server'], capture_output=True, text=True, timeout=5
            )
            if res.returncode == 0 and res.stdout.strip():
                puppet_server = res.stdout.strip()

            cert_dir = "/etc/puppetlabs/puppet/ssl/certs"
            crl_file = "/etc/puppetlabs/puppet/ssl/crl.pem"

            if not os.path.exists("/etc/puppetlabs/puppet") and os.path.exists("/var/lib/puppet/ssl"):
                cert_dir = "/var/lib/puppet/ssl/certs"
                crl_file = "/var/lib/puppet/ssl/crl.pem"

            os.makedirs(cert_dir, exist_ok=True, mode=0o755)

            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            ca_url = f"https://{puppet_server}:8140/puppet-ca/v1/certificate/ca"
            crl_url = f"https://{puppet_server}:8140/puppet-ca/v1/certificate_revocation_list/ca"

            r_ca = requests.get(ca_url, verify=False, timeout=10)
            if r_ca.status_code == 200:
                with open(os.path.join(cert_dir, "ca.pem"), 'w') as f:
                    f.write(r_ca.text)

            r_crl = requests.get(crl_url, verify=False, timeout=10)
            if r_crl.status_code == 200:
                with open(crl_file, 'w') as f:
                    f.write(r_crl.text)

            os.chmod(os.path.join(cert_dir, "ca.pem"), 0o644)
            os.chmod(crl_file, 0o644)
            logger.info(f"✅ CA/CRL sincronizadas desde {puppet_server}")
            return True
        except Exception as e:
            logger.warning(f"Error sincronizando CA/CRL: {e}")
            return False

    def _validate_rsa_keypair(self, certname: str) -> bool:
        """Verifica usando OpenSSL si el modulus del cert y la clave coinciden."""
        cert_file = f"/etc/puppetlabs/puppet/ssl/certs/{certname}.pem"
        key_file = f"/etc/puppetlabs/puppet/ssl/private_keys/{certname}.pem"

        if not os.path.exists(cert_file):
            cert_file = f"/var/lib/puppet/ssl/certs/{certname}.pem"
            key_file = f"/var/lib/puppet/ssl/private_keys/{certname}.pem"

        if not os.path.exists(cert_file) or not os.path.exists(key_file):
            return False

        try:
            res_cert = subprocess.run(
                ['openssl', 'x509', '-noout', '-modulus', '-in', cert_file],
                capture_output=True, text=True, timeout=5,
            )
            res_key = subprocess.run(
                ['openssl', 'rsa', '-noout', '-modulus', '-in', key_file],
                capture_output=True, text=True, timeout=5,
            )
            if res_cert.returncode == 0 and res_key.returncode == 0:
                mod_cert = res_cert.stdout.strip()
                mod_key = res_key.stdout.strip()
                if mod_cert and mod_key and mod_cert == mod_key:
                    return True
        except Exception as e:
            logger.debug(f"Error verificando OpenSSL modulus: {e}")
        return False

    def _purge_corrupted_security_data(self):
        """Limpieza defensiva completa del directorio SSL de puppet."""
        subprocess.run(['systemctl', 'stop', 'puppet'], check=False)
        subprocess.run(['puppet', 'ssl', 'clean'], check=False)
        for ssl_path in ['/var/lib/puppet/ssl', '/etc/puppetlabs/puppet/ssl']:
            if os.path.exists(ssl_path):
                subprocess.run(['rm', '-rf', ssl_path], check=False)
                logger.info(f"🗑️ Directorio {ssl_path} purgado.")

    def _request_master_certificate_revocation(self, certname: str) -> bool:
        """Notifica al backend para ejecutar `puppetserver ca clean --certname`."""
        mac = self._get_mac_address()

        notify_url = f"{self.config.http_url}/api/hosts/agent/puppet-stuck/"
        headers = {'Content-Type': 'application/json'}
        if self.config.token:
            headers['Authorization'] = f'Token {self.config.token}'

        logger.info(f"📤 Notificando al master (vía backend) limpieza de '{certname}'...")
        try:
            response = requests.post(
                notify_url,
                json={
                    'mac': mac,
                    'hostname': self.config.hostname,
                    'certname': certname,
                    'agent_id': self.config.agent_id,
                    'ip_address': self._get_ip_address(),
                },
                headers=headers,
                timeout=10,
                verify=self.config.verify_ssl,
            )
            if response.status_code == 200:
                logger.info("✅ Petición de limpieza aceptada.")
                return True
            else:
                logger.error(f"❌ Error API limpieza (HTTP {response.status_code}): {response.text}")
        except Exception as e:
            logger.error(f"❌ Error conectando para limpieza: {e}")
        return False

    def _test_puppet_connection(self) -> Optional[bool]:
        """Verifica si el agente puede hacer handshake SSL válido con el servidor Puppet.

        Returns:
            True  → conexión exitosa
            False → fallo SSL
            None  → no se pudo conectar (red/servidor caído)
        """
        import ssl

        try:
            puppet_server = subprocess.run(
                ['puppet', 'config', 'print', 'server'],
                capture_output=True, text=True, check=True,
            ).stdout.strip()

            puppet_certname = self._get_puppet_certname()

            cert_file = f"/etc/puppetlabs/puppet/ssl/certs/{puppet_certname}.pem"
            key_file = f"/etc/puppetlabs/puppet/ssl/private_keys/{puppet_certname}.pem"
            ca_file = "/etc/puppetlabs/puppet/ssl/certs/ca.pem"

            if not os.path.exists(cert_file):
                cert_file = f"/var/lib/puppet/ssl/certs/{puppet_certname}.pem"
                key_file = f"/var/lib/puppet/ssl/private_keys/{puppet_certname}.pem"
                ca_file = "/var/lib/puppet/ssl/certs/ca.pem"

            if not (os.path.exists(cert_file) and os.path.exists(key_file) and os.path.exists(ca_file)):
                return False

            context = ssl.create_default_context(cafile=ca_file)
            context.load_cert_chain(certfile=cert_file, keyfile=key_file)

            with socket.create_connection((puppet_server, 8140), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=puppet_server):
                    return True

        except ssl.SSLError as e:
            logger.warning(f"Test handshake SSL contra master falló: {e}")
            return False
        except Exception as e:
            logger.debug(f"Test handshake de red falló (master quizás apagado): {e}")
            return None

    def _get_ip_address(self) -> str:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect((self.config.host, 80))
                return s.getsockname()[0]
        except Exception:
            return "unknown"

    def _get_mac_address(self) -> Optional[str]:
        """Obtener MAC address principal del sistema (delegado a RemoteAgent en el original;
        aquí usamos una implementación autónoma)."""
        try:
            import psutil as _psutil
            network_interfaces = _psutil.net_if_addrs()
            wired_patterns = ['eno', 'ens', 'enp', 'eth', 'enx', 'ethernet']

            for pattern in wired_patterns:
                for iface, addrs in sorted(network_interfaces.items()):
                    if iface.lower().startswith(pattern):
                        for addr in addrs:
                            if addr.family == _psutil.AF_LINK:
                                mac = addr.address.upper()
                                if mac and mac != '00:00:00:00:00:00':
                                    return mac
        except Exception:
            pass
        return None

    # ── comprobación principal ────────────────────────────────────────────────

    async def check_puppet_stuck(self):
        """Verificar si puppet agent está atascado por problemas de certificado y repararlo."""
        if platform.system() != 'Linux':
            return
        if not REQUESTS_AVAILABLE:
            return
        if not self.config.puppet_check_enabled:
            return

        try:
            logger.info("🔍 Verificando estado del SSL del agente puppet...")
            ssl_error_patterns = [
                'certificate verify failed', 'certificate revoked',
                'does not match its private key',
            ]
            stuck = False

            # 1. Chequeo por logs
            log_paths = ['/var/log/puppetlabs/puppet/puppet.log', '/var/log/puppet/puppet.log']
            for path in log_paths:
                if os.path.exists(path):
                    result = subprocess.run(
                        ['tail', '-n', '100', path], capture_output=True, text=True, check=False,
                    )
                    if result.returncode == 0:
                        output = result.stdout.lower()
                        if any(p in output for p in ssl_error_patterns):
                            stuck = True
                            logger.warning(f"⚠️ Detectado error de certificado en {path}")
                            break

            if not stuck and os.path.exists('/bin/journalctl'):
                result = subprocess.run(
                    ['journalctl', '-u', 'puppet', '-n', '50', '--no-pager'],
                    capture_output=True, text=True, check=False,
                )
                if result.returncode == 0 and any(p in result.stdout.lower() for p in ssl_error_patterns):
                    stuck = True
                    logger.warning("⚠️ Detectado error de certificado en journalctl")

            # 2. OpenSSL modulus check
            puppet_certname = self._get_puppet_certname()
            cert_exists = (
                os.path.exists(f"/etc/puppetlabs/puppet/ssl/certs/{puppet_certname}.pem")
                or os.path.exists(f"/var/lib/puppet/ssl/certs/{puppet_certname}.pem")
            )

            openssl_mismatch = False
            if cert_exists and not self._validate_rsa_keypair(puppet_certname):
                logger.warning("⚠️ Mismatch detectado por OpenSSL (Certificado vs Clave Privada)!")
                stuck = True
                openssl_mismatch = True

            if stuck and not openssl_mismatch:
                tls_result = self._test_puppet_connection()
                if tls_result is True:
                    logger.info(
                        "ℹ️ Los logs indican error de certificado, pero el handshake TLS actual fue exitoso. "
                        "Ignorando falso positivo de logs antiguos."
                    )
                    stuck = False
                elif tls_result is None:
                    logger.info(
                        "ℹ️ No se pudo conectar al master puppet (red/servidor caído). "
                        "No se puede confirmar si el error de logs es actual."
                    )
                    stuck = False

            if stuck:
                logger.info("🛠️ Ejecutando rutina de recuperación avanzada de SSL de Puppet...")

                self._update_trusted_certs()
                api_success = self._request_master_certificate_revocation(puppet_certname)
                if not api_success:
                    logger.error(
                        "❌ Abortando recuperación: El servidor de EduControl no pudo limpiar el certificado "
                        "en el master. Reintentando en el próximo ciclo."
                    )
                    return

                logger.info("⏳ Esperando 5 segundos a que el servidor principal complete el borrado...")
                time.sleep(5)

                self._purge_corrupted_security_data()

                for intento in range(1, 4):
                    logger.info(f"⏳ Generando nueva clave y solicitando firma (Intento {intento}/3)")
                    res = subprocess.run(['puppet', 'ssl', 'submit_request'], capture_output=True, text=True)
                    out = (res.stdout + res.stderr).lower()

                    if 'conflict on the server' in out:
                        logger.warning("⚠️ Conflicto reportado por el servidor CA.")
                        retry_success = self._request_master_certificate_revocation(puppet_certname)
                        if not retry_success:
                            logger.error("❌ Abortando reintento.")
                            return
                        self._purge_corrupted_security_data()
                        logger.info("⏳ Esperando 8 segundos extra para el borrado asíncrono...")
                        time.sleep(8)
                        continue
                    else:
                        break

                cert_downloaded = False
                for dl_intento in range(1, 4):
                    time.sleep(3)
                    subprocess.run(['puppet', 'ssl', 'download_cert'], capture_output=True, text=True)
                    if self._validate_rsa_keypair(puppet_certname):
                        logger.info(f"✅ Certificado descargado y verificado OpenSSL en intento {dl_intento}.")
                        cert_downloaded = True
                        break
                    logger.info(f"🔄 Cert aún no disponible, reintentando ({dl_intento}/3)...")

                if not cert_downloaded:
                    logger.warning("⚠️ El certificado no fue firmado automáticamente. `puppet agent -t` lo intentará al final.")

                logger.info("🔄 Ejecutando puppet agent...")
                subprocess.run(['puppet', 'agent', '-t'], check=False)
            else:
                logger.info("✅ SSL de Puppet verificado y funcionando correctamente.")

        except Exception as e:
            logger.error(f"❌ Error en rutina recuperadora: {e}")

"""
terminal_handler.py — Terminal interactivo con PTY para EduControl Agent.
"""

import asyncio
import json
import logging
import os
import platform
import subprocess

logger = logging.getLogger('EduControlAgent')


class TerminalHandler:
    """Manejador de terminal interactivo con PTY."""

    def __init__(self, websocket, agent_id: str, terminal_id: str, terminal_group: str):
        self.websocket = websocket
        self.agent_id = agent_id
        self.terminal_id = terminal_id
        self.terminal_group = terminal_group
        self.process = None
        self.master_fd = None
        self.running = False
        self.read_task = None

    # ── arranque ─────────────────────────────────────────────────────────────

    async def start(self):
        """Iniciar shell con PTY."""
        try:
            system = platform.system()
            if system == 'Windows':
                shell = 'powershell.exe'
                logger.info(f"Iniciando terminal Windows: {shell}")
                await self.start_windows_shell(shell)
            else:
                shell = os.environ.get('SHELL', '/bin/bash')
                if shell == '/bin/sh' or not os.path.exists(shell):
                    shell = '/bin/bash'
                logger.info(f"Iniciando terminal Unix con PTY: {shell}")
                await self.start_unix_pty(shell)

            logger.info(f"Terminal iniciado exitosamente: {self.terminal_id}")
        except Exception as e:
            logger.error(f"Error iniciando terminal: {e}")
            await self.send_error(f"Error iniciando terminal: {str(e)}")

    def _get_privileged_shell_command(self, shell: str) -> list:
        """Construye el comando para el shell, usando nsenter si es posible
        para escapar del sandbox de systemd (God Mode)."""
        shell_name = os.path.basename(shell)

        if shell_name in ['bash', 'zsh']:
            cmd = [shell, '-i', '-l']
        else:
            cmd = [shell, '-i']

        if os.geteuid() == 0:
            nsenter = '/usr/bin/nsenter'
            if os.path.exists(nsenter):
                return [nsenter, '-t', '1', '-m', '-u', '-i', '-n', '--'] + cmd

        return cmd

    async def start_unix_pty(self, shell: str):
        """Iniciar shell Unix con PTY."""
        import pty
        import fcntl
        import termios
        import struct

        self.master_fd, slave_fd = pty.openpty()
        fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, struct.pack('HHHH', 24, 80, 0, 0))

        env = os.environ.copy()
        env['TERM'] = 'xterm-256color'
        env['COLUMNS'] = '80'
        env['LINES'] = '24'

        shell_cmd = self._get_privileged_shell_command(shell)

        if shell_cmd[0].endswith('nsenter'):
            logger.info("🛡️  Modo Dios activado: Terminal corriendo via nsenter")

        loop = asyncio.get_event_loop()

        def create_process():
            def preexec_fn():
                if hasattr(os, 'setsid'):
                    os.setsid()

            return subprocess.Popen(
                shell_cmd,
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                env=env,
                cwd='/root',
                preexec_fn=preexec_fn if hasattr(os, 'setsid') else None,
            )

        self.process = await loop.run_in_executor(None, create_process)
        os.close(slave_fd)

        flags = fcntl.fcntl(self.master_fd, fcntl.F_GETFL)
        fcntl.fcntl(self.master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

        self.running = True
        self.read_task = asyncio.create_task(self.read_pty_output())

    async def start_windows_shell(self, shell: str):
        """Iniciar shell Windows sin PTY (fallback)."""
        self.process = await asyncio.create_subprocess_shell(
            shell,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            shell=True,
        )
        self.running = True
        self.read_task = asyncio.create_task(self.read_subprocess_output())

    # ── lectura de output ─────────────────────────────────────────────────────

    async def read_pty_output(self):
        """Leer output del PTY y enviar al servidor (Unix)."""
        loop = asyncio.get_event_loop()

        while self.running and self.process:
            try:
                if self.process.poll() is not None:
                    logger.info(f"Proceso del terminal terminado: {self.terminal_id}")
                    await self.send_closed("Shell terminado")
                    break

                try:
                    output = await loop.run_in_executor(None, os.read, self.master_fd, 4096)
                    if output:
                        text = output.decode('utf-8', errors='replace')
                        await self.send_output(text)
                    else:
                        await asyncio.sleep(0.01)
                except (BlockingIOError, OSError):
                    await asyncio.sleep(0.01)

            except Exception as e:
                if self.running:
                    logger.error(f"Error leyendo PTY: {e}")
                    await self.send_error(f"Error leyendo terminal: {str(e)}")
                break

        await self.close()

    async def read_subprocess_output(self):
        """Leer output del subprocess (Windows fallback)."""
        try:
            while self.running and self.process:
                line = await self.process.stdout.readline()
                if line:
                    text = line.decode('utf-8', errors='replace')
                    await self.send_output(text)
                else:
                    await self.send_closed("Shell terminado")
                    break
        except Exception as e:
            if self.running:
                logger.error(f"Error leyendo subprocess: {e}")
                await self.send_error(f"Error leyendo terminal: {str(e)}")

        await self.close()

    # ── escritura / redimensionado ────────────────────────────────────────────

    async def write_input(self, data: str):
        """Escribir input del usuario al terminal."""
        try:
            if not self.running:
                return
            if platform.system() == 'Windows':
                if self.process and self.process.stdin:
                    self.process.stdin.write(data.encode('utf-8'))
                    await self.process.stdin.drain()
            else:
                if self.master_fd:
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, os.write, self.master_fd, data.encode('utf-8'))
        except Exception as e:
            logger.error(f"Error escribiendo input al terminal: {e}")
            await self.send_error(f"Error escribiendo al terminal: {str(e)}")

    async def resize(self, cols: int, rows: int):
        """Redimensionar terminal."""
        try:
            if platform.system() != 'Windows' and self.master_fd:
                import fcntl
                import termios
                import struct

                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None,
                    fcntl.ioctl,
                    self.master_fd,
                    termios.TIOCSWINSZ,
                    struct.pack('HHHH', rows, cols, 0, 0),
                )
                logger.debug(f"Terminal redimensionado: {cols}x{rows}")
        except Exception as e:
            logger.error(f"Error redimensionando terminal: {e}")

    # ── mensajes hacia el servidor ────────────────────────────────────────────

    async def send_output(self, data: str):
        """Enviar output del terminal al servidor."""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'terminal_output',
                    'terminal_id': self.terminal_id,
                    'data': data,
                }))
        except Exception as e:
            logger.error(f"Error enviando output del terminal: {e}")

    async def send_error(self, error_msg: str):
        """Enviar error del terminal al servidor."""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'terminal_error',
                    'terminal_id': self.terminal_id,
                    'message': error_msg,
                }))
        except Exception as e:
            logger.error(f"Error enviando error del terminal: {e}")

    async def send_closed(self, message: str):
        """Notificar que el terminal se cerró."""
        try:
            if self.websocket and self.websocket.close_code is None:
                await self.websocket.send(json.dumps({
                    'type': 'terminal_closed',
                    'terminal_id': self.terminal_id,
                    'message': message,
                }))
        except Exception as e:
            logger.error(f"Error enviando cierre del terminal: {e}")

    # ── cierre ────────────────────────────────────────────────────────────────

    async def close(self):
        """Cerrar terminal."""
        logger.info(f"Cerrando terminal: {self.terminal_id}")
        self.running = False

        if self.read_task:
            self.read_task.cancel()

        if self.process:
            try:
                self.process.terminate()
                for _ in range(10):
                    if self.process.poll() is not None:
                        break
                    await asyncio.sleep(0.1)
                if self.process.poll() is None:
                    self.process.kill()
            except Exception:
                pass

        if self.master_fd:
            try:
                os.close(self.master_fd)
            except Exception:
                pass

        self.process = None
        self.master_fd = None

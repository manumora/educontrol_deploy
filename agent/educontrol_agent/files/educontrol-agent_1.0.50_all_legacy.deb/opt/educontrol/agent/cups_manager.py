"""
cups_manager.py — Configuración automática de auditoría CUPS para EduControl Agent.

Asegura que el daemon CUPS registre cada trabajo impreso con el formato
requerido por el daemon de parsing interno (page_log).
"""

import logging
import os
import subprocess
import threading
import time
from typing import List, Optional, Tuple

logger = logging.getLogger('EduControlAgent')

CUPSD_CONF = '/etc/cups/cupsd.conf'
# Desde CUPS 1.6 las rutas de ficheros (PageLog incluido) van en cups-files.conf: en cupsd.conf se ignoran.
CUPS_FILES_CONF = '/etc/cups/cups-files.conf'
LOCAL_CUPS_SOCKET = '/run/cups/cups.sock'

# Directivas requeridas y sus valores exactos.
CUPSD_DIRECTIVES = [
    ('JobPrivateValues', 'none'),
    ('PageLogFormat', '%p %u %j %T %P %C %{job-originating-host-name} %{job-name}'),
]
PAGE_LOG_DIRECTIVE = ('PageLog', '/var/log/cups/page_log')
# Sin cups-files.conf (CUPS anterior a 1.6) todo va en cupsd.conf.
REQUIRED_DIRECTIVES = CUPSD_DIRECTIVES[:1] + [PAGE_LOG_DIRECTIVE] + CUPSD_DIRECTIVES[1:]

# Espera máxima a que terminen los trabajos en curso antes de reiniciar CUPS.
RESTART_WAIT_SECONDS = 30 * 60
RESTART_POLL_SECONDS = 15


class CUPSManager:
    """Encapsula la lógica de detección y configuración de CUPS para auditoría."""

    def __init__(self, config):
        """
        Args:
            config: instancia de AgentConfig con print_tracking.
        """
        self.config = config

    # ── helpers privados ─────────────────────────────────────────────────────

    @staticmethod
    def _cups_installed() -> bool:
        """Verifica si CUPS está instalado (presencia de cupsd.conf)."""
        return os.path.isfile(CUPSD_CONF)

    @staticmethod
    def _is_active(line: str, directive: str, value: str) -> bool:
        """
        Comprueba si una línea activa (sin # al inicio) contiene la
        directiva con el valor esperado.

        Se considera activa si la línea, tras stripping, no empieza por '#'.
        """
        stripped = line.strip()
        if stripped.startswith('#'):
            return False
        # La directiva puede aparecer sola o con el valor pegado:
        #   JobPrivateValues none
        #   JobPrivateValues=none
        #   PageLog /var/log/cups/page_log
        return (
            stripped == f'{directive} {value}'
            or stripped == f'{directive}={value}'
        )

    def _configure(self) -> bool:
        """
        Deja las directivas de auditoría donde CUPS las lee: PageLog en cups-files.conf si existe
        (CUPS ≥ 1.6) y el resto en cupsd.conf. Devuelve True si se modificó algún fichero.
        """
        if not self._cups_installed():
            return False
        if os.path.isfile(CUPS_FILES_CONF):
            modified = self._configure_file(CUPS_FILES_CONF, [PAGE_LOG_DIRECTIVE])
            # Un PageLog en cupsd.conf (versiones anteriores del agente) solo produce avisos: se comenta.
            modified |= self._configure_file(CUPSD_CONF, CUPSD_DIRECTIVES, obsolete=['PageLog'])
            return modified
        return self._configure_file(CUPSD_CONF, REQUIRED_DIRECTIVES)

    def _configure_file(self, path: str, directives: List[Tuple[str, str]], obsolete: List[str] = ()) -> bool:
        """
        Garantiza en `path` las directivas indicadas. Si una ya está activa con el valor correcto
        no se modifica; si está activa con otro valor se comenta y se agrega la correcta; si no
        existe se agrega al final. Las directivas de `obsolete` activas se comentan.

        Returns:
            True  → el archivo fue modificado
            False → no hubo cambios (ya estaba correctamente configurado)
        """
        try:
            with open(path, 'r') as f:
                lines = f.readlines()
        except OSError as e:
            logger.error(f"No se pudo leer {path}: {e}")
            return False

        modified = False
        new_lines = []
        # Rastrea qué directivas ya están activas con el valor correcto.
        satisfied = set()

        for line in lines:
            stripped = line.strip()

            # Verificar si esta línea es una directiva activa que necesitamos.
            matched = False
            for idx, (directive, value) in enumerate(directives):
                if idx in satisfied:
                    continue  # ya la tenemos

                # Línea activa con el valor correcto → dejarla y marcarla.
                if self._is_active(line, directive, value):
                    satisfied.add(idx)
                    new_lines.append(line)
                    matched = True
                    break

                # Línea activa de la misma directiva pero con valor distinto
                # → comentar y planear agregar la correcta.
                if stripped and not stripped.startswith('#'):
                    parts = stripped.split()
                    key = parts[0].rstrip('=') if parts else ''
                    if key == directive:
                        logger.info(
                            f"CUPS: comentando línea existente "
                            f"'{stripped}' (valor incorrecto)"
                        )
                        new_lines.append(f"# {line.rstrip()}\n" if not line.startswith('#') else line)
                        matched = True
                        break

            if not matched and stripped and not stripped.startswith('#') and stripped.split()[0] in obsolete:
                logger.info(f"CUPS: comentando '{stripped}' en {path} (aquí CUPS no la usa)")
                new_lines.append(f"# {line.rstrip()}\n")
                modified = True
                matched = True

            if not matched:
                new_lines.append(line)

        # Agregar las directivas faltantes al final.
        for idx, (directive, value) in enumerate(directives):
            if idx not in satisfied:
                logger.info(f"CUPS: añadiendo '{directive} {value}'")
                new_lines.append(f"\n{directive} {value}\n")
                modified = True

        if modified:
            try:
                with open(path, 'w') as f:
                    f.writelines(new_lines)
                logger.info(f"CUPS: {path} actualizado correctamente")
            except OSError as e:
                logger.error(f"No se pudo escribir {path}: {e}")
                return False

        return modified

    @staticmethod
    def _active_jobs() -> bool:
        """¿Hay trabajos en la cola del CUPS local? Si no se puede saber, se asume que no."""
        try:
            result = subprocess.run(['lpstat', '-h', LOCAL_CUPS_SOCKET, '-o'],
                                    capture_output=True, text=True, timeout=10, check=False)
        except Exception:
            return False
        return result.returncode == 0 and bool(result.stdout.strip())

    def _restart_when_idle(self):
        """Reinicia CUPS cuando no hay trabajos en curso (un reinicio cortaría lo que se está imprimiendo)."""
        if not self._active_jobs():
            self._restart_cups()
            return

        def wait_and_restart():
            deadline = time.monotonic() + RESTART_WAIT_SECONDS
            while self._active_jobs() and time.monotonic() < deadline:
                time.sleep(RESTART_POLL_SECONDS)
            self._restart_cups()

        logger.info("CUPS: hay trabajos en curso; se reiniciará cuando terminen")
        threading.Thread(target=wait_and_restart, name='CUPSRestart', daemon=True).start()

    @staticmethod
    def _restart_cups() -> bool:
        """Reinicia el servicio CUPS para que los cambios surtan efecto."""
        try:
            result = subprocess.run(
                ['systemctl', 'restart', 'cups'],
                capture_output=True, text=True, timeout=15, check=False,
            )
            if result.returncode == 0:
                logger.info("✅ Servicio CUPS reiniciado correctamente")
                return True
            else:
                logger.warning(f"CUPS: fallo al reiniciar (rc={result.returncode}): {result.stderr.strip()}")
                return False
        except Exception as e:
            logger.warning(f"CUPS: error al reiniciar el servicio: {e}")
            return False

    # ── entrada principal ────────────────────────────────────────────────────

    def configure_audit(self) -> bool:
        """
        Configura CUPS para auditoría de impresiones.

        Retorna True si la auditoría está activa al final (ya lo estaba o fue
        configurada en esta llamada), False en caso contrario.
        """
        if not self._cups_installed():
            logger.warning("⚠️  CUPS no está instalado en este equipo; omitiendo configuración de auditoría")
            return False

        modified = self._configure()

        if modified:
            self._restart_when_idle()
            return True

        logger.info("✅ CUPS ya está configurado para auditoría de impresiones")
        return True

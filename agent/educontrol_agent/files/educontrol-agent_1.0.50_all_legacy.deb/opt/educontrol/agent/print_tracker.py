"""
print_tracker.py — Contabilidad de las impresoras locales del equipo para EduControl Agent.

Observa con inotify /var/log/cups/ y lee el page_log del CUPS del equipo. Solo comunica
los trabajos de colas locales (USB o red directa): los de colas que apuntan al servidor
de impresión central ya los registra el servidor, y contarlos aquí los duplicaría.

Los trabajos se envían en lotes a `printing/local-jobs/` y aparecen en Impresión ›
Trabajos con origen «Local». La posición leída solo avanza cuando el servidor confirma
el envío; si falla, se reintenta (el servidor descarta los duplicados).
"""

import json
import logging
import os
import re
import subprocess
import threading
import time
from datetime import datetime
from typing import Optional

logger = logging.getLogger('EduControlAgent')

# ── dependencias opcionales ──────────────────────────────────────────────────

try:
    # v1.x API: Watcher + flags
    from inotify_simple import Watcher, flags
    INOTIFY_AVAILABLE = True
    INOTIFY_V2 = False
except ImportError:
    try:
        # v2.x API: INotify + flags
        import inotify_simple
        INOTIFY_AVAILABLE = True
        INOTIFY_V2 = True
    except ImportError:
        INOTIFY_AVAILABLE = False
        INOTIFY_V2 = False

try:
    import cups
    PYCUPS_AVAILABLE = True
except ImportError:
    PYCUPS_AVAILABLE = False

# ── constantes ───────────────────────────────────────────────────────────────

PAGE_LOG_DIR = '/var/log/cups/'
PAGE_LOG_FILE = os.path.join(PAGE_LOG_DIR, 'page_log')
PAGE_LOG_STATE_FILE = os.path.join(PAGE_LOG_DIR, '.educontrol_page_log_pos')
PRINTING_STATE_FILE = '/etc/educontrol/printing-state.json'
LOCAL_CUPS_SOCKET = '/run/cups/cups.sock'

# Trabajos por envío y espera antes de reintentar un envío fallido.
BATCH_SIZE = 200
RETRY_SECONDS = 60
# Colas del CUPS de un servidor: ipp(s)://HOST:631/printers/COLA
SERVER_QUEUE_RE = re.compile(r'^ipps?://([^/:]+)(?::(\d+))?/printers/', re.IGNORECASE)

# Regex para la línea CUPS:
#   <Printer> <User> <Job_ID> [<Date>] total <Total_Sheets> <Host> <Document_Name>
LINE_RE = re.compile(
    r'^(\S+)\s+(\S+)\s+(\d+)\s+\[(.*?)\]\s+total\s+(\d+)\s+(\S+)\s+(.*)$'
)


class PrintTracker:
    """Monitoriza /var/log/cups/page_log y envía registros al backend."""

    def __init__(self, config):
        """
        Args:
            config: instancia de AgentConfig con http_url, token, agent_id,
                    verify_ssl, hostname y print_tracking.
        """
        self.config = config
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        # Posición en el archivo page_log (offset en bytes) para no
        # reenviar registros ya procesados en arranques anteriores.
        self._last_pos = self._load_position()
        # URI de cada cola local, para distinguir las que van al servidor central.
        self._queue_uris: dict = {}
        self._retry_at: Optional[float] = None

    # ── helpers privados ─────────────────────────────────────────────────────

    def _get_copies(self, job_id: int) -> int:
        """
        Consulta el servidor CUPS local para obtener el número de copias
        del trabajo.

        Returns:
            Número de copias si CUPS lo devuelve, o None si no se pudo
            obtener (el backend enviará null al frontend, que mostrará '—').
        """
        if not PYCUPS_AVAILABLE:
            return None

        try:
            conn = cups.Connection()
            job = conn.getJobAttributes(job_id)

            # Número de copias — la clave IPP estándar es 'copies'
            for key in ('copies', 'num-copies', 'number-of-copies'):
                if key in job:
                    try:
                        val = int(job[key])
                        if val > 0:
                            return val
                    except (ValueError, TypeError):
                        pass

            return None

        except Exception as e:
            logger.debug(
                f"PrintTracker: no se pudo consultar Job {job_id} en CUPS: {e}"
            )
            return None

    def _send_jobs(self, jobs: list) -> bool:
        """
        Envía un lote de trabajos locales a `printing/local-jobs/`. True si el servidor los
        ha recibido (aunque no guarde ninguno, p. ej. con el módulo de impresión desactivado).
        """
        if not jobs:
            return True
        try:
            import requests as _requests

            url = f"{self.config.http_url}/api/printing/local-jobs/"
            headers = {'Content-Type': 'application/json'}
            if self.config.token:
                headers['Authorization'] = f'Token {self.config.token}'
            resp = _requests.post(url, json={'agent_id': self.config.agent_id, 'jobs': jobs}, headers=headers,
                                  timeout=15, verify=self.config.verify_ssl)
            if resp.status_code == 200:
                recorded = resp.json().get('recorded', 0)
                logger.info(f"PrintTracker: {len(jobs)} trabajo(s) local(es) enviados, {recorded} nuevos")
                return True
            logger.warning(f"PrintTracker: fallo al enviar (HTTP {resp.status_code}): {resp.text[:200]}")
            return False
        except ImportError:
            logger.warning("PrintTracker: requests no disponible, no se puede enviar registro")
            return False
        except Exception as e:
            logger.warning(f"PrintTracker: error al enviar registros: {e}")
            return False

    # ── clasificación de colas ───────────────────────────────────────────────

    @staticmethod
    def _printing_state() -> dict:
        try:
            with open(PRINTING_STATE_FILE, encoding='utf-8') as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return {}

    def _refresh_queue_uris(self):
        """URI de cada cola del CUPS del equipo (`lpstat -v` contra el socket local)."""
        try:
            result = subprocess.run(['lpstat', '-h', LOCAL_CUPS_SOCKET, '-v'],
                                    capture_output=True, text=True, timeout=15, check=False)
        except Exception as e:
            logger.debug(f"PrintTracker: no se pudieron listar las colas: {e}")
            return
        uris = {}
        for line in result.stdout.splitlines():
            # "device for COLA: uri" (o traducido: "dispositivo para COLA: uri")
            match = re.match(r'^\S+\s+\S+\s+([^:]+):\s*(\S+)', line.strip())
            if match:
                uris[match.group(1).strip()] = match.group(2).strip()
        if uris:
            self._queue_uris = uris

    def _is_server_queue(self, queue: str) -> bool:
        """
        ¿La cola imprime a través del servidor central? Lo es si la creó el agente
        (`managed_queues`) o si su URI apunta a `ipp(s)://SERVIDOR:631/printers/`.
        """
        state = self._printing_state()
        if queue in (state.get('managed_queues') or []):
            return True
        if queue not in self._queue_uris:
            self._refresh_queue_uris()
        server = str(state.get('server') or '').lower()
        match = SERVER_QUEUE_RE.match(self._queue_uris.get(queue, ''))
        return bool(server and match and match.group(1).lower() == server)

    def _load_position(self) -> int:
        """Lee la posición última procesada desde el archivo de estado."""
        try:
            if os.path.isfile(PAGE_LOG_STATE_FILE):
                with open(PAGE_LOG_STATE_FILE, 'r') as f:
                    return int(f.read().strip())
        except (ValueError, OSError):
            pass
        return 0

    def _save_position(self, pos: int):
        """Guarda la posición actual procesada en el archivo de estado."""
        try:
            with open(PAGE_LOG_STATE_FILE, 'w') as f:
                f.write(str(pos))
        except OSError as e:
            logger.warning(f"PrintTracker: no se pudo guardar posición: {e}")

    def _parse_line(self, line: str) -> Optional[dict]:
        """Trabajo de una línea «total» del page_log, o None si no lo es."""
        m = LINE_RE.match(line.strip())
        if not m:
            return None
        printer_name, user, job_id, date_str, impressions, _host, title = m.groups()
        job_id = int(job_id)
        timestamp = datetime.now().astimezone().isoformat()
        try:
            timestamp = datetime.strptime(date_str, '%d/%b/%Y:%H:%M:%S %z').isoformat()
        except ValueError:
            pass
        return {
            'printer': printer_name,
            'job_id': job_id,
            'user': user,
            'title': title.strip(),
            # CUPS anota en «total» las caras impresas (páginas × copias).
            'impressions': int(impressions),
            'copies': self._get_copies(job_id) or 1,
            'timestamp': timestamp,
        }

    def _parse_and_send(self, filepath: str):
        """
        Lee las líneas nuevas desde la última posición, envía en lotes los trabajos de colas
        locales y avanza la posición solo hasta donde el servidor ha confirmado.
        """
        with self._lock:
            try:
                size = os.path.getsize(filepath)
                pos = self._last_pos
                if size < pos:
                    # CUPS ha rotado el log: el fichero nuevo empieza de cero.
                    logger.info("PrintTracker: page_log rotado; se lee desde el principio")
                    pos = 0
                with open(filepath, 'r', errors='replace') as f:
                    f.seek(pos)
                    pending, batch_end = [], pos
                    while True:
                        line = f.readline()
                        if not line:
                            break
                        if not line.endswith('\n'):
                            break  # línea a medio escribir: se leerá entera en el siguiente evento
                        job = self._parse_line(line) if 'total' in line else None
                        if job and not self._is_server_queue(job['printer']):
                            logger.info(f"PrintTracker: impresión local — user={job['user']}, "
                                        f"printer={job['printer']}, doc={job['title']}, job_id={job['job_id']}")
                            pending.append(job)
                        batch_end = f.tell()
                        if len(pending) >= BATCH_SIZE:
                            if not self._commit(pending, batch_end):
                                return
                            pending = []
                    self._commit(pending, batch_end)
            except OSError as e:
                logger.warning(f"PrintTracker: error leyendo {filepath}: {e}")

    def _commit(self, jobs: list, end_pos: int) -> bool:
        """Envía y, si el servidor confirma, guarda la posición. Si falla, programa un reintento."""
        if not self._send_jobs(jobs):
            self._retry_at = time.monotonic() + RETRY_SECONDS
            return False
        self._retry_at = None
        if end_pos != self._last_pos:
            self._last_pos = end_pos
            self._save_position(end_pos)
        return True

    def _maybe_retry(self):
        """Reintenta un envío fallido aunque no haya impresiones nuevas."""
        if self._retry_at is not None and time.monotonic() >= self._retry_at and os.path.isfile(PAGE_LOG_FILE):
            self._parse_and_send(PAGE_LOG_FILE)

    def _watch(self):
        """
        Bucle principal del hilo: inicializa inotify y espera eventos en el
        directorio de logs.  Compatible con inotify-simple v1.x y v2.x.
        """
        if not os.path.isdir(PAGE_LOG_DIR):
            logger.warning(f"PrintTracker: directorio {PAGE_LOG_DIR} no existe; omitiendo")
            return

        # Si el archivo ya existe y tiene contenido, procesarlo antes de vigilar.
        if os.path.isfile(PAGE_LOG_FILE):
            logger.info("PrintTracker: procesando registros previos de page_log...")
            self._parse_and_send(PAGE_LOG_FILE)

        logger.info("PrintTracker: iniciando watcher en %s (inotify-simple v%s)",
                    PAGE_LOG_DIR, "2.x" if INOTIFY_V2 else "1.x")

        while not self._stop_event.is_set():
            try:
                if INOTIFY_V2:
                    self._watch_v2()
                else:
                    self._watch_v1()

            except Exception as e:
                logger.warning(f"PrintTracker: error en watcher: {e}")
                if self._stop_event.is_set():
                    break
                time.sleep(3)

    # ── watchers por versión ───────────────────────────────────────────────

    def _watch_v1(self):
        """inotify-simple v1.x: API Watcher."""
        watcher = Watcher()
        watcher.add_watch(PAGE_LOG_DIR, flags.MODIFY | flags.CREATE)

        while not self._stop_event.is_set():
            events = watcher.event(timeout=1000)
            self._maybe_retry()

            for event in events:
                # Ignorar eventos de directorio o ignorados
                if 'ISDIR' in event.mask_names or 'IGNORE' in event.mask_names:
                    continue

                # Filtrar para el archivo page_log
                if event.name and 'page_log' in event.name:
                    logger.debug(f"PrintTracker: evento inotify en page_log ({event.mask_names})")
                    time.sleep(0.1)
                    if os.path.isfile(PAGE_LOG_FILE):
                        self._parse_and_send(PAGE_LOG_FILE)

    def _watch_v2(self):
        """inotify-simple v2.x: API INotify."""
        import inotify_simple as inotify

        inf = inotify.INotify()
        inf.add_watch(
            PAGE_LOG_DIR,
            inotify.flags.MODIFY | inotify.flags.CREATE,
        )

        while not self._stop_event.is_set():
            events = inf.read(timeout=1000)
            self._maybe_retry()

            for ev in events:
                # Ignorar eventos de directorio o ignorados
                if inotify.flags.ISDIR.value & ev.mask:
                    continue
                if inotify.flags.IGNORED.value & ev.mask:
                    continue

                # Filtrar para el archivo page_log
                if ev.name and 'page_log' in ev.name:
                    logger.debug(f"PrintTracker: evento inotify en page_log (mask={ev.mask:#x})")
                    time.sleep(0.1)
                    if os.path.isfile(PAGE_LOG_FILE):
                        self._parse_and_send(PAGE_LOG_FILE)

    # ── control del hilo ────────────────────────────────────────────────────

    def start(self):
        """Inicia el hilo de monitoreo de impresiones."""
        if not INOTIFY_AVAILABLE:
            logger.warning("PrintTracker: inotify_simple no disponible; monitoreo desactivado")
            return
        # Se llama en cada conexión con el servidor: un solo hilo vigilante.
        if self._thread is not None and self._thread.is_alive():
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._watch, daemon=True, name='PrintTracker')
        self._thread.start()
        logger.info("PrintTracker: hilo iniciado")

    def stop(self):
        """Detiene el hilo de monitoreo."""
        self._stop_event.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=5)
        logger.info("PrintTracker: hilo detenido")

"""
kiosk_manager.py — Reproductor de cartelería de Educontrol en modo kiosk.

Si el equipo está elegido en Cartelería › Pantalla, el servidor envía la acción
`signage_kiosk_sync` con la URL del reproductor. El agente la guarda en disco y un
watchdog mantiene abierto el navegador a pantalla completa en la sesión gráfica:
lo lanza al iniciar sesión, lo relanza si se cierra y lo cierra si se desactiva.

El navegador se lanza con `systemd-run` como unidad propia (`educontrol-kiosk`) y no
como hijo del agente: así sobrevive a un reinicio o una actualización del agente.
"""

import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
import threading
from typing import List, Optional, Tuple

logger = logging.getLogger('EduControlAgent')

STATE_FILE = '/etc/educontrol/kiosk-state.json'
# Fuera de /etc/educontrol, que guarda el token del agente: el usuario de la sesión debe poder leerla.
EXTENSION_DIR = '/opt/educontrol/kiosk-extension'
UNIT = 'educontrol-kiosk'
PROFILE_SUBDIR = '.config/educontrol-kiosk'
WATCHDOG_INTERVAL = 10
BROWSERS = ('chromium', 'chromium-browser', 'google-chrome', 'google-chrome-stable')

BROWSER_FLAGS = [
    '--noerrdialogs',
    '--disable-infobars',
    '--disable-session-crashed-bubble',
    '--check-for-update-interval=31536000',
    '--no-first-run',
    '--no-default-browser-check',
    '--password-store=basic',
    '--disable-translate',
    '--autoplay-policy=no-user-gesture-required',
    '--overscroll-history-navigation=0',
    '--disable-pinch',
    # Chromium solo atiende al último --disable-features: todas en una lista.
    '--disable-features=Translate,TranslateUI,MediaRouter,DisableLoadExtensionCommandLineSwitch',
]

# Extensión que quita X-Frame-Options y CSP solo a los documentos cargados en iframes, para poder
# mostrar webs que prohíben incrustarse. Aceptable porque el navegador del kiosk no lo usa nadie.
EXTENSION_FILES = {
    'manifest.json': {
        'manifest_version': 3,
        'name': 'Educontrol Kiosk: webs en iframes',
        'version': '1.0',
        'description': 'Permite que el reproductor de cartelería muestre webs que prohíben los iframes.',
        'permissions': ['declarativeNetRequest'],
        'host_permissions': ['<all_urls>'],
        'declarative_net_request': {
            'rule_resources': [{'id': 'frames', 'enabled': True, 'path': 'rules.json'}],
        },
    },
    'rules.json': [{
        'id': 1,
        'priority': 1,
        'action': {
            'type': 'modifyHeaders',
            'responseHeaders': [
                {'header': 'x-frame-options', 'operation': 'remove'},
                {'header': 'content-security-policy', 'operation': 'remove'},
            ],
        },
        'condition': {'resourceTypes': ['sub_frame']},
    }],
}


class KioskManager:
    def __init__(self, actions):
        # AgentActions: aporta la localización de la sesión gráfica.
        self.actions = actions
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    # ── Estado ─────────────────────────────────────────────────────────────────

    def _load_state(self) -> dict:
        try:
            with open(STATE_FILE, encoding='utf-8') as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return {}

    def _save_state(self, state: dict):
        directory = os.path.dirname(STATE_FILE)
        os.makedirs(directory, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=directory, prefix='.kiosk-')
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as fh:
                json.dump(state, fh, indent=2)
            os.chmod(tmp, 0o600)
            os.replace(tmp, STATE_FILE)
        except Exception:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise

    @property
    def active(self) -> bool:
        """Se informa al servidor al conectar: si ya no está elegido, el servidor manda cerrarlo."""
        return bool(self._load_state().get('enabled'))

    # ── Acciones del servidor ──────────────────────────────────────────────────

    def sync(self, params: dict) -> Tuple[bool, str, str]:
        enabled = bool(params.get('enabled'))
        url = str(params.get('url') or '').strip()
        if enabled and not re.match(r'^https?://\S+$', url):
            return False, '', 'URL del reproductor no válida'
        with self._lock:
            state = self._load_state()
            state.update({
                'enabled': enabled,
                'url': url if enabled else state.get('url', ''),
                'ignore_cert_errors': bool(params.get('ignore_cert_errors')),
                'allow_http': bool(params.get('allow_http')),
            })
            self._save_state(state)
            message = self._reconcile(state)
        return True, message, ''

    def status(self) -> Tuple[bool, str, str]:
        state = self._load_state()
        running = self._unit_active()
        return True, json.dumps({
            'enabled': bool(state.get('enabled')),
            'url': state.get('url', ''),
            'running': running,
            'user': (state.get('launched') or {}).get('user') if running else None,
            'browser': self._browser(),
        }), ''

    # ── Watchdog ───────────────────────────────────────────────────────────────

    def start_watchdog(self):
        """Arranca con el agente, antes de conectar: tras un reinicio el kiosk vuelve aunque no haya servidor."""
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._watchdog_loop, name='kiosk-watchdog', daemon=True)
        self._thread.start()

    def stop_watchdog(self):
        self._stop.set()

    def _watchdog_loop(self):
        while not self._stop.is_set():
            try:
                with self._lock:
                    self._reconcile(self._load_state())
            except Exception as e:
                logger.warning(f'Kiosk: error en el watchdog: {e}')
            self._stop.wait(WATCHDOG_INTERVAL)

    def _reconcile(self, state: dict) -> str:
        """Deja el navegador como dice el estado. Devuelve un mensaje legible."""
        if not state.get('enabled'):
            if self._unit_active():
                self._stop_unit()
                return 'Kiosk cerrado'
            return 'Kiosk desactivado'

        session = self._pick_session()
        if session is None:
            return 'Kiosk activado; se abrirá cuando haya una sesión gráfica'
        browser = self._browser()
        if browser is None:
            return 'Kiosk activado, pero no hay Chromium ni Google Chrome instalado'

        command, env = self.build_command(state, session, browser)
        wanted = {'user': session.user, 'command': command}
        if self._unit_active() and state.get('launched') == wanted:
            return f'Kiosk abierto en la sesión de {session.user}'

        if self._unit_active():
            self._stop_unit()
        self._prepare_session(session)
        ok, error = self._start_unit(session, command, env)
        if not ok:
            logger.warning(f'Kiosk: no se pudo lanzar el navegador: {error}')
            return f'No se pudo abrir el kiosk: {error}'
        state['launched'] = wanted
        self._save_state(state)
        logger.info(f'Kiosk: navegador abierto en la sesión de {session.user} ({state["url"]})')
        return f'Kiosk abierto en la sesión de {session.user}'

    # ── Sesión y navegador ─────────────────────────────────────────────────────

    def _pick_session(self):
        """Prefiere la sesión de la consola física (VT 7 o tty7), que es la que se ve en la TV."""
        sessions = self.actions._graphical_sessions()
        for session in sessions:
            if session.vt == '7' or session.tty == 'tty7':
                return session
        return sessions[0] if sessions else None

    @staticmethod
    def _browser() -> Optional[str]:
        return next((path for path in map(shutil.which, BROWSERS) if path), None)

    @staticmethod
    def _wayland_display(session) -> Optional[str]:
        try:
            sockets = sorted(n for n in os.listdir(session.runtime_dir)
                             if re.fullmatch(r'wayland-\d+', n))
        except OSError:
            return None
        return sockets[0] if sockets else None

    def build_command(self, state: dict, session, browser: str) -> Tuple[List[str], dict]:
        env = {
            'HOME': session.home,
            'XDG_RUNTIME_DIR': session.runtime_dir,
            'DBUS_SESSION_BUS_ADDRESS': f'unix:path={session.runtime_dir}/bus',
            'DISPLAY': session.display,
        }
        if session.xauthority:
            env['XAUTHORITY'] = session.xauthority

        command = [browser, '--kiosk', state['url'],
                   f'--user-data-dir={os.path.join(session.home, PROFILE_SUBDIR)}', *BROWSER_FLAGS]
        if session.session_type == 'wayland':
            wayland = self._wayland_display(session)
            if wayland:
                env['WAYLAND_DISPLAY'] = wayland
                command.append('--ozone-platform=wayland')
        if state.get('ignore_cert_errors'):
            command.append('--ignore-certificate-errors')
        if state.get('allow_http'):
            command.append('--allow-running-insecure-content')
        if self._ensure_extension():
            command.append(f'--load-extension={EXTENSION_DIR}')
        return command, env

    @staticmethod
    def _ensure_extension() -> bool:
        try:
            os.makedirs(EXTENSION_DIR, mode=0o755, exist_ok=True)
            for name, content in EXTENSION_FILES.items():
                path = os.path.join(EXTENSION_DIR, name)
                text = json.dumps(content, indent=2)
                try:
                    with open(path, encoding='utf-8') as fh:
                        if fh.read() == text:
                            continue
                except OSError:
                    pass
                with open(path, 'w', encoding='utf-8') as fh:
                    fh.write(text)
                os.chmod(path, 0o644)
            return True
        except OSError as e:
            logger.warning(f'Kiosk: no se pudo preparar la extensión de iframes: {e}')
            return False

    def _prepare_session(self, session):
        """Antes de lanzar: pantalla siempre encendida y sin aviso de «restaurar sesión»."""
        preferences = os.path.join(session.home, PROFILE_SUBDIR, 'Default', 'Preferences')
        try:
            with open(preferences, encoding='utf-8') as fh:
                text = fh.read()
            fixed = text.replace('"exited_cleanly":false', '"exited_cleanly":true')
            fixed = re.sub(r'"exit_type":"[^"]*"', '"exit_type":"Normal"', fixed)
            if fixed != text:
                with open(preferences, 'w', encoding='utf-8') as fh:
                    fh.write(fixed)
        except OSError:
            pass  # primer arranque: aún no hay perfil

        if session.session_type == 'x11' and shutil.which('xset'):
            env = {'DISPLAY': session.display, **({'XAUTHORITY': session.xauthority} if session.xauthority else {})}
            for args in (['s', 'off'], ['s', 'noblank'], ['-dpms']):
                self._run(['runuser', '-u', session.user, '--', 'env',
                           *[f'{k}={v}' for k, v in env.items()], 'xset', *args])
        elif shutil.which('raspi-config'):
            # Wayland en Raspberry Pi OS: el apagado de pantalla lo gestiona swayidle; raspi-config lo desactiva.
            self._run(['raspi-config', 'nonint', 'do_blanking', '1'])

    # ── Unidad systemd ─────────────────────────────────────────────────────────

    @staticmethod
    def _run(cmd: List[str], timeout: int = 20) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
        except (OSError, subprocess.TimeoutExpired) as e:
            return subprocess.CompletedProcess(cmd, 1, '', str(e))

    def _unit_active(self) -> bool:
        return self._run(['systemctl', 'is-active', '--quiet', UNIT]).returncode == 0

    def _stop_unit(self):
        self._run(['systemctl', 'stop', UNIT], timeout=30)
        self._run(['systemctl', 'reset-failed', UNIT])

    def _start_unit(self, session, command: List[str], env: dict) -> Tuple[bool, str]:
        self._run(['systemctl', 'reset-failed', UNIT])
        cmd = ['systemd-run', f'--unit={UNIT}', '--collect', '--quiet',
               f'--uid={session.uid}', f'--gid={self._gid(session)}',
               '--description=Educontrol: reproductor de cartelería en modo kiosk']
        cmd += [f'--setenv={k}={v}' for k, v in env.items()]
        result = self._run(cmd + command)
        return result.returncode == 0, (result.stderr or result.stdout or '').strip()

    @staticmethod
    def _gid(session) -> int:
        import pwd
        try:
            return pwd.getpwnam(session.user).pw_gid
        except KeyError:
            return session.uid
